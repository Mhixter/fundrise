import React from 'react';
import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom';
import { LayoutDashboard, Users, Flag, MessageSquare, Settings, LogOut } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { toast } from 'sonner';

export default function AdminLayout() {
  const { signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleSignOut = async () => {
    try {
      await signOut();
      toast.success('Logged out successfully');
      navigate('/login');
    } catch (error) {
      console.error('Error signing out:', error);
      toast.error('Failed to log out');
    }
  };

  const isActive = (path: string) => {
    return location.pathname === `/admin${path}` ? 'bg-emerald-700' : '';
  };

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="w-64 bg-emerald-800 text-white">
        <div className="p-4">
          <Link to="/admin" className="flex items-center space-x-2">
            <span className="text-2xl font-bold">Admin Panel</span>
          </Link>
        </div>
        
        <nav className="mt-8 space-y-2 px-4">
          <Link
            to="/admin"
            className={`flex items-center space-x-2 rounded-lg p-2 hover:bg-emerald-700 ${isActive('')}`}
          >
            <LayoutDashboard size={20} />
            <span>Dashboard</span>
          </Link>
          
          <Link
            to="/admin/campaigns"
            className={`flex items-center space-x-2 rounded-lg p-2 hover:bg-emerald-700 ${isActive('/campaigns')}`}
          >
            <Flag size={20} />
            <span>Campaigns</span>
          </Link>
          
          <Link
            to="/admin/users"
            className={`flex items-center space-x-2 rounded-lg p-2 hover:bg-emerald-700 ${isActive('/users')}`}
          >
            <Users size={20} />
            <span>Users</span>
          </Link>
          
          <Link
            to="/admin/support"
            className={`flex items-center space-x-2 rounded-lg p-2 hover:bg-emerald-700 ${isActive('/support')}`}
          >
            <MessageSquare size={20} />
            <span>Support</span>
          </Link>
          
          <Link
            to="/admin/settings"
            className={`flex items-center space-x-2 rounded-lg p-2 hover:bg-emerald-700 ${isActive('/settings')}`}
          >
            <Settings size={20} />
            <span>Settings</span>
          </Link>
        </nav>

        <div className="absolute bottom-0 w-64 border-t border-emerald-700 p-4">
          <button
            onClick={handleSignOut}
            className="flex w-full items-center space-x-2 rounded-lg p-2 hover:bg-emerald-700"
          >
            <LogOut size={20} />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <Outlet />
      </div>
    </div>
  );
}