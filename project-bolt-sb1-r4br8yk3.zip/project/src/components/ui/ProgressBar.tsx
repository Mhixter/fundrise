import React from 'react';

interface ProgressBarProps {
  currentAmount: number;
  goalAmount: number;
  className?: string;
  showPercentage?: boolean;
}

export default function ProgressBar({
  currentAmount,
  goalAmount,
  className = '',
  showPercentage = true
}: ProgressBarProps) {
  const percentage = Math.min(Math.round((currentAmount / goalAmount) * 100), 100);
  
  return (
    <div className={`w-full ${className}`}>
      <div className="relative h-4 w-full overflow-hidden rounded-full bg-gray-200">
        <div
          className="absolute left-0 top-0 h-full rounded-full bg-emerald-600 transition-all duration-500 ease-in-out"
          style={{ width: `${percentage}%` }}
        />
      </div>
      {showPercentage && (
        <div className="mt-1 flex justify-between text-xs text-gray-500">
          <span>{percentage}% funded</span>
          <span>{currentAmount} / {goalAmount}</span>
        </div>
      )}
    </div>
  );
}