import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';

interface SupportAgent {
  id: string;
  name: string;
  email: string;
  status: 'online' | 'offline' | 'busy';
  specialization: string[];
}

export default function SupportTeam() {
  const { user } = useAuth();
  const [agents, setAgents] = React.useState<SupportAgent[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    fetchSupportAgents();
  }, []);

  const fetchSupportAgents = async () => {
    try {
      const { data, error } = await supabase
        .from('support_agents')
        .select('*')
        .eq('status', 'online');

      if (error) throw error;
      setAgents(data || []);
    } catch (error) {
      console.error('Error fetching support agents:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div>Loading support team...</div>;
  }

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Available Support Agents</h2>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {agents.map((agent) => (
          <div key={agent.id} className="rounded-lg border p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">{agent.name}</h3>
                <p className="text-sm text-gray-500">{agent.specialization.join(', ')}</p>
              </div>
              <div className={`h-3 w-3 rounded-full ${
                agent.status === 'online' ? 'bg-green-500' : 
                agent.status === 'busy' ? 'bg-yellow-500' : 'bg-gray-500'
              }`} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}