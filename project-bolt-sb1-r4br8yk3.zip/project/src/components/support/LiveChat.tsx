import React, { useState, useRef, useEffect } from 'react';
import { Send, X, MinusCircle, Maximize2, Minimize2, User } from 'lucide-react';
import Button from '../ui/Button';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'support' | 'auto';
  timestamp: Date;
  isQuickReply?: boolean;
}

interface QuickReply {
  text: string;
  action: string;
}

interface UserInfo {
  name: string;
  email: string;
  issue: string;
}

const AUTO_REPLIES: Record<string, string> = {
  'help': "How can I help you today? Choose from the following options:",
  'account': "For account-related issues, please provide:\n- Your name\n- Email address\n- Specific account issue\n\nA support agent will assist you shortly.",
  'donation': "For donation support, please share:\n- Your name\n- Email address\n- Transaction ID (if applicable)\n- Donation issue\n\nWe'll help you right away.",
  'campaign': "For campaign assistance, please provide:\n- Your name\n- Email address\n- Campaign URL (if existing)\n- Your question\n\nOur team will guide you through.",
  'technical': "For technical help, please share:\n- Your name\n- Email address\n- Browser & device info\n- Issue description\n\nWe'll help resolve your technical issue.",
  'other': "Please provide:\n- Your name\n- Email address\n- How can we help you?\n\nA support agent will assist you shortly."
};

const QUICK_REPLIES: QuickReply[] = [
  { text: "Account Help", action: "account" },
  { text: "Donation Support", action: "donation" },
  { text: "Campaign Help", action: "campaign" },
  { text: "Technical Support", action: "technical" },
  { text: "Other Question", action: "other" }
];

export default function LiveChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [showQuickReplies, setShowQuickReplies] = useState(true);
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);
  const [collectingInfo, setCollectingInfo] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      const welcomeMessage: Message = {
        id: Date.now().toString(),
        text: "👋 Welcome to FundRise Support! To better assist you, please choose a topic from below:",
        sender: 'auto',
        timestamp: new Date()
      };
      setMessages([welcomeMessage]);
    }
  }, [isOpen]);

  const handleQuickReply = (reply: QuickReply) => {
    setSelectedTopic(reply.action);
    const userMessage: Message = {
      id: Date.now().toString(),
      text: reply.text,
      sender: 'user',
      timestamp: new Date(),
      isQuickReply: true
    };

    const autoReply: Message = {
      id: (Date.now() + 1).toString(),
      text: AUTO_REPLIES[reply.action],
      sender: 'auto',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage, autoReply]);
    setShowQuickReplies(false);
    setCollectingInfo(true);
  };

  const handleUserInfoSubmit = (info: UserInfo) => {
    setUserInfo(info);
    setCollectingInfo(false);

    const infoMessage: Message = {
      id: Date.now().toString(),
      text: `Name: ${info.name}\nEmail: ${info.email}\nIssue: ${info.issue}`,
      sender: 'user',
      timestamp: new Date()
    };

    const responseMessage: Message = {
      id: (Date.now() + 1).toString(),
      text: "Thank you for providing your information. A support agent will be with you shortly. In the meantime, feel free to provide any additional details about your issue.",
      sender: 'auto',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, infoMessage, responseMessage]);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    if (collectingInfo) {
      // Parse user info from message
      const [name, email, ...issueParts] = message.split('\n');
      const issue = issueParts.join('\n');

      handleUserInfoSubmit({
        name: name || 'Not provided',
        email: email || 'Not provided',
        issue: issue || 'Not provided'
      });
    } else {
      const newMessage: Message = {
        id: Date.now().toString(),
        text: message,
        sender: 'user',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, newMessage]);

      // Auto-response for follow-up messages
      setTimeout(() => {
        const autoResponse: Message = {
          id: (Date.now() + 1).toString(),
          text: "Thank you for the additional information. Our support team will review your message and respond shortly.",
          sender: 'auto',
          timestamp: new Date()
        };
        setMessages(prev => [...prev, autoResponse]);
      }, 1000);
    }

    setMessage('');
  };

  if (!isOpen) {
    return (
      <Button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 z-50 rounded-full shadow-lg bg-emerald-600 text-white hover:bg-emerald-700"
      >
        Need Help? Chat with Us
      </Button>
    );
  }

  return (
    <div className={`fixed bottom-4 right-4 z-50 w-96 rounded-lg bg-white shadow-xl transition-all duration-200 ${isMinimized ? 'h-14' : 'h-[600px]'}`}>
      {/* Header */}
      <div className="flex items-center justify-between bg-emerald-600 p-4 text-white rounded-t-lg">
        <div className="flex items-center">
          <div className={`mr-2 h-2 w-2 rounded-full ${isConnected ? 'bg-green-400' : 'bg-yellow-400'}`} />
          <h3 className="font-semibold">Support Chat</h3>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="text-white hover:text-gray-200"
          >
            {isMinimized ? <Maximize2 size={18} /> : <MinusCircle size={18} />}
          </button>
          <button
            onClick={() => setIsOpen(false)}
            className="text-white hover:text-gray-200"
          >
            <X size={18} />
          </button>
        </div>
      </div>

      {!isMinimized && (
        <>
          {/* Messages */}
          <div className="h-[480px] overflow-y-auto p-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`mb-4 flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`rounded-lg px-4 py-2 max-w-[80%] ${
                    msg.sender === 'user'
                      ? 'bg-emerald-600 text-white'
                      : msg.sender === 'auto'
                      ? 'bg-gray-100 text-gray-900'
                      : 'bg-blue-600 text-white'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.text}</p>
                  <p className="mt-1 text-xs opacity-75">
                    {msg.timestamp.toLocaleTimeString()}
                  </p>
                </div>
              </div>
            ))}
            {showQuickReplies && (
              <div className="my-4 flex flex-wrap gap-2">
                {QUICK_REPLIES.map((reply) => (
                  <button
                    key={reply.action}
                    onClick={() => handleQuickReply(reply)}
                    className="rounded-full bg-gray-100 px-4 py-2 text-sm text-gray-700 hover:bg-gray-200 transition-colors"
                  >
                    {reply.text}
                  </button>
                ))}
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <form onSubmit={handleSendMessage} className="border-t p-4">
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder={
                  collectingInfo
                    ? "Enter your name, email, and issue (each on a new line)"
                    : "Type your message..."
                }
                className="flex-1 rounded-lg border border-gray-300 px-4 py-2 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
              <Button 
                type="submit" 
                disabled={!message.trim()}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                <Send size={18} />
              </Button>
            </div>
            {collectingInfo && (
              <p className="mt-2 text-xs text-gray-500">
                Please provide your information in the following format:
                <br />Your Name
                <br />Your Email
                <br />Your Issue/Question
              </p>
            )}
          </form>
        </>
      )}
    </div>
  );
}