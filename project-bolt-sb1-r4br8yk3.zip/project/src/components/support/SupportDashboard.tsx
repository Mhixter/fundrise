import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import Button from '../ui/Button';
import ChatWindow from './ChatWindow';

interface ChatSession {
  id: string;
  user_id: string;
  status: string;
  created_at: string;
  user: {
    email: string;
    full_name: string;
  };
}

export default function SupportDashboard() {
  const { user } = useAuth();
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSession, setActiveSession] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchSessions();
      subscribeToNewSessions();
    }
  }, [user]);

  const fetchSessions = async () => {
    try {
      const { data, error } = await supabase
        .from('chat_sessions')
        .select(`
          *,
          user:user_id (
            email,
            full_name
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSessions(data || []);
    } catch (error) {
      console.error('Error fetching sessions:', error);
    } finally {
      setLoading(false);
    }
  };

  const subscribeToNewSessions = () => {
    const subscription = supabase
      .channel('chat_sessions')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'chat_sessions'
        },
        () => {
          fetchSessions();
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  };

  const handleSessionClick = (sessionId: string) => {
    setActiveSession(sessionId);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500" />
      </div>
    );
  }

  return (
    <div className="flex h-screen">
      {/* Sessions List */}
      <div className="w-1/4 border-r bg-gray-50 p-4">
        <h2 className="text-lg font-semibold mb-4">Active Sessions</h2>
        <div className="space-y-2">
          {sessions.map((session) => (
            <button
              key={session.id}
              onClick={() => handleSessionClick(session.id)}
              className={`w-full rounded-lg p-4 text-left transition-colors ${
                activeSession === session.id
                  ? 'bg-emerald-100'
                  : 'bg-white hover:bg-gray-100'
              }`}
            >
              <p className="font-medium">{session.user.full_name || session.user.email}</p>
              <p className="text-sm text-gray-500">
                {new Date(session.created_at).toLocaleString()}
              </p>
              <span className={`inline-block px-2 py-1 text-xs rounded-full ${
                session.status === 'active'
                  ? 'bg-green-100 text-green-800'
                  : 'bg-yellow-100 text-yellow-800'
              }`}>
                {session.status}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Chat Window */}
      <div className="flex-1">
        {activeSession ? (
          <ChatWindow
            sessionId={activeSession}
            onClose={() => setActiveSession(null)}
          />
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500">
            Select a session to start chatting
          </div>
        )}
      </div>
    </div>
  );
}