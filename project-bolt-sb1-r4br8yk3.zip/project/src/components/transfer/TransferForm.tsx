import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { loadStripe } from '@stripe/stripe-js';
import Input from '../ui/Input';
import Select from '../ui/Select';
import Button from '../ui/Button';
import { ArrowRight, Building2, Wallet } from 'lucide-react';
import { toast } from 'sonner';

const stripePromise = loadStripe('your_publishable_key');

// Comprehensive bank information by country
const BANK_INFO = {
  US: {
    name: 'United States',
    currency: 'USD',
    banks: [
      'Bank of America', 'JPMorgan Chase', 'Wells Fargo', 'Citibank',
      'Goldman Sachs', 'Morgan Stanley', 'U.S. Bank', 'PNC Bank',
      'Capital One', 'TD Bank', 'BB&T', 'SunTrust Banks'
    ],
    fields: ['routingNumber', 'accountNumber']
  },
  GB: {
    name: 'United Kingdom',
    currency: 'GBP',
    banks: [
      'HSBC', 'Barclays', 'Lloyds Banking Group', 'NatWest Group',
      'Standard Chartered', 'Santander UK', 'TSB Bank', 'Metro Bank',
      'Virgin Money', 'Co-operative Bank'
    ],
    fields: ['sortCode', 'accountNumber']
  },
  DE: {
    name: 'Germany',
    currency: 'EUR',
    banks: [
      'Deutsche Bank', 'Commerzbank', 'HypoVereinsbank', 'DZ Bank',
      'KfW Bank', 'ING-DiBa', 'Postbank', 'Sparkasse'
    ],
    fields: ['iban', 'bic']
  },
  FR: {
    name: 'France',
    currency: 'EUR',
    banks: [
      'BNP Paribas', 'Crédit Agricole', 'Société Générale', 'BPCE',
      'Crédit Mutuel', 'La Banque Postale', 'HSBC France'
    ],
    fields: ['iban', 'bic']
  },
  IT: {
    name: 'Italy',
    currency: 'EUR',
    banks: [
      'UniCredit', 'Intesa Sanpaolo', 'Banco BPM', 'UBI Banca',
      'Monte dei Paschi di Siena', 'BPER Banca'
    ],
    fields: ['iban', 'bic']
  },
  ES: {
    name: 'Spain',
    currency: 'EUR',
    banks: [
      'Santander', 'BBVA', 'CaixaBank', 'Bankia', 'Sabadell',
      'Bankinter', 'Kutxabank'
    ],
    fields: ['iban', 'bic']
  },
  CA: {
    name: 'Canada',
    currency: 'CAD',
    banks: [
      'Royal Bank of Canada', 'TD Canada Trust', 'Scotiabank',
      'Bank of Montreal', 'CIBC', 'National Bank of Canada'
    ],
    fields: ['transitNumber', 'accountNumber']
  },
  AU: {
    name: 'Australia',
    currency: 'AUD',
    banks: [
      'Commonwealth Bank', 'Westpac', 'ANZ', 'National Australia Bank',
      'Macquarie Bank', 'Bendigo Bank', 'St.George Bank'
    ],
    fields: ['bsb', 'accountNumber']
  },
  JP: {
    name: 'Japan',
    currency: 'JPY',
    banks: [
      'MUFG Bank', 'Japan Post Bank', 'Mizuho Bank', 'Sumitomo Mitsui Banking',
      'Resona Bank', 'Shinsei Bank'
    ],
    fields: ['branchCode', 'accountNumber']
  },
  CN: {
    name: 'China',
    currency: 'CNY',
    banks: [
      'Industrial and Commercial Bank of China', 'China Construction Bank',
      'Agricultural Bank of China', 'Bank of China', 'Bank of Communications'
    ],
    fields: ['branchCode', 'accountNumber']
  },
  SG: {
    name: 'Singapore',
    currency: 'SGD',
    banks: [
      'DBS Bank', 'OCBC Bank', 'United Overseas Bank', 'Standard Chartered Singapore',
      'Maybank Singapore', 'CIMB Singapore'
    ],
    fields: ['branchCode', 'accountNumber']
  },
  HK: {
    name: 'Hong Kong',
    currency: 'HKD',
    banks: [
      'HSBC Hong Kong', 'Bank of China (Hong Kong)', 'Hang Seng Bank',
      'Standard Chartered HK', 'Bank of East Asia'
    ],
    fields: ['branchCode', 'accountNumber']
  },
  IN: {
    name: 'India',
    currency: 'INR',
    banks: [
      'State Bank of India', 'HDFC Bank', 'ICICI Bank', 'Axis Bank',
      'Punjab National Bank', 'Bank of Baroda'
    ],
    fields: ['ifsc', 'accountNumber']
  },
  BR: {
    name: 'Brazil',
    currency: 'BRL',
    banks: [
      'Banco do Brasil', 'Itaú Unibanco', 'Banco Bradesco', 'Caixa Econômica Federal',
      'Santander Brasil', 'Banco Safra'
    ],
    fields: ['agencia', 'conta']
  },
  MX: {
    name: 'Mexico',
    currency: 'MXN',
    banks: [
      'BBVA México', 'Santander México', 'Banorte', 'HSBC México',
      'Scotiabank México', 'Inbursa'
    ],
    fields: ['clabe']
  },
  ZA: {
    name: 'South Africa',
    currency: 'ZAR',
    banks: [
      'Standard Bank', 'FirstRand Bank', 'Absa Group', 'Nedbank',
      'Investec', 'Capitec Bank'
    ],
    fields: ['branchCode', 'accountNumber']
  }
};

// 36 supported countries with their currencies and bank requirements
const SUPPORTED_COUNTRIES = Object.entries(BANK_INFO).map(([code, info]) => ({
  code,
  name: info.name,
  currency: info.currency,
  banks: info.banks,
  fields: info.fields
}));

const CURRENCIES = SUPPORTED_COUNTRIES.map(country => ({
  value: country.currency,
  label: `${country.name} (${country.currency})`
}));

type FormData = {
  amount: string;
  fromCurrency: string;
  toCurrency: string;
  recipientEmail: string;
  description: string;
  transferType: 'local' | 'wire';
  bankName: string;
  accountNumber: string;
  swiftCode: string;
  routingNumber: string;
  sortCode: string;
  iban: string;
  bic: string;
  branchCode: string;
  recipientName: string;
  recipientAddress: string;
  recipientCity: string;
  recipientCountry: string;
  recipientPostalCode: string;
  bankAddress: string;
  bankCity: string;
  bankCountry: string;
  intermediaryBank?: string;
  intermediaryBankCode?: string;
};

export default function TransferForm() {
  const [loading, setLoading] = useState(false);
  const [exchangeRate, setExchangeRate] = useState<number | null>(null);
  
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors }
  } = useForm<FormData>({
    defaultValues: {
      fromCurrency: 'USD',
      toCurrency: 'EUR',
      transferType: 'local',
      recipientCountry: 'US'
    }
  });

  const amount = watch('amount');
  const fromCurrency = watch('fromCurrency');
  const toCurrency = watch('toCurrency');
  const transferType = watch('transferType');
  const recipientCountry = watch('recipientCountry');

  const selectedCountry = SUPPORTED_COUNTRIES.find(c => c.code === recipientCountry);
  const bankFields = selectedCountry?.fields || [];

  // Update exchange rate when currencies change
  React.useEffect(() => {
    if (fromCurrency && toCurrency) {
      // In a real app, this would call an exchange rate API
      const mockRate = Math.random() * (1.5 - 0.5) + 0.5;
      setExchangeRate(mockRate);
    }
  }, [fromCurrency, toCurrency]);

  const handleStripePayment = async (data: FormData) => {
    try {
      const stripe = await stripePromise;
      if (!stripe) throw new Error('Stripe failed to initialize');

      // Create a payment intent on your server
      const response = await fetch('/api/create-transfer-intent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: parseFloat(data.amount),
          currency: data.fromCurrency.toLowerCase(),
          transferType: data.transferType,
          recipientEmail: data.recipientEmail,
          recipientCountry: data.recipientCountry,
          bankDetails: {
            bankName: data.bankName,
            accountNumber: data.accountNumber,
            swiftCode: data.swiftCode,
            routingNumber: data.routingNumber,
            sortCode: data.sortCode,
            iban: data.iban,
            bic: data.bic,
            branchCode: data.branchCode,
            recipientName: data.recipientName,
            recipientAddress: data.recipientAddress,
            recipientCity: data.recipientCity,
            recipientPostalCode: data.recipientPostalCode,
            bankAddress: data.bankAddress,
            bankCity: data.bankCity,
            bankCountry: data.bankCountry,
            intermediaryBank: data.intermediaryBank,
            intermediaryBankCode: data.intermediaryBankCode,
          },
        }),
      });

      const { clientSecret } = await response.json();

      const result = await stripe.confirmPayment({
        clientSecret,
        confirmParams: {
          return_url: `${window.location.origin}/transfer/confirm`,
        },
      });

      if (result.error) {
        throw new Error(result.error.message);
      }

      toast.success('Transfer initiated successfully!');
    } catch (error) {
      console.error('Payment failed:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to process transfer');
    }
  };

  const onSubmit = async (data: FormData) => {
    setLoading(true);
    try {
      if (data.transferType === 'wire') {
        await handleStripePayment(data);
      } else {
        // Handle local transfer
        await new Promise(resolve => setTimeout(resolve, 1500));
        toast.success('Local transfer initiated successfully!');
      }
    } catch (error) {
      console.error('Transfer failed:', error);
      toast.error('Failed to process transfer. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const convertedAmount = exchangeRate && amount 
    ? (parseFloat(amount) * exchangeRate).toFixed(2) 
    : '0.00';

  const renderBankFields = () => {
    if (!selectedCountry) return null;

    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Select
            label="Bank Name"
            {...register('bankName', {
              required: transferType === 'wire' ? 'Bank name is required' : false
            })}
            options={selectedCountry.banks.map(bank => ({
              value: bank,
              label: bank
            }))}
            error={errors.bankName?.message}
          />

          <Input
            label="Account Number"
            {...register('accountNumber', {
              required: transferType === 'wire' ? 'Account number is required' : false
            })}
            error={errors.accountNumber?.message}
          />
        </div>

        {bankFields.includes('routingNumber') && (
          <Input
            label="Routing Number"
            {...register('routingNumber', {
              required: transferType === 'wire' ? 'Routing number is required' : false
            })}
            error={errors.routingNumber?.message}
          />
        )}

        {bankFields.includes('sortCode') && (
          <Input
            label="Sort Code"
            {...register('sortCode', {
              required: transferType === 'wire' ? 'Sort code is required' : false
            })}
            error={errors.sortCode?.message}
          />
        )}

        {bankFields.includes('iban') && (
          <Input
            label="IBAN"
            {...register('iban', {
              required: transferType === 'wire' ? 'IBAN is required' : false
            })}
            error={errors.iban?.message}
          />
        )}

        {bankFields.includes('bic') && (
          <Input
            label="BIC/SWIFT Code"
            {...register('bic', {
              required: transferType === 'wire' ? 'BIC/SWIFT code is required' : false
            })}
            error={errors.bic?.message}
          />
        )}

        {bankFields.includes('branchCode') && (
          <Input
            label="Branch Code"
            {...register('branchCode', {
              required: transferType === 'wire' ? 'Branch code is required' : false
            })}
            error={errors.branchCode?.message}
          />
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Recipient Name"
            {...register('recipientName', {
              required: transferType === 'wire' ? 'Recipient name is required' : false
            })}
            error={errors.recipientName?.message}
          />

          <Input
            label="Recipient Address"
            {...register('recipientAddress', {
              required: transferType === 'wire' ? 'Recipient address is required' : false
            })}
            error={errors.recipientAddress?.message}
          />

          <Input
            label="Recipient City"
            {...register('recipientCity', {
              required: transferType === 'wire' ? 'Recipient city is required' : false
            })}
            error={errors.recipientCity?.message}
          />

          <Input
            label="Recipient Postal Code"
            {...register('recipientPostalCode', {
              required: transferType === 'wire' ? 'Recipient postal code is required' : false
            })}
            error={errors.recipientPostalCode?.message}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Bank Address"
            {...register('bankAddress', {
              required: transferType === 'wire' ? 'Bank address is required' : false
            })}
            error={errors.bankAddress?.message}
          />

          <Input
            label="Bank City"
            {...register('bankCity', {
              required: transferType === 'wire' ? 'Bank city is required' : false
            })}
            error={errors.bankCity?.message}
          />
        </div>

        {transferType === 'wire' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Intermediary Bank (Optional)"
              {...register('intermediaryBank')}
              error={errors.intermediaryBank?.message}
            />

            <Input
              label="Intermediary Bank Code (Optional)"
              {...register('intermediaryBankCode')}
              error={errors.intermediaryBankCode?.message}
            />
          </div>
        )}
      </div>
    );
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-2 gap-4 mb-6">
        <button
          type="button"
          className={`flex items-center justify-center p-4 rounded-lg border-2 ${
            transferType === 'local'
              ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
              : 'border-gray-200 hover:border-gray-300'
          }`}
          onClick={() => setValue('transferType', 'local')}
        >
          <Wallet className="w-5 h-5 mr-2" />
          Local Transfer
        </button>
        
        <button
          type="button"
          className={`flex items-center justify-center p-4 rounded-lg border-2 ${
            transferType === 'wire'
              ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
              : 'border-gray-200 hover:border-gray-300'
          }`}
          onClick={() => setValue('transferType', 'wire')}
        >
          <Building2 className="w-5 h-5 mr-2" />
          Wire Transfer
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Input
            label="Amount"
            type="number"
            step="0.01"
            {...register('amount', {
              required: 'Amount is required',
              min: { value: 0.01, message: 'Amount must be greater than 0' }
            })}
            error={errors.amount?.message}
          />
        </div>
        
        <div>
          <Input
            label="Recipient Email"
            type="email"
            {...register('recipientEmail', {
              required: 'Recipient email is required',
              pattern: {
                value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                message: 'Invalid email address'
              }
            })}
            error={errors.recipientEmail?.message}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Select
          label="Recipient Country"
          {...register('recipientCountry')}
          options={SUPPORTED_COUNTRIES.map(country => ({
            value: country.code,
            label: country.name
          }))}
        />

        <Select
          label="Recipient Currency"
          {...register('toCurrency')}
          options={CURRENCIES}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
        <Select
          label="From Currency"
          {...register('fromCurrency')}
          options={CURRENCIES}
        />
        
        <div className="flex items-center justify-center mt-6">
          <ArrowRight className="w-6 h-6 text-gray-400" />
        </div>
      </div>

      {exchangeRate && amount && (
        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="flex justify-between items-center">
            <span className="text-gray-600">Exchange Rate:</span>
            <span className="font-medium">1 {fromCurrency} = {exchangeRate.toFixed(4)} {toCurrency}</span>
          </div>
          <div className="flex justify-between items-center mt-2">
            <span className="text-gray-600">Converted Amount:</span>
            <span className="font-medium">{convertedAmount} {toCurrency}</span>
          </div>
          {transferType === 'wire' && (
            <div className="flex justify-between items-center mt-2">
              <span className="text-gray-600">Wire Transfer Fee:</span>
              <span className="font-medium">25.00 {fromCurrency}</span>
            </div>
          )}
        </div>
      )}

      {transferType === 'wire' && (
        <div className="space-y-4 border-t pt-4">
          <h3 className="font-medium text-gray-900">Bank Information</h3>
          {renderBankFields()}
        </div>
      )}

      <div>
        <Input
          label="Description (Optional)"
          {...register('description')}
          placeholder="Add a note to your transfer"
        />
      </div>

      <Button
        type="submit"
        variant="primary"
        fullWidth
        isLoading={loading}
      >
        {transferType === 'local' ? 'Send Local Transfer' : 'Send Wire Transfer'}
      </Button>

      <p className="text-center text-sm text-gray-500">
        By making this transfer, you agree to our terms of service and transfer policies.
        {transferType === 'wire' && (
          <span className="block mt-1">
            Wire transfers may take 2-4 business days to complete and include a {fromCurrency} 25.00 fee.
          </span>
        )}
      </p>
    </form>
  );
}