import React from 'react';
import { PAYMENT_GATEWAYS, PaymentGatewayConfig } from '../../services/PaymentService';

interface PaymentMethodSelectorProps {
  currency: string;
  country: string;
  onSelect: (gateway: PaymentGatewayConfig) => void;
  selectedGateway?: PaymentGatewayConfig;
}

export default function PaymentMethodSelector({
  currency,
  country,
  onSelect,
  selectedGateway
}: PaymentMethodSelectorProps) {
  const availableGateways = PAYMENT_GATEWAYS.filter(gateway => 
    gateway.currencies.includes(currency) && 
    gateway.countries.includes(country)
  );

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium text-gray-900">Select Payment Method</h3>
      <div className="grid grid-cols-2 gap-4">
        {availableGateways.map((gateway) => (
          <button
            key={gateway.name}
            onClick={() => onSelect(gateway)}
            className={`
              flex items-center justify-center p-4 rounded-lg border-2 transition-colors
              ${selectedGateway?.name === gateway.name
                ? 'border-emerald-500 bg-emerald-50'
                : 'border-gray-200 hover:border-emerald-200 hover:bg-emerald-50'
              }
            `}
          >
            <img 
              src={gateway.icon} 
              alt={gateway.name} 
              className="h-8 object-contain"
            />
          </button>
        ))}
      </div>
    </div>
  );
}