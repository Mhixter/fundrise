import React from 'react';
import { PayPalButtons } from '@paypal/react-paypal-js';
import { usePaystackPayment } from 'react-paystack';
import { useFlutterwave } from 'flutterwave-react-v3';
import { PaymentGatewayConfig, PaymentData } from '../../services/PaymentService';

interface PaymentProcessorProps {
  gateway: PaymentGatewayConfig;
  paymentData: PaymentData;
  onSuccess: (response: any) => void;
  onError: (error: any) => void;
}

export default function PaymentProcessor({
  gateway,
  paymentData,
  onSuccess,
  onError
}: PaymentProcessorProps) {
  const handlePayPalPayment = async () => {
    // PayPal payment handling
  };

  const handleStripePayment = async () => {
    // Stripe payment handling
  };

  const handlePaystackPayment = usePaystackPayment({
    email: paymentData.donorEmail,
    amount: paymentData.amount * 100,
    publicKey: import.meta.env.VITE_PAYSTACK_PUBLIC_KEY,
    currency: paymentData.currency,
  });

  const handleFlutterwavePayment = useFlutterwave({
    public_key: import.meta.env.VITE_FLUTTERWAVE_PUBLIC_KEY,
    tx_ref: Date.now().toString(),
    amount: paymentData.amount,
    currency: paymentData.currency,
    payment_options: 'card,mobilemoney,ussd',
    customer: {
      email: paymentData.donorEmail,
      name: paymentData.donorName,
    },
    customizations: {
      title: 'GoHelpThem Donation',
      description: paymentData.description,
    },
  });

  switch (gateway.name) {
    case 'paypal':
      return (
        <PayPalButtons
          createOrder={(data, actions) => {
            return actions.order.create({
              purchase_units: [{
                amount: {
                  value: paymentData.amount.toString(),
                  currency_code: paymentData.currency
                }
              }]
            });
          }}
          onApprove={(data, actions) => {
            return actions.order!.capture().then(onSuccess);
          }}
          onError={onError}
        />
      );

    case 'stripe':
      return (
        <button
          onClick={handleStripePayment}
          className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700"
        >
          Pay with Stripe
        </button>
      );

    case 'paystack':
      return (
        <button
          onClick={() => handlePaystackPayment()}
          className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700"
        >
          Pay with Paystack
        </button>
      );

    case 'flutterwave':
      return (
        <button
          onClick={() => handleFlutterwavePayment()}
          className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700"
        >
          Pay with Flutterwave
        </button>
      );

    default:
      return null;
  }
}