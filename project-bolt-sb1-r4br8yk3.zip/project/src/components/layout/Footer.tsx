import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Mail, Github, Twitter, Facebook, Instagram } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-200">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div className="space-y-4">
            <div className="flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#10B981" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M5.3 18a7 7 0 1 1 13.4 0"></path>
                <path d="m9 6.8 3 2.5 3-2.5"></path>
                <path d="M15 9.8v10.5"></path>
                <path d="M9 11.8v8.5"></path>
                <path d="M9 20.3h6"></path>
              </svg>
              <span className="ml-2 text-xl font-bold text-emerald-600">FundRise</span>
            </div>
            <p className="text-sm text-gray-600">
              Making dreams come true through collective support.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-500 hover:text-gray-700">
                <Facebook size={20} />
                <span className="sr-only">Facebook</span>
              </a>
              <a href="#" className="text-gray-500 hover:text-gray-700">
                <Twitter size={20} />
                <span className="sr-only">Twitter</span>
              </a>
              <a href="#" className="text-gray-500 hover:text-gray-700">
                <Instagram size={20} />
                <span className="sr-only">Instagram</span>
              </a>
              <a href="#" className="text-gray-500 hover:text-gray-700">
                <Github size={20} />
                <span className="sr-only">GitHub</span>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-gray-900">For Fundraisers</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <Link to="/start" className="text-sm text-gray-600 hover:text-emerald-600">
                  How to Start a Campaign
                </Link>
              </li>
              <li>
                <Link to="/success-stories" className="text-sm text-gray-600 hover:text-emerald-600">
                  Success Stories
                </Link>
              </li>
              <li>
                <Link to="/tips" className="text-sm text-gray-600 hover:text-emerald-600">
                  Campaign Tips
                </Link>
              </li>
              <li>
                <Link to="/fees" className="text-sm text-gray-600 hover:text-emerald-600">
                  Fees & Pricing
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-gray-900">For Donors</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <Link to="/why-donate" className="text-sm text-gray-600 hover:text-emerald-600">
                  Why Donate
                </Link>
              </li>
              <li>
                <Link to="/trust-safety" className="text-sm text-gray-600 hover:text-emerald-600">
                  Trust & Safety
                </Link>
              </li>
              <li>
                <Link to="/donation-faqs" className="text-sm text-gray-600 hover:text-emerald-600">
                  Donation FAQs
                </Link>
              </li>
              <li>
                <Link to="/tax-deductions" className="text-sm text-gray-600 hover:text-emerald-600">
                  Tax Deductions
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-gray-900">Company</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <Link to="/about" className="text-sm text-gray-600 hover:text-emerald-600">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/careers" className="text-sm text-gray-600 hover:text-emerald-600">
                  Careers
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-sm text-gray-600 hover:text-emerald-600">
                  Contact
                </Link>
              </li>
              <li>
                <Link to="/help" className="text-sm text-gray-600 hover:text-emerald-600">
                  Help Center
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 border-t border-gray-200 pt-8">
          <div className="flex flex-col items-center justify-between md:flex-row">
            <p className="text-base text-gray-500">
              &copy; {new Date().getFullYear()} FundRise. All rights reserved.
            </p>
            <div className="mt-4 flex space-x-6 md:mt-0">
              <Link to="/privacy" className="text-sm text-gray-600 hover:text-emerald-600">
                Privacy Policy
              </Link>
              <Link to="/terms" className="text-sm text-gray-600 hover:text-emerald-600">
                Terms of Service
              </Link>
              <Link to="/legal" className="text-sm text-gray-600 hover:text-emerald-600">
                Legal
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}