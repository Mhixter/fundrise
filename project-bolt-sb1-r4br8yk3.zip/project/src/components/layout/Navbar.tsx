import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, X, Search, ChevronDown } from 'lucide-react';
import Button from '../ui/Button';
import { useAuth } from '../../context/AuthContext';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [showDonateMenu, setShowDonateMenu] = useState(false);
  const [showFundraiseMenu, setShowFundraiseMenu] = useState(false);
  const [showAboutMenu, setShowAboutMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const auth = useAuth();
  const navigate = useNavigate();

  // Early return if auth context is not available
  if (!auth) {
    return null;
  }

  const { user } = auth;

  const handleNavigate = (path: string) => {
    navigate(path);
    setIsOpen(false);
    setShowDonateMenu(false);
    setShowFundraiseMenu(false);
    setShowAboutMenu(false);
    setShowUserMenu(false);
  };

  return (
    <nav className="bg-white shadow-sm">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#10B981" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M5.3 18a7 7 0 1 1 13.4 0"></path>
              <path d="m9 6.8 3 2.5 3-2.5"></path>
              <path d="M15 9.8v10.5"></path>
              <path d="M9 11.8v8.5"></path>
              <path d="M9 20.3h6"></path>
            </svg>
            <span className="ml-2 text-xl font-bold text-emerald-600">FundRise</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search"
                className="pl-10 pr-4 py-2 rounded-full border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent text-sm"
              />
            </div>

            {/* Donate Button with Dropdown */}
            <div className="relative group">
              <button 
                className="flex items-center space-x-1 text-gray-700 hover:text-emerald-600 font-medium"
                onMouseEnter={() => setShowDonateMenu(true)}
                onMouseLeave={() => setShowDonateMenu(false)}
              >
                <span>Donate</span>
                <ChevronDown className="h-4 w-4 transition-transform group-hover:rotate-180" />
              </button>
              {showDonateMenu && (
                <div 
                  className="absolute top-full left-0 mt-1 w-56 bg-white rounded-lg shadow-lg py-2 z-50 border border-gray-100"
                  onMouseEnter={() => setShowDonateMenu(true)}
                  onMouseLeave={() => setShowDonateMenu(false)}
                >
                  <Link to="/campaigns" className="block px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600">
                    Browse All Campaigns
                  </Link>
                  <Link to="/campaigns/category/medical" className="block px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600">
                    Medical Fundraising
                  </Link>
                  <Link to="/campaigns/category/emergency" className="block px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600">
                    Emergency Relief
                  </Link>
                  <Link to="/campaigns/category/education" className="block px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600">
                    Education
                  </Link>
                  <Link to="/campaigns/category/nonprofit" className="block px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600">
                    Nonprofit & Charity
                  </Link>
                </div>
              )}
            </div>

            {/* Fundraise Button with Dropdown */}
            <div className="relative group">
              <button 
                className="flex items-center space-x-1 text-gray-700 hover:text-emerald-600 font-medium"
                onMouseEnter={() => setShowFundraiseMenu(true)}
                onMouseLeave={() => setShowFundraiseMenu(false)}
              >
                <span>Fundraise</span>
                <ChevronDown className="h-4 w-4 transition-transform group-hover:rotate-180" />
              </button>
              {showFundraiseMenu && (
                <div 
                  className="absolute top-full left-0 mt-1 w-56 bg-white rounded-lg shadow-lg py-2 z-50 border border-gray-100"
                  onMouseEnter={() => setShowFundraiseMenu(true)}
                  onMouseLeave={() => setShowFundraiseMenu(false)}
                >
                  <Link to="/create-campaign" className="block px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600">
                    Start a Campaign
                  </Link>
                  <Link to="/fundraising-tips" className="block px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600">
                    Fundraising Tips
                  </Link>
                  <Link to="/success-stories" className="block px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600">
                    Success Stories
                  </Link>
                  <Link to="/fundraising-tools" className="block px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600">
                    Fundraising Tools
                  </Link>
                  <Link to="/team-fundraising" className="block px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600">
                    Team Fundraising
                  </Link>
                </div>
              )}
            </div>

            {/* About Button with Dropdown */}
            <div className="relative group">
              <button 
                className="flex items-center space-x-1 text-gray-700 hover:text-emerald-600 font-medium"
                onMouseEnter={() => setShowAboutMenu(true)}
                onMouseLeave={() => setShowAboutMenu(false)}
              >
                <span>About</span>
                <ChevronDown className="h-4 w-4 transition-transform group-hover:rotate-180" />
              </button>
              {showAboutMenu && (
                <div 
                  className="absolute top-full right-0 mt-1 w-56 bg-white rounded-lg shadow-lg py-2 z-50 border border-gray-100"
                  onMouseEnter={() => setShowAboutMenu(true)}
                  onMouseLeave={() => setShowAboutMenu(false)}
                >
                  <Link to="/about" className="block px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600">
                    About Us
                  </Link>
                  <Link to="/how-it-works" className="block px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600">
                    How It Works
                  </Link>
                  <Link to="/pricing" className="block px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600">
                    Pricing & Fees
                  </Link>
                  <Link to="/trust-safety" className="block px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600">
                    Trust & Safety
                  </Link>
                  <Link to="/contact" className="block px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600">
                    Contact Us
                  </Link>
                </div>
              )}
            </div>
          </div>

          {/* Right side buttons/profile */}
          <div className="hidden md:flex items-center space-x-4">
            {!user ? (
              <div className="flex items-center space-x-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handleNavigate('/login')}
                >
                  Log in
                </Button>
                <Button 
                  variant="primary" 
                  size="sm"
                  onClick={() => handleNavigate('/signup')}
                >
                  Sign up
                </Button>
              </div>
            ) : (
              <div className="flex items-center space-x-4">
                <Link to="/create-campaign">
                  <Button variant="primary" size="sm">
                    Start a Campaign
                  </Button>
                </Link>
                <div className="relative">
                  <button
                    className="flex items-center space-x-2"
                    onClick={() => setShowUserMenu(!showUserMenu)}
                  >
                    <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
                      {user.avatar_url ? (
                        <img
                          src={user.avatar_url}
                          alt={user.full_name || 'User'}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <span className="text-sm font-medium text-gray-600">
                          {(user.full_name || 'User').charAt(0)}
                        </span>
                      )}
                    </div>
                  </button>
                  {showUserMenu && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-50 border border-gray-100">
                      <Link to="/dashboard" className="block px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600">
                        Dashboard
                      </Link>
                      <Link to="/settings" className="block px-4 py-2 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-600">
                        Settings
                      </Link>
                      <button
                        onClick={() => auth.signOut()}
                        className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50"
                      >
                        Sign out
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-700 hover:text-emerald-600 hover:bg-emerald-50"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={`md:hidden ${isOpen ? 'block' : 'hidden'}`}>
        <div className="px-2 pt-2 pb-3 space-y-1">
          <div className="px-3 py-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search"
                className="w-full pl-10 pr-4 py-2 rounded-full border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent text-sm"
              />
            </div>
          </div>

          <button
            onClick={() => setShowDonateMenu(!showDonateMenu)}
            className="w-full flex items-center justify-between px-3 py-2 text-base font-medium text-gray-700 hover:text-emerald-600 hover:bg-emerald-50 rounded-md"
          >
            <span>Donate</span>
            <ChevronDown className={`h-4 w-4 transition-transform ${showDonateMenu ? 'rotate-180' : ''}`} />
          </button>
          {showDonateMenu && (
            <div className="pl-4">
              <Link to="/campaigns" className="block px-3 py-2 text-base text-gray-700 hover:text-emerald-600">
                Browse All Campaigns
              </Link>
              <Link to="/campaigns/category/medical" className="block px-3 py-2 text-base text-gray-700 hover:text-emerald-600">
                Medical Fundraising
              </Link>
              <Link to="/campaigns/category/emergency" className="block px-3 py-2 text-base text-gray-700 hover:text-emerald-600">
                Emergency Relief
              </Link>
              <Link to="/campaigns/category/education" className="block px-3 py-2 text-base text-gray-700 hover:text-emerald-600">
                Education
              </Link>
              <Link to="/campaigns/category/nonprofit" className="block px-3 py-2 text-base text-gray-700 hover:text-emerald-600">
                Nonprofit & Charity
              </Link>
            </div>
          )}

          <button
            onClick={() => setShowFundraiseMenu(!showFundraiseMenu)}
            className="w-full flex items-center justify-between px-3 py-2 text-base font-medium text-gray-700 hover:text-emerald-600 hover:bg-emerald-50 rounded-md"
          >
            <span>Fundraise</span>
            <ChevronDown className={`h-4 w-4 transition-transform ${showFundraiseMenu ? 'rotate-180' : ''}`} />
          </button>
          {showFundraiseMenu && (
            <div className="pl-4">
              <Link to="/create-campaign" className="block px-3 py-2 text-base text-gray-700 hover:text-emerald-600">
                Start a Campaign
              </Link>
              <Link to="/fundraising-tips" className="block px-3 py-2 text-base text-gray-700 hover:text-emerald-600">
                Fundraising Tips
              </Link>
              <Link to="/success-stories" className="block px-3 py-2 text-base text-gray-700 hover:text-emerald-600">
                Success Stories
              </Link>
            </div>
          )}

          <button
            onClick={() => setShowAboutMenu(!showAboutMenu)}
            className="w-full flex items-center justify-between px-3 py-2 text-base font-medium text-gray-700 hover:text-emerald-600 hover:bg-emerald-50 rounded-md"
          >
            <span>About</span>
            <ChevronDown className={`h-4 w-4 transition-transform ${showAboutMenu ? 'rotate-180' : ''}`} />
          </button>
          {showAboutMenu && (
            <div className="pl-4">
              <Link to="/about" className="block px-3 py-2 text-base text-gray-700 hover:text-emerald-600">
                About Us
              </Link>
              <Link to="/how-it-works" className="block px-3 py-2 text-base text-gray-700 hover:text-emerald-600">
                How It Works
              </Link>
              <Link to="/contact" className="block px-3 py-2 text-base text-gray-700 hover:text-emerald-600">
                Contact Us
              </Link>
            </div>
          )}

          {user ? (
            <div className="px-3 py-2 space-y-2">
              <Link to="/dashboard" className="block px-3 py-2 text-base font-medium text-gray-700 hover:text-emerald-600">
                Dashboard
              </Link>
              <Link to="/settings" className="block px-3 py-2 text-base font-medium text-gray-700 hover:text-emerald-600">
                Settings
              </Link>
              <button
                onClick={() => auth.signOut()}
                className="block w-full text-left px-3 py-2 text-base font-medium text-red-600 hover:text-red-700"
              >
                Sign out
              </button>
            </div>
          ) : (
            <div className="px-3 py-2 space-y-2">
              <Button 
                variant="outline"
                fullWidth
                onClick={() => handleNavigate('/login')}
              >
                Log in
              </Button>
              <Button 
                variant="primary"
                fullWidth
                onClick={() => handleNavigate('/signup')}
              >
                Sign up
              </Button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}