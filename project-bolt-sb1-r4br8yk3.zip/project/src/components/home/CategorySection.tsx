import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Heart, Briefcase, Paintbrush, GraduationCap, 
  Stethoscope, User, Lightbulb, MoreHorizontal
} from 'lucide-react';

const categories = [
  { id: 'charity', name: 'Charity & Causes', icon: Heart, color: 'bg-red-100 text-red-600' },
  { id: 'business', name: 'Business', icon: Briefcase, color: 'bg-blue-100 text-blue-600' },
  { id: 'creative', name: 'Creative & Arts', icon: Paintbrush, color: 'bg-purple-100 text-purple-600' },
  { id: 'education', name: 'Education', icon: GraduationCap, color: 'bg-yellow-100 text-yellow-600' },
  { id: 'medical', name: 'Medical & Health', icon: Stethoscope, color: 'bg-green-100 text-green-600' },
  { id: 'personal', name: 'Personal Needs', icon: User, color: 'bg-orange-100 text-orange-600' },
  { id: 'technology', name: 'Technology', icon: Lightbulb, color: 'bg-indigo-100 text-indigo-600' },
  { id: 'other', name: 'Other', icon: MoreHorizontal, color: 'bg-gray-100 text-gray-600' }
];

export default function CategorySection() {
  return (
    <section className="py-12 bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">Find Campaigns by Category</h2>
          <p className="mt-3 text-xl text-gray-500 sm:mx-auto sm:mt-4 max-w-2xl">
            Discover fundraising campaigns across different categories that match your interests
          </p>
        </div>
        
        <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-4">
          {categories.map((category) => {
            const Icon = category.icon;
            
            return (
              <Link
                key={category.id}
                to={`/campaigns?category=${category.id}`}
                className="group flex flex-col items-center justify-center rounded-lg border border-gray-200 p-6 text-center hover:border-emerald-500 hover:shadow-md transition-all"
              >
                <div className={`rounded-full p-3 ${category.color}`}>
                  <Icon size={24} />
                </div>
                <h3 className="mt-3 font-medium text-gray-900 group-hover:text-emerald-600">
                  {category.name}
                </h3>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}