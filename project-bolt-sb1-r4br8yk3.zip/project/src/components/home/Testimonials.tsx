import React from 'react';

const testimonials = [
  {
    quote: "FundRise helped me raise enough money for my mom's medical treatment in just two weeks. I'm forever grateful for this platform and its community.",
    author: "Sarah Johnson",
    title: "Medical Campaign",
    image: "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750"
  },
  {
    quote: "As a small business owner, I was struggling to find funding. Thanks to FundRise, I raised enough capital to expand my store and hire two new employees.",
    author: "Michael Chen",
    title: "Business Campaign",
    image: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750"
  },
  {
    quote: "My art exhibition would never have happened without the support I received through FundRise. The platform made it so easy to share my vision and get funded.",
    author: "Priya Patel",
    title: "Creative Campaign",
    image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750"
  }
];

export default function Testimonials() {
  return (
    <section className="bg-white py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">Success Stories</h2>
          <p className="mt-3 text-xl text-gray-500 sm:mx-auto sm:mt-4 max-w-2xl">
            Hear from people who have successfully raised funds and achieved their goals with FundRise
          </p>
        </div>
        
        <div className="mt-12 grid gap-8 md:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index} 
              className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm transition-all duration-300 hover:shadow-md"
            >
              <div className="p-6">
                <div className="flex justify-center">
                  <div className="relative h-16 w-16 overflow-hidden rounded-full">
                    <img 
                      src={testimonial.image} 
                      alt={testimonial.author}
                      className="h-full w-full object-cover" 
                    />
                  </div>
                </div>
                
                <blockquote className="mt-4">
                  <p className="text-center text-gray-700 before:content-[''] after:content-['']">
                    {testimonial.quote}
                  </p>
                </blockquote>
                
                <div className="mt-4 text-center">
                  <p className="font-medium text-gray-900">{testimonial.author}</p>
                  <p className="text-sm text-gray-500">{testimonial.title}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}