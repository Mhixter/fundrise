import React from 'react';
import { FileEdit, Gift, BarChart } from 'lucide-react';
import { Link } from 'react-router-dom';
import Button from '../ui/Button';

export default function HowItWorks() {
  const steps = [
    {
      id: 1,
      title: 'Create Your Campaign',
      description: 'Set up your fundraising campaign in minutes. Add photos, tell your story, and set your goal.',
      icon: FileEdit,
      color: 'bg-emerald-100 text-emerald-600'
    },
    {
      id: 2,
      title: 'Share & Receive Donations',
      description: 'Share your campaign on social media and receive donations from supporters around the world.',
      icon: Gift,
      color: 'bg-blue-100 text-blue-600'
    },
    {
      id: 3,
      title: 'Track Progress & Update',
      description: 'Monitor your fundraising progress and keep supporters updated with campaign milestones.',
      icon: BarChart,
      color: 'bg-purple-100 text-purple-600'
    }
  ];

  return (
    <section className="py-12 bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">How FundRise Works</h2>
          <p className="mt-3 text-xl text-gray-500 sm:mx-auto sm:mt-4 max-w-2xl">
            Raising funds has never been easier. Get started in just a few simple steps.
          </p>
        </div>

        <div className="mt-12 lg:mt-16">
          <div className="grid gap-8 lg:grid-cols-3">
            {steps.map((step) => {
              const Icon = step.icon;
              
              return (
                <div key={step.id} className="relative">
                  <div className="flex flex-col items-center text-center">
                    <div className={`mb-4 rounded-full p-3 ${step.color}`}>
                      <Icon size={28} />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900">{step.title}</h3>
                    <p className="mt-2 text-gray-600">{step.description}</p>
                  </div>
                  
                  {step.id < steps.length && (
                    <div className="absolute top-12 right-0 hidden lg:block w-10 h-0.5 bg-gray-200 transform translate-x-1/2">
                      <div className="absolute -right-1.5 -top-1.5 h-4 w-4 rounded-full border border-gray-200 bg-white" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          
          <div className="mt-12 text-center">
            <Link to="/how-it-works">
              <Button variant="outline">
                Learn More About Our Process
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}