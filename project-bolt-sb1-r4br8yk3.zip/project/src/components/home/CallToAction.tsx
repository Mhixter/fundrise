import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../ui/Button';

export default function CallToAction() {
  return (
    <section className="bg-emerald-700">
      <div className="mx-auto max-w-7xl py-12 px-4 sm:px-6 lg:flex lg:items-center lg:justify-between lg:px-8 lg:py-16">
        <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
          <span className="block">Ready to start fundraising?</span>
          <span className="block text-emerald-200">Create your campaign in minutes.</span>
        </h2>
        <div className="mt-8 flex flex-col space-y-4 sm:flex-row sm:space-x-4 sm:space-y-0 lg:mt-0 lg:flex-shrink-0">
          <Link to="/create-campaign">
            <Button 
              variant="primary" 
              size="lg" 
              className="bg-white text-emerald-700 hover:bg-emerald-50"
            >
              Start a Campaign
            </Button>
          </Link>
          <Link to="/how-it-works">
            <Button 
              variant="outline" 
              size="lg" 
              className="border-white text-white hover:bg-emerald-800"
            >
              Learn More
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}