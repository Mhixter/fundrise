import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../ui/Button';

export default function HeroSection() {
  const navigate = useNavigate();
  
  return (
    <div className="relative bg-white">
      <div className="absolute inset-0 overflow-hidden">
        <img
          src="https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=1600"
          alt="People collaborating"
          className="h-full w-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-900/90 to-emerald-600/60 mix-blend-multiply" />
      </div>
      
      <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 sm:py-32 lg:px-8">
        <div className="max-w-2xl">
          <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl lg:text-6xl">
            <span className="block">Fund Your Dreams.</span>
            <span className="block">Support Others.</span>
          </h1>
          <p className="mt-6 max-w-xl text-xl text-emerald-100">
            FundRise makes it easy to raise money for personal causes, creative projects, and business ventures. Start a campaign today or support others on their journey.
          </p>
          <div className="mt-10 flex flex-col space-y-4 sm:flex-row sm:space-x-4 sm:space-y-0">
            <Button
              variant="primary"
              size="lg"
              onClick={() => navigate('/create-campaign')}
              className="bg-white text-emerald-600 hover:bg-emerald-50"
            >
              Start a Campaign
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={() => navigate('/campaigns')}
              className="border-white text-white hover:bg-white/10"
            >
              Explore Campaigns
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}