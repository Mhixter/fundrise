import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { CreditCard, Gift, Heart } from 'lucide-react';
import Input from '../ui/Input';
import TextArea from '../ui/TextArea';
import Button from '../ui/Button';
import { Campaign } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import { toast } from 'sonner';

type DonationFormProps = {
  campaign: Campaign;
  onSuccess: () => void;
};

type FormData = {
  amount: string;
  firstName: string;
  lastName: string;
  email: string;
  message: string;
  isAnonymous: boolean;
  isDedication: boolean;
  dedicationType: 'in_memory' | 'in_honor';
  dedicationName: string;
  notifyEmail: string;
};

const SUGGESTED_AMOUNTS = [10, 25, 50, 100, 250, 500];
const PLATFORM_FEE_PERCENTAGE = 0.02; // 2% platform fee

export default function DonationForm({ campaign, onSuccess }: DonationFormProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [customAmount, setCustomAmount] = useState(false);
  const [selectedAmount, setSelectedAmount] = useState<number>(25);

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors }
  } = useForm<FormData>({
    defaultValues: {
      amount: '25',
      isAnonymous: false,
      isDedication: false,
    }
  });

  const isDedication = watch('isDedication');
  const dedicationType = watch('dedicationType');

  const handleAmountSelect = (amount: number) => {
    setCustomAmount(false);
    setSelectedAmount(amount);
    setValue('amount', amount.toString());
  };

  const onSubmit = async (data: FormData) => {
    setLoading(true);

    try {
      const donationAmount = parseFloat(data.amount);
      const platformFee = donationAmount * PLATFORM_FEE_PERCENTAGE;
      const netAmount = donationAmount - platformFee;

      // Create donation record
      const { error: donationError } = await supabase.from('donations').insert({
        campaign_id: campaign.id,
        user_id: user?.id,
        amount: donationAmount,
        currency: campaign.currency,
        message: data.message,
        is_anonymous: data.isAnonymous,
        platform_fee: platformFee,
        net_amount: netAmount,
        donor_info: {
          first_name: data.firstName,
          last_name: data.lastName,
          email: data.email,
          dedication: data.isDedication ? {
            type: data.dedicationType,
            name: data.dedicationName,
            notify_email: data.notifyEmail
          } : null
        }
      });

      if (donationError) throw donationError;

      // Update campaign amount
      const { error: campaignError } = await supabase
        .from('campaigns')
        .update({ 
          current_amount: campaign.current_amount + netAmount 
        })
        .eq('id', campaign.id);

      if (campaignError) throw campaignError;

      toast.success('Thank you for your donation!');
      onSuccess();
    } catch (error) {
      console.error('Error processing donation:', error);
      toast.error('Failed to process donation. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Select Amount ({campaign.currency})
        </label>
        <div className="grid grid-cols-3 gap-2 mb-3">
          {SUGGESTED_AMOUNTS.map((amount) => (
            <button
              key={amount}
              type="button"
              className={`
                py-3 px-4 rounded-lg border-2 font-medium text-center transition-colors
                ${selectedAmount === amount && !customAmount
                  ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                  : 'border-gray-200 hover:border-emerald-200 hover:bg-emerald-50'
                }
              `}
              onClick={() => handleAmountSelect(amount)}
            >
              {campaign.currency} {amount}
            </button>
          ))}
        </div>
        <button
          type="button"
          className={`
            w-full py-3 px-4 rounded-lg border-2 font-medium text-center mb-4 transition-colors
            ${customAmount
              ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
              : 'border-gray-200 hover:border-emerald-200 hover:bg-emerald-50'
            }
          `}
          onClick={() => {
            setCustomAmount(true);
            setSelectedAmount(0);
          }}
        >
          Custom Amount
        </button>
        {customAmount && (
          <Input
            type="number"
            min="1"
            step="0.01"
            {...register('amount', {
              required: 'Amount is required',
              min: { value: 1, message: 'Minimum donation is 1' }
            })}
            error={errors.amount?.message}
          />
        )}
        <p className="text-sm text-gray-500 mt-2">
          A 2% platform fee will be deducted to support our operations.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Input
          label="First Name"
          {...register('firstName', { required: 'First name is required' })}
          error={errors.firstName?.message}
        />
        <Input
          label="Last Name"
          {...register('lastName', { required: 'Last name is required' })}
          error={errors.lastName?.message}
        />
      </div>

      <Input
        label="Email"
        type="email"
        {...register('email', {
          required: 'Email is required',
          pattern: {
            value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
            message: 'Invalid email address'
          }
        })}
        error={errors.email?.message}
      />

      <div className="space-y-4 border-t border-b py-4">
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            className="h-4 w-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
            {...register('isDedication')}
          />
          <span className="text-sm text-gray-700">Dedicate this donation</span>
        </label>

        {isDedication && (
          <div className="pl-6 space-y-4">
            <div className="flex space-x-4">
              <label className="flex items-center space-x-2">
                <input
                  type="radio"
                  value="in_memory"
                  className="h-4 w-4 border-gray-300 text-emerald-600 focus:ring-emerald-500"
                  {...register('dedicationType')}
                />
                <span className="text-sm text-gray-700">In Memory</span>
              </label>
              <label className="flex items-center space-x-2">
                <input
                  type="radio"
                  value="in_honor"
                  className="h-4 w-4 border-gray-300 text-emerald-600 focus:ring-emerald-500"
                  {...register('dedicationType')}
                />
                <span className="text-sm text-gray-700">In Honor</span>
              </label>
            </div>

            <Input
              label={`${dedicationType === 'in_memory' ? 'In memory of' : 'In honor of'}`}
              {...register('dedicationName', {
                required: isDedication ? 'Name is required' : false
              })}
              error={errors.dedicationName?.message}
            />

            <Input
              label="Email address to notify (optional)"
              type="email"
              {...register('notifyEmail', {
                pattern: {
                  value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                  message: 'Invalid email address'
                }
              })}
              error={errors.notifyEmail?.message}
            />
          </div>
        )}
      </div>

      <TextArea
        label="Leave a Message (Optional)"
        placeholder="Share a message of support..."
        {...register('message')}
      />

      <div className="space-y-4">
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            className="h-4 w-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
            {...register('isAnonymous')}
          />
          <span className="text-sm text-gray-700">Make this donation anonymous</span>
        </label>
      </div>

      <div className="rounded-lg bg-gray-50 p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-600">Donation Amount</span>
          <span className="text-lg font-semibold">
            {campaign.currency} {watch('amount') || '0'}
          </span>
        </div>
        <div className="flex items-center justify-between text-sm text-gray-500">
          <span>Platform Fee (2%)</span>
          <span>
            {campaign.currency} {((parseFloat(watch('amount') || '0') * PLATFORM_FEE_PERCENTAGE)).toFixed(2)}
          </span>
        </div>
        <div className="flex items-center justify-between mt-2 pt-2 border-t">
          <span className="font-medium">Net Amount to Campaign</span>
          <span className="text-lg font-semibold text-emerald-600">
            {campaign.currency} {(parseFloat(watch('amount') || '0') * (1 - PLATFORM_FEE_PERCENTAGE)).toFixed(2)}
          </span>
        </div>
      </div>

      <div className="space-y-4">
        <Button
          type="submit"
          variant="primary"
          fullWidth
          isLoading={loading}
          className="py-3"
        >
          <CreditCard className="w-5 h-5 mr-2" />
          Complete Donation
        </Button>

        <div className="flex justify-center space-x-4">
          <img src="/visa.svg" alt="Visa" className="h-8" />
          <img src="/mastercard.svg" alt="Mastercard" className="h-8" />
          <img src="/amex.svg" alt="American Express" className="h-8" />
          <img src="/paypal.svg" alt="PayPal" className="h-8" />
        </div>

        <p className="text-center text-xs text-gray-500">
          By donating, you agree to our Terms of Service and Privacy Policy.
          Your donation is secure and encrypted.
        </p>
      </div>
    </form>
  );
}