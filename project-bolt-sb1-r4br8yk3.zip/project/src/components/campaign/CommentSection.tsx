import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { User, Clock } from 'lucide-react';
import Button from '../ui/Button';
import TextArea from '../ui/TextArea';
import { Comment } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import { formatDate } from '../../utils/helpers';
import { toast } from 'sonner';

interface CommentSectionProps {
  campaignId: string;
}

type FormData = {
  content: string;
};

export default function CommentSection({ campaignId }: CommentSectionProps) {
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const { user } = useAuth();
  
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm<FormData>();

  useEffect(() => {
    fetchComments();
  }, [campaignId]);

  const fetchComments = async () => {
    try {
      const { data, error } = await supabase
        .from('comments')
        .select(`
          id,
          campaign_id,
          user_id,
          content,
          created_at,
          updated_at,
          author:profiles(full_name, avatar_url)
        `)
        .eq('campaign_id', campaignId)
        .order('created_at', { ascending: false });

      if (error) {
        throw error;
      }

      setComments(data || []);
    } catch (error) {
      console.error('Error fetching comments:', error);
      toast.error('Failed to load comments');
    } finally {
      setLoading(false);
    }
  };

  const onSubmit = async (data: FormData) => {
    if (!user) {
      toast.error('You must be logged in to comment');
      return;
    }

    setSubmitting(true);

    try {
      const { error } = await supabase
        .from('comments')
        .insert({
          campaign_id: campaignId,
          user_id: user.id,
          content: data.content
        });

      if (error) {
        throw error;
      }

      toast.success('Comment added successfully');
      reset();
      fetchComments();
    } catch (error) {
      console.error('Error adding comment:', error);
      toast.error('Failed to add comment');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="animate-pulse space-y-4">
        <div className="h-10 w-1/4 rounded bg-gray-300" />
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="rounded-md border border-gray-200 p-4">
              <div className="flex items-center space-x-2">
                <div className="h-10 w-10 rounded-full bg-gray-300" />
                <div className="space-y-1">
                  <div className="h-4 w-24 rounded bg-gray-300" />
                  <div className="h-3 w-16 rounded bg-gray-300" />
                </div>
              </div>
              <div className="mt-3 space-y-2">
                <div className="h-4 w-full rounded bg-gray-300" />
                <div className="h-4 w-3/4 rounded bg-gray-300" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h3 className="text-xl font-semibold text-gray-900">Comments ({comments.length})</h3>

      {user ? (
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
          <TextArea
            placeholder="Leave a comment..."
            {...register('content', {
              required: 'Comment cannot be empty',
              minLength: { value: 3, message: 'Comment is too short' }
            })}
            error={errors.content?.message}
          />
          <div className="flex justify-end">
            <Button type="submit" variant="primary" isLoading={submitting}>
              Post Comment
            </Button>
          </div>
        </form>
      ) : (
        <div className="rounded-md bg-gray-50 p-4">
          <p className="text-center text-sm text-gray-600">
            Please <a href="/login" className="font-medium text-emerald-600">sign in</a> to leave a comment.
          </p>
        </div>
      )}

      <div className="space-y-4">
        {comments.length === 0 ? (
          <p className="text-center text-gray-500 py-6">Be the first to comment on this campaign!</p>
        ) : (
          comments.map((comment) => (
            <div key={comment.id} className="rounded-md border border-gray-200 p-4">
              <div className="flex items-center space-x-3">
                <div className="flex-shrink-0">
                  {comment.author?.avatar_url ? (
                    <img
                      src={comment.author.avatar_url}
                      alt={comment.author.full_name || 'User'}
                      className="h-10 w-10 rounded-full"
                    />
                  ) : (
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-200">
                      <User size={20} className="text-gray-500" />
                    </div>
                  )}
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-900">
                    {comment.author?.full_name || 'Anonymous User'}
                  </h4>
                  <div className="flex items-center text-xs text-gray-500">
                    <Clock size={12} className="mr-1" />
                    <span>{formatDate(comment.created_at)}</span>
                  </div>
                </div>
              </div>
              <p className="mt-3 text-gray-700 whitespace-pre-wrap">{comment.content}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
}