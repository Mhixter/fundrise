import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import Input from '../ui/Input';
import TextArea from '../ui/TextArea';
import Select from '../ui/Select';
import Button from '../ui/Button';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { toast } from 'sonner';

type FormData = {
  title: string;
  description: string;
  goalAmount: string;
  currency: string;
  deadline: string;
  category: string;
  coverImage?: FileList;
};

const CATEGORIES = [
  { value: 'charity', label: 'Charity & Causes' },
  { value: 'business', label: 'Business & Entrepreneurship' },
  { value: 'creative', label: 'Creative & Arts' },
  { value: 'education', label: 'Education' },
  { value: 'medical', label: 'Medical & Health' },
  { value: 'personal', label: 'Personal Needs' },
  { value: 'technology', label: 'Technology & Innovation' },
  { value: 'nonprofit', label: 'Nonprofit Organizations' },
  { value: 'community', label: 'Community Projects' },
  { value: 'emergency', label: 'Emergency Relief' },
  { value: 'other', label: 'Other' }
];

const CURRENCIES = [
  { value: 'USD', label: 'US Dollar ($)' },
  { value: 'EUR', label: 'Euro (€)' },
  { value: 'GBP', label: 'British Pound (£)' },
  { value: 'CAD', label: 'Canadian Dollar (C$)' },
  { value: 'AUD', label: 'Australian Dollar (A$)' },
  { value: 'JPY', label: 'Japanese Yen (¥)' }
];

export default function CampaignForm() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm<FormData>();

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      setImageFile(file);
      
      // Create a preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = async (data: FormData) => {
    if (!user) {
      toast.error('You must be logged in to create a campaign');
      navigate('/login');
      return;
    }

    setLoading(true);

    try {
      let coverImageUrl = '';
      
      // Upload image if one was selected
      if (imageFile) {
        const fileExt = imageFile.name.split('.').pop();
        const fileName = `${Math.random().toString(36).substring(2, 15)}.${fileExt}`;
        const filePath = `campaign-covers/${fileName}`;
        
        const { error: uploadError } = await supabase.storage
          .from('campaigns')
          .upload(filePath, imageFile);
          
        if (uploadError) {
          throw new Error('Error uploading image: ' + uploadError.message);
        }
        
        const { data: urlData } = supabase.storage
          .from('campaigns')
          .getPublicUrl(filePath);
          
        coverImageUrl = urlData.publicUrl;
      } else {
        // Set a default image if none is provided
        coverImageUrl = 'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750';
      }

      // Create the campaign
      const { data: campaign, error } = await supabase
        .from('campaigns')
        .insert({
          title: data.title,
          description: data.description,
          goal_amount: parseFloat(data.goalAmount),
          current_amount: 0,
          currency: data.currency,
          deadline: data.deadline || null,
          category: data.category,
          cover_image: coverImageUrl,
          created_by: user.id,
          status: 'active'
        })
        .select()
        .single();
        
      if (error) {
        throw new Error('Error creating campaign: ' + error.message);
      }

      toast.success('Campaign created successfully!');
      navigate(`/campaign/${campaign.id}`);
    } catch (error) {
      console.error('Error creating campaign:', error);
      toast.error('Failed to create campaign. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div>
        <Input
          label="Campaign Title"
          id="title"
          placeholder="Give your campaign a clear, attention-grabbing title"
          {...register('title', { 
            required: 'Title is required',
            minLength: { value: 5, message: 'Title must be at least 5 characters' }
          })}
          error={errors.title?.message}
        />
      </div>
      
      <div>
        <TextArea
          label="Campaign Description"
          id="description"
          placeholder="Describe your campaign, its purpose, and what the funds will be used for"
          {...register('description', { 
            required: 'Description is required',
            minLength: { value: 20, message: 'Description must be at least 20 characters' }
          })}
          error={errors.description?.message}
        />
      </div>
      
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Input
          label="Funding Goal"
          id="goalAmount"
          type="number"
          min="1"
          step="0.01"
          placeholder="100.00"
          {...register('goalAmount', { 
            required: 'Funding goal is required',
            min: { value: 1, message: 'Goal must be at least 1' }
          })}
          error={errors.goalAmount?.message}
        />
        
        <Select
          label="Currency"
          id="currency"
          {...register('currency', { required: 'Currency is required' })}
          options={CURRENCIES}
          error={errors.currency?.message}
          defaultValue="USD"
        />
      </div>
      
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Input
          label="Campaign Deadline (Optional)"
          id="deadline"
          type="date"
          min={new Date().toISOString().split('T')[0]}
          {...register('deadline')}
          error={errors.deadline?.message}
          helperText="Leave blank for no deadline"
        />
        
        <Select
          label="Category"
          id="category"
          {...register('category', { required: 'Category is required' })}
          options={CATEGORIES}
          error={errors.category?.message}
          defaultValue="charity"
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Cover Image
        </label>
        <div className="mt-1 flex justify-center rounded-md border-2 border-dashed border-gray-300 px-6 pt-5 pb-6">
          <div className="space-y-1 text-center">
            {imageUrl ? (
              <div className="mb-3">
                <img 
                  src={imageUrl} 
                  alt="Cover preview" 
                  className="mx-auto h-32 w-auto object-cover rounded-md"
                />
                <button 
                  type="button"
                  onClick={() => {
                    setImageUrl(null);
                    setImageFile(null);
                  }}
                  className="mt-2 text-sm font-medium text-red-600 hover:text-red-500"
                >
                  Remove image
                </button>
              </div>
            ) : (
              <svg
                className="mx-auto h-12 w-12 text-gray-400"
                stroke="currentColor"
                fill="none"
                viewBox="0 0 48 48"
              >
                <path
                  d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            )}
            <div className="flex text-sm text-gray-600">
              <label
                htmlFor="file-upload"
                className="relative cursor-pointer rounded-md bg-white font-medium text-emerald-600 focus-within:outline-none focus-within:ring-2 focus-within:ring-emerald-500 focus-within:ring-offset-2 hover:text-emerald-500"
              >
                <span>Upload a file</span>
                <input
                  id="file-upload"
                  name="file-upload"
                  type="file"
                  className="sr-only"
                  accept="image/*"
                  onChange={handleImageChange}
                />
              </label>
              <p className="pl-1">or drag and drop</p>
            </div>
            <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
          </div>
        </div>
      </div>
      
      <div className="flex justify-end">
        <Button 
          type="button" 
          variant="outline" 
          className="mr-3"
          onClick={() => navigate(-1)}
        >
          Cancel
        </Button>
        <Button type="submit" variant="primary" isLoading={loading}>
          Create Campaign
        </Button>
      </div>
    </form>
  );
}