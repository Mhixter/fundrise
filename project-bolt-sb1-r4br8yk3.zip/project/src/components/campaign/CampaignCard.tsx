import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Clock, User } from 'lucide-react';
import { Card, CardContent, CardFooter } from '../ui/Card';
import ProgressBar from '../ui/ProgressBar';
import { Campaign } from '../../types';
import { formatCurrency, getDaysLeft } from '../../utils/helpers';

interface CampaignCardProps {
  campaign: Campaign;
}

export default function CampaignCard({ campaign }: CampaignCardProps) {
  const daysLeft = campaign.deadline ? getDaysLeft(campaign.deadline) : null;
  const percentFunded = Math.round((campaign.current_amount / campaign.goal_amount) * 100);

  return (
    <Card className="overflow-hidden transition-all duration-200 hover:shadow-md">
      <Link to={`/campaign/${campaign.id}`}>
        <div className="relative aspect-[16/9] w-full overflow-hidden">
          <img
            src={campaign.cover_image || 'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'}
            alt={campaign.title}
            className="h-full w-full object-cover transition-transform duration-300 ease-in-out hover:scale-105"
          />
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-gray-900/80 to-transparent p-4">
            <div className="rounded-full bg-white px-2 py-1 text-xs font-semibold text-gray-700 inline-block">
              {campaign.category}
            </div>
          </div>
        </div>
      </Link>

      <CardContent className="p-4">
        <Link to={`/campaign/${campaign.id}`}>
          <h3 className="line-clamp-2 text-lg font-semibold text-gray-900 mb-2 hover:text-emerald-600">
            {campaign.title}
          </h3>
        </Link>
        <p className="line-clamp-2 text-sm text-gray-500 mb-4">{campaign.description}</p>
        <ProgressBar currentAmount={campaign.current_amount} goalAmount={campaign.goal_amount} />
      </CardContent>

      <CardFooter className="bg-gray-50 px-4 py-3 flex flex-col sm:flex-row gap-2 sm:gap-0 sm:justify-between text-sm">
        <div className="flex items-center text-gray-500">
          <User size={14} className="mr-1" />
          <span>by {campaign.created_by.substring(0, 15)}</span>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center text-gray-500">
            <Clock size={14} className="mr-1" />
            <span>{daysLeft !== null ? `${daysLeft} days left` : 'No deadline'}</span>
          </div>
          <div className="font-semibold text-emerald-600">
            {formatCurrency(campaign.current_amount, campaign.currency)}
          </div>
        </div>
      </CardFooter>
    </Card>
  );
}