export type UserRole = 'visitor' | 'user' | 'admin';

export interface User {
  id: string;
  email: string;
  full_name?: string;
  avatar_url?: string;
  bio?: string;
  role: UserRole;
  created_at: string;
}

export interface Campaign {
  id: string;
  title: string;
  description: string;
  goal_amount: number;
  current_amount: number;
  currency: string;
  deadline: string | null;
  category: string;
  status: 'draft' | 'active' | 'completed' | 'cancelled';
  cover_image: string;
  created_by: string;
  created_at: string;
  updated_at: string;
  creator?: {
    id: string;
    full_name: string | null;
    avatar_url: string | null;
  };
}

export interface Donation {
  id: string;
  campaign_id: string;
  user_id: string | null;
  amount: number;
  currency: string;
  message?: string;
  is_anonymous: boolean;
  created_at: string;
}

export interface Comment {
  id: string;
  campaign_id: string;
  user_id: string;
  content: string;
  created_at: string;
  updated_at: string;
}

export interface Update {
  id: string;
  campaign_id: string;
  title: string;
  content: string;
  created_at: string;
}

export interface Withdrawal {
  id: string;
  campaign_id: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
  updated_at: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
}