import { loadStripe } from '@stripe/stripe-js';
import { PayPalScriptProvider, PayPalButtons } from '@paypal/react-paypal-js';
import { usePaystackPayment } from 'react-paystack';
import { useFlutterwave } from 'flutterwave-react-v3';

// Initialize payment gateway configurations
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);
const paystackConfig = {
  publicKey: import.meta.env.VITE_PAYSTACK_PUBLIC_KEY,
  currency: 'USD',
};
const flutterwaveConfig = {
  public_key: import.meta.env.VITE_FLUTTERWAVE_PUBLIC_KEY,
  tx_ref: Date.now().toString(),
  currency: 'USD',
};

export interface PaymentGatewayConfig {
  name: string;
  icon: string;
  currencies: string[];
  countries: string[];
}

export const PAYMENT_GATEWAYS: PaymentGatewayConfig[] = [
  {
    name: 'stripe',
    icon: '/stripe.svg',
    currencies: ['USD', 'EUR', 'GBP', 'AUD', 'CAD', 'JPY'],
    countries: ['US', 'GB', 'EU', 'AU', 'CA', 'JP'],
  },
  {
    name: 'paypal',
    icon: '/paypal.svg',
    currencies: ['USD', 'EUR', 'GBP', 'AUD', 'CAD'],
    countries: ['US', 'GB', 'EU', 'AU', 'CA'],
  },
  {
    name: 'paystack',
    icon: '/paystack.svg',
    currencies: ['NGN', 'USD', 'GHS', 'ZAR', 'KES'],
    countries: ['NG', 'GH', 'ZA', 'KE'],
  },
  {
    name: 'flutterwave',
    icon: '/flutterwave.svg',
    currencies: ['NGN', 'USD', 'GHS', 'KES', 'ZAR', 'UGX'],
    countries: ['NG', 'GH', 'KE', 'ZA', 'UG'],
  },
];

export interface PaymentData {
  amount: number;
  currency: string;
  donorEmail: string;
  donorName: string;
  campaignId: string;
  description: string;
}

class PaymentService {
  async processStripePayment(paymentData: PaymentData) {
    const stripe = await stripePromise;
    if (!stripe) throw new Error('Stripe failed to initialize');

    const response = await fetch('/api/create-payment-intent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(paymentData),
    });

    const { clientSecret } = await response.json();
    return stripe.confirmPayment({ clientSecret });
  }

  async processPayPalPayment(paymentData: PaymentData) {
    return new Promise((resolve, reject) => {
      // PayPal payment logic will be handled by the PayPal component
      resolve(true);
    });
  }

  async processPaystackPayment(paymentData: PaymentData) {
    const config = {
      ...paystackConfig,
      email: paymentData.donorEmail,
      amount: paymentData.amount * 100, // Paystack expects amount in kobo
      reference: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };

    return usePaystackPayment(config);
  }

  async processFlutterwavePayment(paymentData: PaymentData) {
    const config = {
      ...flutterwaveConfig,
      amount: paymentData.amount,
      customer: {
        email: paymentData.donorEmail,
        name: paymentData.donorName,
      },
      customizations: {
        title: "GoHelpThem Donation",
        description: paymentData.description,
      },
    };

    return useFlutterwave(config);
  }

  getAvailableGateways(currency: string, country: string): PaymentGatewayConfig[] {
    return PAYMENT_GATEWAYS.filter(gateway => 
      gateway.currencies.includes(currency) && 
      gateway.countries.includes(country)
    );
  }

  async verifyPayment(gatewayName: string, paymentId: string) {
    const response = await fetch(`/api/verify-payment`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ gateway: gatewayName, paymentId }),
    });

    return response.json();
  }

  async processRefund(gatewayName: string, paymentId: string, amount: number) {
    const response = await fetch(`/api/refund-payment`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ gateway: gatewayName, paymentId, amount }),
    });

    return response.json();
  }
}

export const paymentService = new PaymentService();