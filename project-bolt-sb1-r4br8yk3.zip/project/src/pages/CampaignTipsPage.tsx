import React from 'react';
import Layout from '../components/layout/Layout';
import { Lightbulb, Target, Users, Share2, Camera, Clock } from 'lucide-react';

export default function CampaignTipsPage() {
  const tips = [
    {
      icon: Target,
      title: "Set Clear Goals",
      description: "Define specific, achievable fundraising targets and explain exactly how the funds will be used."
    },
    {
      icon: Camera,
      title: "Tell Your Story Visually",
      description: "Use high-quality photos and videos to make your campaign more engaging and personal."
    },
    {
      icon: Users,
      title: "Engage Your Network",
      description: "Start by sharing with close friends and family who can help spread the word."
    },
    {
      icon: Share2,
      title: "Leverage Social Media",
      description: "Regular updates across different platforms keep supporters engaged and attract new donors."
    },
    {
      icon: Clock,
      title: "Time It Right",
      description: "Choose campaign duration carefully and create urgency with specific milestones."
    },
    {
      icon: Lightbulb,
      title: "Offer Updates",
      description: "Keep supporters informed about progress and how their donations are making an impact."
    }
  ];

  return (
    <Layout>
      <div className="bg-white">
        <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">Campaign Tips</h1>
            <p className="mt-6 text-lg leading-8 text-gray-600">
              Expert advice to help you create and run successful fundraising campaigns.
            </p>
          </div>

          <div className="mt-16 grid gap-12 sm:grid-cols-2 lg:grid-cols-3">
            {tips.map((tip, index) => (
              <div key={index} className="relative">
                <div className="absolute -top-4 left-4 inline-block rounded-lg bg-emerald-600 p-2 text-white">
                  <tip.icon className="h-6 w-6" />
                </div>
                <div className="rounded-lg border border-gray-200 p-8 pt-12">
                  <h3 className="text-lg font-semibold text-gray-900">{tip.title}</h3>
                  <p className="mt-4 text-gray-600">{tip.description}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-24">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 text-center mb-12">
              Best Practices for Campaign Success
            </h2>
            <div className="grid gap-8 md:grid-cols-2">
              <div className="bg-gray-50 rounded-lg p-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Do's</h3>
                <ul className="space-y-4">
                  {[
                    "Be transparent about your goals and how funds will be used",
                    "Share regular updates with your supporters",
                    "Use high-quality images and videos",
                    "Engage with donors and thank them personally",
                    "Create a compelling story that connects emotionally",
                    "Set realistic fundraising goals"
                  ].map((item, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <span className="text-emerald-600">✓</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-gray-50 rounded-lg p-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Don'ts</h3>
                <ul className="space-y-4">
                  {[
                    "Set unrealistic fundraising goals",
                    "Forget to thank your donors",
                    "Neglect to provide regular updates",
                    "Use low-quality or stock images",
                    "Ignore questions from potential donors",
                    "Launch without a promotion plan"
                  ].map((item, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <span className="text-red-600">×</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <div className="mt-24 bg-emerald-50 rounded-lg p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Need More Help?</h2>
            <p className="text-gray-600 mb-8">
              Our team is here to help you create and run successful campaigns. Get in touch with us for personalized advice.
            </p>
            <a
              href="/contact"
              className="inline-block rounded-md bg-emerald-600 px-6 py-3 text-base font-semibold text-white shadow-sm hover:bg-emerald-500"
            >
              Contact Support
            </a>
          </div>
        </div>
      </div>
    </Layout>
  );
}