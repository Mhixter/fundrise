import React from 'react';
import Layout from '../components/layout/Layout';
import { Check } from 'lucide-react';

export default function PricingPage() {
  return (
    <Layout>
      <div className="bg-white">
        <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
          <div className="mx-auto max-w-4xl text-center">
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl">
              Simple, Transparent Pricing
            </h1>
            <p className="mt-6 text-lg leading-8 text-gray-600">
              We believe in keeping our fees low and transparent so you can focus on what matters most - your cause.
            </p>
          </div>

          <div className="mx-auto mt-16 max-w-7xl px-6 lg:px-8">
            <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
              {/* Standard Plan */}
              <div className="flex flex-col rounded-3xl bg-white p-8 ring-1 ring-gray-200 xl:p-10">
                <div className="mb-12">
                  <h3 className="text-lg font-semibold leading-8 text-emerald-600">Standard</h3>
                  <p className="mt-4 text-sm leading-6 text-gray-600">
                    Perfect for personal fundraising and small projects
                  </p>
                  <p className="mt-6 flex items-baseline gap-x-1">
                    <span className="text-4xl font-bold tracking-tight text-gray-900">2%</span>
                    <span className="text-sm font-semibold leading-6 text-gray-600">platform fee</span>
                  </p>
                  <p className="mt-2 text-sm text-gray-600">+ 2.9% + $0.30 payment processing</p>
                </div>
                <ul className="flex flex-col gap-4">
                  {[
                    'Basic campaign page',
                    'Social media sharing',
                    'Email support',
                    'Secure payment processing',
                    'Mobile optimization',
                  ].map((feature) => (
                    <li key={feature} className="flex items-center gap-3">
                      <Check className="h-5 w-5 text-emerald-600" />
                      <span className="text-sm leading-6 text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Plus Plan */}
              <div className="flex flex-col rounded-3xl bg-white p-8 ring-1 ring-gray-200 xl:p-10 lg:z-10 lg:rounded-b-none">
                <div className="mb-12">
                  <h3 className="text-lg font-semibold leading-8 text-emerald-600">Plus</h3>
                  <p className="mt-4 text-sm leading-6 text-gray-600">
                    For organizations and larger campaigns
                  </p>
                  <p className="mt-6 flex items-baseline gap-x-1">
                    <span className="text-4xl font-bold tracking-tight text-gray-900">1.5%</span>
                    <span className="text-sm font-semibold leading-6 text-gray-600">platform fee</span>
                  </p>
                  <p className="mt-2 text-sm text-gray-600">+ 2.9% + $0.30 payment processing</p>
                </div>
                <ul className="flex flex-col gap-4">
                  {[
                    'All Standard features',
                    'Custom campaign URL',
                    'Priority support',
                    'Team fundraising',
                    'Advanced analytics',
                    'Donor CRM tools',
                  ].map((feature) => (
                    <li key={feature} className="flex items-center gap-3">
                      <Check className="h-5 w-5 text-emerald-600" />
                      <span className="text-sm leading-6 text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Enterprise Plan */}
              <div className="flex flex-col rounded-3xl bg-white p-8 ring-1 ring-gray-200 xl:p-10">
                <div className="mb-12">
                  <h3 className="text-lg font-semibold leading-8 text-emerald-600">Enterprise</h3>
                  <p className="mt-4 text-sm leading-6 text-gray-600">
                    Custom solutions for large organizations
                  </p>
                  <p className="mt-6 flex items-baseline gap-x-1">
                    <span className="text-4xl font-bold tracking-tight text-gray-900">Custom</span>
                  </p>
                  <p className="mt-2 text-sm text-gray-600">Contact us for custom pricing</p>
                </div>
                <ul className="flex flex-col gap-4">
                  {[
                    'All Plus features',
                    'Dedicated account manager',
                    'Custom integration',
                    'API access',
                    'White-label options',
                    'Custom reporting',
                    '24/7 phone support',
                  ].map((feature) => (
                    <li key={feature} className="flex items-center gap-3">
                      <Check className="h-5 w-5 text-emerald-600" />
                      <span className="text-sm leading-6 text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <div className="mx-auto mt-16 max-w-3xl text-center">
            <h2 className="text-2xl font-bold tracking-tight text-gray-900">Frequently Asked Questions</h2>
            <dl className="mt-8 space-y-6 divide-y divide-gray-300/10">
              {[
                {
                  question: "When do I pay the platform fee?",
                  answer: "Platform fees are only charged when you receive donations. There are no upfront or monthly fees."
                },
                {
                  question: "Can I change plans?",
                  answer: "Yes, you can upgrade or downgrade your plan at any time. Changes will apply to future donations."
                },
                {
                  question: "Are there any hidden fees?",
                  answer: "No hidden fees. We're completely transparent about our pricing structure and all fees are clearly displayed."
                },
                {
                  question: "What payment methods are supported?",
                  answer: "We accept all major credit cards, PayPal, and bank transfers. Enterprise clients can request additional payment methods."
                }
              ].map((faq) => (
                <div key={faq.question} className="pt-6">
                  <dt className="text-lg font-semibold leading-7 text-gray-900">
                    {faq.question}
                  </dt>
                  <dd className="mt-2 text-base leading-7 text-gray-600">
                    {faq.answer}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </div>
    </Layout>
  );
}