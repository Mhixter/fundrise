import React from 'react';
import Layout from '../components/layout/Layout';
import { Building2, Users, Target, Award } from 'lucide-react';

export default function AboutPage() {
  return (
    <Layout>
      <div className="bg-white">
        <div className="relative isolate overflow-hidden bg-gradient-to-b from-emerald-100/20">
          <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
            <div className="mx-auto max-w-2xl lg:mx-0">
              <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">About FundRise</h1>
              <p className="mt-6 text-lg leading-8 text-gray-600">
                We're on a mission to make fundraising accessible, transparent, and effective for everyone.
              </p>
            </div>
          </div>
        </div>

        <div className="mx-auto max-w-7xl px-6 py-12 sm:py-16 lg:px-8">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-2">
            <div>
              <h2 className="text-3xl font-bold tracking-tight text-gray-900">Our Story</h2>
              <p className="mt-6 text-lg leading-8 text-gray-600">
                Founded in 2025, FundRise emerged from a simple yet powerful idea: everyone deserves the opportunity to raise funds for causes they care about. We've since grown into a global platform that has helped millions of people achieve their fundraising goals.
              </p>
            </div>
            <div>
              <img
                src="https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg"
                alt="Team collaboration"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>

          <div className="mt-24">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 text-center mb-12">Our Values</h2>
            <div className="grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-4">
              <div className="text-center">
                <div className="mx-auto h-12 w-12 text-emerald-600">
                  <Users className="h-12 w-12" />
                </div>
                <h3 className="mt-6 text-lg font-semibold leading-8 text-gray-900">Community First</h3>
                <p className="mt-2 text-base leading-7 text-gray-600">
                  We believe in the power of community to create meaningful change.
                </p>
              </div>
              <div className="text-center">
                <div className="mx-auto h-12 w-12 text-emerald-600">
                  <Building2 className="h-12 w-12" />
                </div>
                <h3 className="mt-6 text-lg font-semibold leading-8 text-gray-900">Transparency</h3>
                <p className="mt-2 text-base leading-7 text-gray-600">
                  We maintain open and honest communication in everything we do.
                </p>
              </div>
              <div className="text-center">
                <div className="mx-auto h-12 w-12 text-emerald-600">
                  <Target className="h-12 w-12" />
                </div>
                <h3 className="mt-6 text-lg font-semibold leading-8 text-gray-900">Impact Driven</h3>
                <p className="mt-2 text-base leading-7 text-gray-600">
                  We measure our success by the positive change we create.
                </p>
              </div>
              <div className="text-center">
                <div className="mx-auto h-12 w-12 text-emerald-600">
                  <Award className="h-12 w-12" />
                </div>
                <h3 className="mt-6 text-lg font-semibold leading-8 text-gray-900">Excellence</h3>
                <p className="mt-2 text-base leading-7 text-gray-600">
                  We strive for excellence in every aspect of our platform.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-24">
            <div className="grid grid-cols-1 gap-12 lg:grid-cols-3">
              <div className="lg:col-span-2">
                <h2 className="text-3xl font-bold tracking-tight text-gray-900">Our Impact</h2>
                <p className="mt-6 text-lg leading-8 text-gray-600">
                  Since our inception, we've helped raise over $100 million for various causes worldwide. Our platform has supported:
                </p>
                <ul className="mt-8 space-y-4 text-lg leading-8 text-gray-600">
                  <li>• Over 10,000 medical fundraisers</li>
                  <li>• 5,000+ educational initiatives</li>
                  <li>• Countless emergency relief efforts</li>
                  <li>• Numerous creative and entrepreneurial projects</li>
                </ul>
              </div>
              <div className="lg:col-span-1">
                <dl className="grid grid-cols-1 gap-6">
                  <div className="rounded-lg bg-emerald-50 px-6 py-8">
                    <dt className="text-sm font-semibold leading-6 text-emerald-600">Total Raised</dt>
                    <dd className="mt-2 text-3xl font-bold leading-10 tracking-tight text-gray-900">$100M+</dd>
                  </div>
                  <div className="rounded-lg bg-emerald-50 px-6 py-8">
                    <dt className="text-sm font-semibold leading-6 text-emerald-600">Successful Campaigns</dt>
                    <dd className="mt-2 text-3xl font-bold leading-10 tracking-tight text-gray-900">15,000+</dd>
                  </div>
                  <div className="rounded-lg bg-emerald-50 px-6 py-8">
                    <dt className="text-sm font-semibold leading-6 text-emerald-600">Countries Reached</dt>
                    <dd className="mt-2 text-3xl font-bold leading-10 tracking-tight text-gray-900">50+</dd>
                  </div>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}