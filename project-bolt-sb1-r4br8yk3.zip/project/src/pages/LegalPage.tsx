import React from 'react';
import Layout from '../components/layout/Layout';
import { FileText, Scale, Shield } from 'lucide-react';

export default function LegalPage() {
  return (
    <Layout>
      <div className="bg-white">
        <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
          <div className="mx-auto max-w-2xl">
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl mb-8">Legal Information</h1>
            
            <div className="space-y-12">
              <section>
                <h2 className="text-2xl font-semibold mb-4">Legal Overview</h2>
                <p className="text-gray-600">
                  This page contains important legal information about FundRise, our services, 
                  and your rights and responsibilities when using our platform.
                </p>
              </section>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="rounded-lg border border-gray-200 p-6">
                  <div className="flex items-center mb-4">
                    <Scale className="h-6 w-6 text-emerald-600 mr-2" />
                    <h3 className="text-lg font-semibold">Terms of Service</h3>
                  </div>
                  <p className="text-gray-600 mb-4">
                    Our terms of service outline the rules and guidelines for using FundRise.
                  </p>
                  <a href="/terms" className="text-emerald-600 hover:text-emerald-700 font-medium">
                    Read Terms →
                  </a>
                </div>

                <div className="rounded-lg border border-gray-200 p-6">
                  <div className="flex items-center mb-4">
                    <Shield className="h-6 w-6 text-emerald-600 mr-2" />
                    <h3 className="text-lg font-semibold">Privacy Policy</h3>
                  </div>
                  <p className="text-gray-600 mb-4">
                    Learn how we collect, use, and protect your personal information.
                  </p>
                  <a href="/privacy" className="text-emerald-600 hover:text-emerald-700 font-medium">
                    Read Policy →
                  </a>
                </div>

                <div className="rounded-lg border border-gray-200 p-6">
                  <div className="flex items-center mb-4">
                    <FileText className="h-6 w-6 text-emerald-600 mr-2" />
                    <h3 className="text-lg font-semibold">Guidelines</h3>
                  </div>
                  <p className="text-gray-600 mb-4">
                    Community guidelines and acceptable use policies.
                  </p>
                  <a href="/guidelines" className="text-emerald-600 hover:text-emerald-700 font-medium">
                    Read Guidelines →
                  </a>
                </div>
              </div>

              <section>
                <h2 className="text-2xl font-semibold mb-4">Legal Compliance</h2>
                <div className="space-y-4">
                  <div className="rounded-lg bg-gray-50 p-6">
                    <h3 className="text-lg font-semibold mb-2">Regulatory Compliance</h3>
                    <p className="text-gray-600">
                      FundRise complies with all applicable laws and regulations regarding 
                      crowdfunding, financial transactions, and data protection.
                    </p>
                  </div>
                  
                  <div className="rounded-lg bg-gray-50 p-6">
                    <h3 className="text-lg font-semibold mb-2">Financial Regulations</h3>
                    <p className="text-gray-600">
                      Our platform adheres to financial regulations and maintains necessary 
                      licenses for payment processing and fund distribution.
                    </p>
                  </div>

                  <div className="rounded-lg bg-gray-50 p-6">
                    <h3 className="text-lg font-semibold mb-2">Data Protection</h3>
                    <p className="text-gray-600">
                      We follow strict data protection guidelines and comply with GDPR, 
                      CCPA, and other relevant privacy laws.
                    </p>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">Contact Legal Team</h2>
                <p className="text-gray-600 mb-6">
                  For legal inquiries or concerns, please contact our legal team at legal@fundrise.com 
                  or use the contact form below.
                </p>
                <form className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                      Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="subject" className="block text-sm font-medium text-gray-700">
                      Subject
                    </label>
                    <input
                      type="text"
                      id="subject"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700">
                      Message
                    </label>
                    <textarea
                      id="message"
                      rows={4}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>
                  
                  <button
                    type="submit"
                    className="inline-flex justify-center rounded-md border border-transparent bg-emerald-600 py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2"
                  >
                    Send Message
                  </button>
                </form>
              </section>

              <div className="text-sm text-gray-500">
                <p>Last updated: January 2025</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}