import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '../../components/layout/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { Campaign, User, Donation, Withdrawal } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import { formatCurrency } from '../../utils/helpers';
import { toast } from 'sonner';

export default function AdminDashboardPage() {
  const { user, isAdmin, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalCampaigns: 0,
    totalDonations: 0,
    totalAmount: 0,
  });
  const [recentCampaigns, setRecentCampaigns] = useState<Campaign[]>([]);
  const [recentDonations, setRecentDonations] = useState<Donation[]>([]);
  const [pendingWithdrawals, setPendingWithdrawals] = useState<Withdrawal[]>([]);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    // Redirect if not admin
    if (!authLoading && (!user || !isAdmin)) {
      toast.error('Access denied. Admin privileges required.');
      navigate('/');
    } else if (!authLoading && user && isAdmin) {
      fetchAdminData();
    }
  }, [authLoading, user, isAdmin, navigate]);

  const fetchAdminData = async () => {
    setLoading(true);

    try {
      // Fetch counts and stats
      const { count: userCount } = await supabase
        .from('profiles')
        .select('id', { count: 'exact', head: true });

      const { count: campaignCount } = await supabase
        .from('campaigns')
        .select('id', { count: 'exact', head: true });

      const { count: donationCount, data: donationData } = await supabase
        .from('donations')
        .select('amount', { count: 'exact' });

      const totalAmount = donationData
        ? donationData.reduce((sum, donation) => sum + donation.amount, 0)
        : 0;

      setStats({
        totalUsers: userCount || 0,
        totalCampaigns: campaignCount || 0,
        totalDonations: donationCount || 0,
        totalAmount,
      });

      // Fetch recent campaigns
      const { data: campaigns, error: campaignsError } = await supabase
        .from('campaigns')
        .select(`
          *,
          profiles(full_name)
        `)
        .order('created_at', { ascending: false })
        .limit(5);

      if (campaignsError) throw campaignsError;
      setRecentCampaigns(campaigns || []);

      // Fetch recent donations
      const { data: donations, error: donationsError } = await supabase
        .from('donations')
        .select(`
          *,
          profiles(full_name),
          campaigns(title)
        `)
        .order('created_at', { ascending: false })
        .limit(5);

      if (donationsError) throw donationsError;
      setRecentDonations(donations || []);

      // Fetch pending withdrawals
      const { data: withdrawals, error: withdrawalsError } = await supabase
        .from('withdrawals')
        .select(`
          *,
          profiles(full_name),
          campaigns(title)
        `)
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      if (withdrawalsError) throw withdrawalsError;
      setPendingWithdrawals(withdrawals || []);
    } catch (error) {
      console.error('Error fetching admin data:', error);
      toast.error('Failed to load admin data');
    } finally {
      setLoading(false);
    }
  };

  const handleWithdrawalApproval = async (withdrawalId: string, approved: boolean) => {
    try {
      const { error } = await supabase
        .from('withdrawals')
        .update({
          status: approved ? 'approved' : 'rejected',
        })
        .eq('id', withdrawalId);

      if (error) throw error;

      toast.success(`Withdrawal ${approved ? 'approved' : 'rejected'} successfully`);
      // Refresh pending withdrawals
      fetchAdminData();
    } catch (error) {
      console.error('Error processing withdrawal:', error);
      toast.error('Failed to process withdrawal');
    }
  };

  if (authLoading || loading) {
    return (
      <Layout>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 animate-pulse">
          <div className="h-8 w-1/4 bg-gray-300 rounded mb-8" />
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 rounded-lg bg-gray-300" />
            ))}
          </div>
          <div className="mt-8 h-64 rounded-lg bg-gray-300" />
        </div>
      </Layout>
    );
  }

  if (!user || !isAdmin) {
    return null; // Redirect handled in useEffect
  }

  return (
    <Layout>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
            <p className="mt-1 text-gray-500">
              Manage users, campaigns, donations, and platform settings
            </p>
          </div>
          <div className="mt-4 flex space-x-3 sm:mt-0">
            <Button 
              variant="primary" 
              onClick={() => fetchAdminData()}
            >
              Refresh Data
            </Button>
          </div>
        </div>

        {/* Stats Section */}
        <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardContent className="p-6">
              <div className="text-sm font-medium uppercase text-gray-500">Total Users</div>
              <div className="mt-2 flex items-center">
                <span className="text-3xl font-bold text-gray-900">{stats.totalUsers}</span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="text-sm font-medium uppercase text-gray-500">Total Campaigns</div>
              <div className="mt-2 flex items-center">
                <span className="text-3xl font-bold text-gray-900">{stats.totalCampaigns}</span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="text-sm font-medium uppercase text-gray-500">Total Donations</div>
              <div className="mt-2 flex items-center">
                <span className="text-3xl font-bold text-gray-900">{stats.totalDonations}</span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="text-sm font-medium uppercase text-gray-500">Total Amount Raised</div>
              <div className="mt-2 flex items-center">
                <span className="text-3xl font-bold text-gray-900">
                  {formatCurrency(stats.totalAmount, 'USD')}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <div className="mt-8">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8" aria-label="Tabs">
              <button
                onClick={() => setActiveTab('overview')}
                className={`py-4 px-1 text-sm font-medium ${
                  activeTab === 'overview'
                    ? 'border-b-2 border-emerald-500 text-emerald-600'
                    : 'border-b-2 border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                }`}
              >
                Overview
              </button>
              <button
                onClick={() => setActiveTab('users')}
                className={`py-4 px-1 text-sm font-medium ${
                  activeTab === 'users'
                    ? 'border-b-2 border-emerald-500 text-emerald-600'
                    : 'border-b-2 border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                }`}
              >
                Users
              </button>
              <button
                onClick={() => setActiveTab('campaigns')}
                className={`py-4 px-1 text-sm font-medium ${
                  activeTab === 'campaigns'
                    ? 'border-b-2 border-emerald-500 text-emerald-600'
                    : 'border-b-2 border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                }`}
              >
                Campaigns
              </button>
              <button
                onClick={() => setActiveTab('withdrawals')}
                className={`py-4 px-1 text-sm font-medium ${
                  activeTab === 'withdrawals'
                    ? 'border-b-2 border-emerald-500 text-emerald-600'
                    : 'border-b-2 border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                }`}
              >
                Withdrawals
              </button>
              <button
                onClick={() => setActiveTab('settings')}
                className={`py-4 px-1 text-sm font-medium ${
                  activeTab === 'settings'
                    ? 'border-b-2 border-emerald-500 text-emerald-600'
                    : 'border-b-2 border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                }`}
              >
                Settings
              </button>
            </nav>
          </div>

          {/* Tab Content */}
          <div className="mt-6">
            {activeTab === 'overview' && (
              <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Campaigns</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {recentCampaigns.length > 0 ? (
                      <div className="divide-y divide-gray-200">
                        {recentCampaigns.map((campaign) => (
                          <div key={campaign.id} className="flex items-center justify-between py-3">
                            <div className="flex-1 truncate">
                              <p className="font-medium text-gray-900 truncate">
                                {campaign.title}
                              </p>
                              <p className="text-sm text-gray-500">
                                By {campaign.profiles?.full_name || 'Anonymous'}
                              </p>
                            </div>
                            <div className="ml-4 flex-shrink-0">
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => navigate(`/campaign/${campaign.id}`)}
                              >
                                View
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-center text-gray-500 py-4">No campaigns found</p>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Recent Donations</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {recentDonations.length > 0 ? (
                      <div className="divide-y divide-gray-200">
                        {recentDonations.map((donation) => (
                          <div key={donation.id} className="flex items-center justify-between py-3">
                            <div className="flex-1 truncate">
                              <p className="font-medium text-gray-900">
                                {formatCurrency(donation.amount, donation.currency)}
                              </p>
                              <p className="text-sm text-gray-500">
                                {donation.is_anonymous 
                                  ? 'Anonymous' 
                                  : (donation.profiles?.full_name || 'Unknown')} 
                                → {donation.campaigns?.title || 'Unknown Campaign'}
                              </p>
                            </div>
                            <div className="ml-4 flex-shrink-0 text-sm text-gray-500">
                              {new Date(donation.created_at).toLocaleDateString()}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-center text-gray-500 py-4">No donations found</p>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Pending Withdrawals</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {pendingWithdrawals.length > 0 ? (
                      <div className="divide-y divide-gray-200">
                        {pendingWithdrawals.map((withdrawal) => (
                          <div key={withdrawal.id} className="py-3">
                            <div className="flex items-center justify-between">
                              <div className="flex-1">
                                <p className="font-medium text-gray-900">
                                  {formatCurrency(withdrawal.amount, 'USD')}
                                </p>
                                <p className="text-sm text-gray-500">
                                  From {withdrawal.campaigns?.title || 'Unknown Campaign'}
                                </p>
                                <p className="text-sm text-gray-500">
                                  By {withdrawal.profiles?.full_name || 'Unknown User'}
                                </p>
                              </div>
                              <div className="ml-4 flex-shrink-0">
                                <div className="flex space-x-2">
                                  <Button 
                                    variant="primary" 
                                    size="sm"
                                    onClick={() => handleWithdrawalApproval(withdrawal.id, true)}
                                  >
                                    Approve
                                  </Button>
                                  <Button 
                                    variant="outline" 
                                    size="sm"
                                    onClick={() => handleWithdrawalApproval(withdrawal.id, false)}
                                  >
                                    Reject
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-center text-gray-500 py-4">No pending withdrawals</p>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}

            {activeTab === 'users' && (
              <div className="text-center py-12">
                <p>User management UI is under construction.</p>
                <p className="text-sm text-gray-500 mt-2">Coming soon!</p>
              </div>
            )}

            {activeTab === 'campaigns' && (
              <div className="text-center py-12">
                <p>Campaign management UI is under construction.</p>
                <p className="text-sm text-gray-500 mt-2">Coming soon!</p>
              </div>
            )}

            {activeTab === 'withdrawals' && (
              <Card>
                <CardHeader>
                  <CardTitle>Pending Withdrawal Requests</CardTitle>
                </CardHeader>
                <CardContent>
                  {pendingWithdrawals.length > 0 ? (
                    <div className="divide-y divide-gray-200">
                      {pendingWithdrawals.map((withdrawal) => (
                        <div key={withdrawal.id} className="py-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium text-gray-900">
                                Withdrawal Request #{withdrawal.id.substring(0, 8)}
                              </p>
                              <p className="text-sm text-gray-500">
                                Campaign: {withdrawal.campaigns?.title || 'Unknown'}
                              </p>
                              <p className="text-sm text-gray-500">
                                User: {withdrawal.profiles?.full_name || 'Unknown'}
                              </p>
                              <p className="text-sm text-gray-500">
                                Requested: {new Date(withdrawal.created_at).toLocaleDateString()}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="text-xl font-bold text-gray-900">
                                {formatCurrency(withdrawal.amount, 'USD')}
                              </p>
                              <div className="mt-2 flex space-x-2">
                                <Button 
                                  variant="primary" 
                                  size="sm"
                                  onClick={() => handleWithdrawalApproval(withdrawal.id, true)}
                                >
                                  Approve
                                </Button>
                                <Button 
                                  variant="danger" 
                                  size="sm"
                                  onClick={() => handleWithdrawalApproval(withdrawal.id, false)}
                                >
                                  Reject
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6">
                      <p className="text-gray-500">No pending withdrawal requests</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {activeTab === 'settings' && (
              <div className="text-center py-12">
                <p>Platform settings UI is under construction.</p>
                <p className="text-sm text-gray-500  mt-2">Coming soon!</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}