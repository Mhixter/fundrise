import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Layout from '../components/layout/Layout';
import { Card, CardContent } from '../components/ui/Card';
import { BarChart3, Calendar, FileText, Settings, Gift, Users, ChevronLeft, ChevronRight, ArrowLeftRight } from 'lucide-react';
import { Campaign, Donation } from '../types';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { formatCurrency, formatDate } from '../utils/helpers';
import TransferForm from '../components/transfer/TransferForm';

export default function DashboardPage() {
  const { user } = useAuth();
  const [donations, setDonations] = useState<Donation[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('This Month');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(true);
  const [showTransferModal, setShowTransferModal] = useState(false);

  useEffect(() => {
    if (user) {
      fetchDonationData();
    }
  }, [user]);

  const fetchDonationData = async () => {
    try {
      const { data, error } = await supabase
        .from('donations')
        .select(`
          *,
          campaigns (
            id,
            title,
            description,
            goal_amount,
            current_amount,
            currency,
            category,
            cover_image
          )
        `)
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setDonations(data || []);
    } catch (error) {
      console.error('Error fetching donation data:', error);
    } finally {
      setLoading(false);
    }
  };

  const totalDonations = donations.reduce((sum, donation) => sum + donation.amount, 0);
  const lastMonthDonations = donations
    .filter(d => new Date(d.created_at).getMonth() === new Date().getMonth() - 1)
    .reduce((sum, donation) => sum + donation.amount, 0);
  const percentageChange = ((totalDonations - lastMonthDonations) / lastMonthDonations) * 100;

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <div 
        className={`bg-black text-white fixed h-full overflow-y-auto transition-all duration-300 ease-in-out ${
          isSidebarCollapsed ? 'w-20' : 'w-64'
        }`}
      >
        <button
          onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          className="absolute -right-3 top-8 bg-black text-white p-1 rounded-full"
        >
          {isSidebarCollapsed ? 
            <ChevronRight size={20} /> : 
            <ChevronLeft size={20} />
          }
        </button>

        <div className="p-6">
          <div className={`flex items-center space-x-3 mb-8 ${isSidebarCollapsed ? 'justify-center' : ''}`}>
            <div className="w-10 h-10 bg-white rounded-full flex-shrink-0" />
            {!isSidebarCollapsed && (
              <div>
                <h2 className="font-semibold">{user?.full_name || 'User'}</h2>
                <p className="text-sm text-gray-400">Verified Foundation</p>
              </div>
            )}
          </div>

          <nav className="space-y-4">
            <Link 
              to="/dashboard" 
              className={`flex items-center p-3 bg-gray-800 rounded-lg ${
                isSidebarCollapsed ? 'justify-center' : 'space-x-3'
              }`}
            >
              <BarChart3 size={20} />
              {!isSidebarCollapsed && <span>Dashboard</span>}
            </Link>
            
            <Link 
              to="/fundraising" 
              className={`flex items-center p-3 text-gray-400 hover:bg-gray-800 rounded-lg ${
                isSidebarCollapsed ? 'justify-center' : 'space-x-3'
              }`}
            >
              <Gift size={20} />
              {!isSidebarCollapsed && <span>Fundraising</span>}
            </Link>
            
            <Link 
              to="/events" 
              className={`flex items-center p-3 text-gray-400 hover:bg-gray-800 rounded-lg ${
                isSidebarCollapsed ? 'justify-center' : 'space-x-3'
              }`}
            >
              <Calendar size={20} />
              {!isSidebarCollapsed && (
                <>
                  <span>Events</span>
                  <span className="ml-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">2</span>
                </>
              )}
            </Link>
            
            <Link 
              to="/campaigns" 
              className={`flex items-center p-3 text-gray-400 hover:bg-gray-800 rounded-lg ${
                isSidebarCollapsed ? 'justify-center' : 'space-x-3'
              }`}
            >
              <Users size={20} />
              {!isSidebarCollapsed && <span>Campaign</span>}
            </Link>
            
            <Link 
              to="/documents" 
              className={`flex items-center p-3 text-gray-400 hover:bg-gray-800 rounded-lg ${
                isSidebarCollapsed ? 'justify-center' : 'space-x-3'
              }`}
            >
              <FileText size={20} />
              {!isSidebarCollapsed && <span>Documents</span>}
            </Link>
            
            <Link 
              to="/settings" 
              className={`flex items-center p-3 text-gray-400 hover:bg-gray-800 rounded-lg ${
                isSidebarCollapsed ? 'justify-center' : 'space-x-3'
              }`}
            >
              <Settings size={20} />
              {!isSidebarCollapsed && <span>Settings</span>}
            </Link>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className={`flex-1 bg-gray-100 overflow-y-auto transition-all duration-300 ${
        isSidebarCollapsed ? 'ml-20' : 'ml-64'
      }`}>
        <div className="p-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="bg-yellow-400 text-black">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold">Total Donation</h3>
                  <button className="text-gray-700">•••</button>
                </div>
                <div className="text-3xl font-bold mb-2">
                  {formatCurrency(totalDonations, 'USD')}
                </div>
                <div className="text-sm">
                  {percentageChange > 0 ? '+' : ''}{percentageChange.toFixed(2)}% Than last month
                </div>
                <div className="text-xs text-gray-700 mt-1">
                  Updated 1d ago
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold">Donation Today</h3>
                  <button className="text-gray-400">•••</button>
                </div>
                <div className="text-3xl font-bold mb-2">
                  {formatCurrency(3326, 'USD')}
                </div>
                <div className="text-sm text-green-500">
                  +2.32% Than yesterday
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  Updated 30m ago
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 relative">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold">Quick Transfer</h3>
                  <button 
                    onClick={() => setShowTransferModal(true)}
                    className="flex items-center text-emerald-600 hover:text-emerald-700"
                  >
                    <ArrowLeftRight size={20} className="mr-2" />
                    Transfer
                  </button>
                </div>
                <div className="text-3xl font-bold mb-2">
                  Multi-Currency
                </div>
                <div className="text-sm text-gray-500">
                  Transfer funds across currencies
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Transfer Modal */}
          {showTransferModal && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
              <div className="bg-white rounded-lg p-6 w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold">Transfer Funds</h2>
                  <button 
                    onClick={() => setShowTransferModal(false)}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    ×
                  </button>
                </div>
                <TransferForm />
              </div>
            </div>
          )}

          <div className="mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-semibold">Donation Analytics</h3>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                      <span className="text-sm">Humanity</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                      <span className="text-sm">Study</span>
                    </div>
                    <select 
                      value={selectedPeriod}
                      onChange={(e) => setSelectedPeriod(e.target.value)}
                      className="ml-4 bg-white border border-gray-300 rounded-md px-3 py-1"
                    >
                      <option>Last 7 Days</option>
                      <option>This Month</option>
                      <option>Last Month</option>
                    </select>
                  </div>
                </div>
                
                <div className="h-64 bg-gray-50 rounded-lg"></div>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">Donation History</h3>
                <div className="space-y-4">
                  {donations.map((donation) => (
                    <div key={donation.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                        <div>
                          <p className="font-medium">{donation.campaigns?.title || 'Campaign'}</p>
                          <p className="text-sm text-gray-500">{formatDate(donation.created_at)}</p>
                        </div>
                      </div>
                      <div className="text-lg font-semibold">
                        {formatCurrency(donation.amount, donation.currency)}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}