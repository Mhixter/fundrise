import React from 'react';
import Layout from '../components/layout/Layout';
import { Mail, Phone, MapPin, Clock } from 'lucide-react';
import Button from '../components/ui/Button';

export default function ContactPage() {
  return (
    <Layout>
      <div className="bg-white">
        <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
          <div className="mx-auto max-w-2xl">
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl mb-8">Contact Us</h1>
            
            <div className="grid grid-cols-1 gap-12 sm:grid-cols-2 mb-12">
              <div>
                <h2 className="text-lg font-semibold text-gray-900">Get in Touch</h2>
                <p className="mt-2 text-gray-600">
                  Have questions or need assistance? We're here to help! Choose the best way to reach us below.
                </p>
                
                <div className="mt-8 space-y-6">
                  <div className="flex items-center">
                    <Mail className="h-6 w-6 text-emerald-600" />
                    <div className="ml-4">
                      <p className="font-medium text-gray-900">Email</p>
                      <p className="text-gray-600">support@fundrise.com</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <Phone className="h-6 w-6 text-emerald-600" />
                    <div className="ml-4">
                      <p className="font-medium text-gray-900">Phone</p>
                      <p className="text-gray-600">+1 (555) 123-4567</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <MapPin className="h-6 w-6 text-emerald-600" />
                    <div className="ml-4">
                      <p className="font-medium text-gray-900">Office</p>
                      <p className="text-gray-600">123 Fundraising Street</p>
                      <p className="text-gray-600">San Francisco, CA 94105</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <Clock className="h-6 w-6 text-emerald-600" />
                    <div className="ml-4">
                      <p className="font-medium text-gray-900">Hours</p>
                      <p className="text-gray-600">Monday - Friday: 9am - 6pm PST</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <form className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                      Name
                    </label>
                    <input
                      type="text"
                      name="name"
                      id="name"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                      Email
                    </label>
                    <input
                      type="email"
                      name="email"
                      id="email"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="subject" className="block text-sm font-medium text-gray-700">
                      Subject
                    </label>
                    <input
                      type="text"
                      name="subject"
                      id="subject"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700">
                      Message
                    </label>
                    <textarea
                      name="message"
                      id="message"
                      rows={4}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>
                  
                  <Button type="submit" variant="primary" fullWidth>
                    Send Message
                  </Button>
                </form>
              </div>
            </div>
            
            <div className="border-t border-gray-200 pt-12">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h2>
              <div className="space-y-8">
                {[
                  {
                    question: "What's your typical response time?",
                    answer: "We aim to respond to all inquiries within 24 hours during business days."
                  },
                  {
                    question: "Do you offer phone support?",
                    answer: "Yes, phone support is available for all users during our business hours."
                  },
                  {
                    question: "Can I visit your office?",
                    answer: "Office visits are available by appointment only. Please contact us to schedule."
                  }
                ].map((faq) => (
                  <div key={faq.question}>
                    <h3 className="text-lg font-medium text-gray-900">{faq.question}</h3>
                    <p className="mt-2 text-gray-600">{faq.answer}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}