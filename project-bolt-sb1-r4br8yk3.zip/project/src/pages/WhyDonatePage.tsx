import React from 'react';
import Layout from '../components/layout/Layout';
import { Heart, Globe, Users, Shield } from 'lucide-react';

export default function WhyDonatePage() {
  return (
    <Layout>
      <div className="bg-white">
        <div className="relative isolate overflow-hidden bg-gradient-to-b from-emerald-100/20">
          <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
            <div className="mx-auto max-w-2xl lg:mx-0">
              <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">Why Donate?</h1>
              <p className="mt-6 text-lg leading-8 text-gray-600">
                Your donation can make a real difference in someone's life. Learn how your support helps create positive change.
              </p>
            </div>
          </div>
        </div>

        <div className="mx-auto max-w-7xl px-6 py-12 sm:py-16 lg:px-8">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-2">
            <div>
              <h2 className="text-3xl font-bold tracking-tight text-gray-900">Make a Difference</h2>
              <p className="mt-6 text-lg leading-8 text-gray-600">
                When you donate through FundRise, you're not just giving money – you're investing in dreams, supporting causes, and helping create positive change in the world.
              </p>
            </div>
            <div>
              <img
                src="https://images.pexels.com/photos/6646917/pexels-photo-6646917.jpeg"
                alt="People helping each other"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>

          <div className="mt-24">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 text-center mb-12">The Impact of Your Donation</h2>
            <div className="grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-4">
              <div className="text-center">
                <div className="mx-auto h-12 w-12 text-emerald-600">
                  <Heart className="h-12 w-12" />
                </div>
                <h3 className="mt-6 text-lg font-semibold leading-8 text-gray-900">Support Causes</h3>
                <p className="mt-2 text-base leading-7 text-gray-600">
                  Help fund important causes and make a real difference in people's lives.
                </p>
              </div>
              <div className="text-center">
                <div className="mx-auto h-12 w-12 text-emerald-600">
                  <Globe className="h-12 w-12" />
                </div>
                <h3 className="mt-6 text-lg font-semibold leading-8 text-gray-900">Global Reach</h3>
                <p className="mt-2 text-base leading-7 text-gray-600">
                  Your donation can help people and projects around the world.
                </p>
              </div>
              <div className="text-center">
                <div className="mx-auto h-12 w-12 text-emerald-600">
                  <Users className="h-12 w-12" />
                </div>
                <h3 className="mt-6 text-lg font-semibold leading-8 text-gray-900">Build Community</h3>
                <p className="mt-2 text-base leading-7 text-gray-600">
                  Join a community of donors making positive change together.
                </p>
              </div>
              <div className="text-center">
                <div className="mx-auto h-12 w-12 text-emerald-600">
                  <Shield className="h-12 w-12" />
                </div>
                <h3 className="mt-6 text-lg font-semibold leading-8 text-gray-900">Secure & Transparent</h3>
                <p className="mt-2 text-base leading-7 text-gray-600">
                  Your donation is secure and you can track its impact.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-24">
            <div className="grid grid-cols-1 gap-12 lg:grid-cols-3">
              <div className="lg:col-span-2">
                <h2 className="text-3xl font-bold tracking-tight text-gray-900">Your Impact</h2>
                <p className="mt-6 text-lg leading-8 text-gray-600">
                  Every donation, no matter the size, makes a difference. Here's what your support has helped achieve:
                </p>
                <ul className="mt-8 space-y-4 text-lg leading-8 text-gray-600">
                  <li>• Over 10,000 medical fundraisers completed</li>
                  <li>• 5,000+ educational initiatives funded</li>
                  <li>• Countless emergency relief efforts supported</li>
                  <li>• Numerous creative and entrepreneurial projects launched</li>
                </ul>
              </div>
              <div className="lg:col-span-1">
                <dl className="grid grid-cols-1 gap-6">
                  <div className="rounded-lg bg-emerald-50 px-6 py-8">
                    <dt className="text-sm font-semibold leading-6 text-emerald-600">Total Raised</dt>
                    <dd className="mt-2 text-3xl font-bold leading-10 tracking-tight text-gray-900">$100M+</dd>
                  </div>
                  <div className="rounded-lg bg-emerald-50 px-6 py-8">
                    <dt className="text-sm font-semibold leading-6 text-emerald-600">Active Campaigns</dt>
                    <dd className="mt-2 text-3xl font-bold leading-10 tracking-tight text-gray-900">15,000+</dd>
                  </div>
                  <div className="rounded-lg bg-emerald-50 px-6 py-8">
                    <dt className="text-sm font-semibold leading-6 text-emerald-600">Success Rate</dt>
                    <dd className="mt-2 text-3xl font-bold leading-10 tracking-tight text-gray-900">94%</dd>
                  </div>
                </dl>
              </div>
            </div>
          </div>

          <div className="mt-24 bg-emerald-50 rounded-lg p-8 text-center">
            <h2 className="text-2xl font-bold text-gray-900">Ready to Make a Difference?</h2>
            <p className="mt-4 text-lg text-gray-600">
              Browse our campaigns and find a cause that speaks to you.
            </p>
            <div className="mt-8">
              <a
                href="/campaigns"
                className="inline-block rounded-md bg-emerald-600 px-6 py-3 text-base font-semibold text-white shadow-sm hover:bg-emerald-500"
              >
                Browse Campaigns
              </a>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}