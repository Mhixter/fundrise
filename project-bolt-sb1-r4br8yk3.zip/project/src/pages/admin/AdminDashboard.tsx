import React, { useState, useEffect } from 'react';
import { Card } from '../../components/ui/Card';
import { supabase } from '../../lib/supabase';
import { formatCurrency } from '../../utils/helpers';

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalCampaigns: 0,
    totalDonations: 0,
    totalAmount: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const [usersCount, campaignsCount, donationsData] = await Promise.all([
        supabase.from('profiles').select('id', { count: 'exact', head: true }),
        supabase.from('campaigns').select('id', { count: 'exact', head: true }),
        supabase.from('donations').select('amount')
      ]);

      const totalAmount = donationsData.data?.reduce((sum, donation) => sum + donation.amount, 0) || 0;

      setStats({
        totalUsers: usersCount.count || 0,
        totalCampaigns: campaignsCount.count || 0,
        totalDonations: donationsData.data?.length || 0,
        totalAmount
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse">
          <div className="h-8 w-1/4 bg-gray-300 rounded mb-8" />
          <div className="grid grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-300 rounded" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-8">Dashboard Overview</h1>
      
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <div className="p-6">
            <h3 className="text-lg font-semibold text-gray-900">Total Users</h3>
            <p className="mt-2 text-3xl font-bold">{stats.totalUsers}</p>
          </div>
        </Card>

        <Card>
          <div className="p-6">
            <h3 className="text-lg font-semibold text-gray-900">Total Campaigns</h3>
            <p className="mt-2 text-3xl font-bold">{stats.totalCampaigns}</p>
          </div>
        </Card>

        <Card>
          <div className="p-6">
            <h3 className="text-lg font-semibold text-gray-900">Total Donations</h3>
            <p className="mt-2 text-3xl font-bold">{stats.totalDonations}</p>
          </div>
        </Card>

        <Card>
          <div className="p-6">
            <h3 className="text-lg font-semibold text-gray-900">Total Amount</h3>
            <p className="mt-2 text-3xl font-bold">{formatCurrency(stats.totalAmount, 'USD')}</p>
          </div>
        </Card>
      </div>
    </div>
  );
}