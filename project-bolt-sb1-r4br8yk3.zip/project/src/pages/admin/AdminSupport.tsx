import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import { toast } from 'sonner';

interface SupportTicket {
  id: string;
  user_id: string;
  subject: string;
  message: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  created_at: string;
  updated_at: string;
  user?: {
    full_name: string;
    email: string;
  };
}

function AdminSupport() {
  const { user, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isAdmin) {
      navigate('/');
      return;
    }
    fetchTickets();
  }, [isAdmin, navigate]);

  const fetchTickets = async () => {
    try {
      setError(null);
      const { data, error: supabaseError } = await supabase
        .from('support_tickets')
        .select(`
          *,
          user:profiles!support_tickets_user_id_fkey(full_name, email)
        `)
        .order('created_at', { ascending: false });

      if (supabaseError) {
        throw new Error(supabaseError.message);
      }

      if (!data) {
        throw new Error('No data received from the server');
      }

      setTickets(data);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to load support tickets';
      setError(errorMessage);
      toast.error(errorMessage);
      console.error('Error fetching support tickets:', err);
    } finally {
      setLoading(false);
    }
  };

  const updateTicketStatus = async (ticketId: string, status: SupportTicket['status']) => {
    try {
      const { error: updateError } = await supabase
        .from('support_tickets')
        .update({ status, updated_at: new Date().toISOString() })
        .eq('id', ticketId);

      if (updateError) {
        throw new Error(updateError.message);
      }

      toast.success('Ticket status updated successfully');
      await fetchTickets();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to update ticket status';
      toast.error(errorMessage);
      console.error('Error updating ticket status:', err);
    }
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse">
          <div className="h-8 w-1/4 bg-gray-300 rounded mb-6" />
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-24 bg-gray-300 rounded" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8">
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <h2 className="text-xl font-semibold text-red-600 mb-2">Error Loading Support Tickets</h2>
              <p className="text-gray-600 mb-4">{error}</p>
              <Button onClick={fetchTickets}>Try Again</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Support Management</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Support Tickets</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4">Subject</th>
                  <th className="text-left py-3 px-4">User</th>
                  <th className="text-left py-3 px-4">Priority</th>
                  <th className="text-left py-3 px-4">Status</th>
                  <th className="text-left py-3 px-4">Created</th>
                  <th className="text-left py-3 px-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                {tickets.map((ticket) => (
                  <tr key={ticket.id} className="border-b">
                    <td className="py-3 px-4">
                      <div className="font-medium">{ticket.subject}</div>
                      <div className="text-sm text-gray-500 truncate max-w-xs">
                        {ticket.message}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div>{ticket.user?.full_name || 'Anonymous'}</div>
                      <div className="text-sm text-gray-500">{ticket.user?.email}</div>
                    </td>
                    <td className="py-3 px-4">
                      <select
                        value={ticket.priority}
                        onChange={async (e) => {
                          try {
                            const { error: priorityError } = await supabase
                              .from('support_tickets')
                              .update({ 
                                priority: e.target.value,
                                updated_at: new Date().toISOString()
                              })
                              .eq('id', ticket.id);

                            if (priorityError) {
                              throw new Error(priorityError.message);
                            }

                            toast.success('Ticket priority updated');
                            await fetchTickets();
                          } catch (err) {
                            const errorMessage = err instanceof Error ? err.message : 'Failed to update priority';
                            toast.error(errorMessage);
                            console.error('Error updating priority:', err);
                          }
                        }}
                        className="rounded border p-1"
                      >
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                        <option value="urgent">Urgent</option>
                      </select>
                    </td>
                    <td className="py-3 px-4">
                      <select
                        value={ticket.status}
                        onChange={(e) => updateTicketStatus(ticket.id, e.target.value as SupportTicket['status'])}
                        className="rounded border p-1"
                      >
                        <option value="open">Open</option>
                        <option value="in_progress">In Progress</option>
                        <option value="resolved">Resolved</option>
                        <option value="closed">Closed</option>
                      </select>
                    </td>
                    <td className="py-3 px-4">
                      {new Date(ticket.created_at).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => navigate(`/admin/support/${ticket.id}`)}
                        >
                          View
                        </Button>
                        <Button
                          variant="primary"
                          size="sm"
                          onClick={() => navigate(`/admin/support/${ticket.id}/reply`)}
                        >
                          Reply
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default AdminSupport;