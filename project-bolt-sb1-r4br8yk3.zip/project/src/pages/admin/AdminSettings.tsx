import React, { useState } from 'react';
import { Card, CardContent } from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';
import { Settings, Mail, Bell, Shield, Database, CreditCard } from 'lucide-react';
import { toast } from 'sonner';

export default function AdminSettings() {
  const [loading, setLoading] = useState(false);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      // Simulated API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success('Settings saved successfully');
    } catch (error) {
      toast.error('Failed to save settings');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Platform Settings</h1>
          <p className="text-gray-600">Manage your platform's global settings and configurations</p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <Mail className="h-6 w-6 text-emerald-600" />
              <h2 className="text-lg font-semibold">Email Settings</h2>
            </div>
            <form onSubmit={handleSaveSettings} className="space-y-4">
              <Input
                label="SMTP Host"
                defaultValue="smtp.example.com"
              />
              <Input
                label="SMTP Port"
                type="number"
                defaultValue="587"
              />
              <Input
                label="SMTP Username"
                type="email"
                defaultValue="noreply@example.com"
              />
              <Input
                label="SMTP Password"
                type="password"
                defaultValue="••••••••"
              />
              <Button type="submit" variant="primary" isLoading={loading}>
                Save Email Settings
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <Bell className="h-6 w-6 text-emerald-600" />
              <h2 className="text-lg font-semibold">Notification Settings</h2>
            </div>
            <form className="space-y-4">
              <div className="space-y-4">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                    defaultChecked
                  />
                  <span>Email notifications for new campaigns</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                    defaultChecked
                  />
                  <span>Email notifications for new donations</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                    defaultChecked
                  />
                  <span>Email notifications for support tickets</span>
                </label>
              </div>
              <Button type="submit" variant="primary">
                Save Notification Settings
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <Shield className="h-6 w-6 text-emerald-600" />
              <h2 className="text-lg font-semibold">Security Settings</h2>
            </div>
            <form className="space-y-4">
              <Select
                label="Session Timeout"
                options={[
                  { value: '15', label: '15 minutes' },
                  { value: '30', label: '30 minutes' },
                  { value: '60', label: '1 hour' },
                  { value: '120', label: '2 hours' },
                ]}
                defaultValue="30"
              />
              <Select
                label="Login Attempts Before Lockout"
                options={[
                  { value: '3', label: '3 attempts' },
                  { value: '5', label: '5 attempts' },
                  { value: '10', label: '10 attempts' },
                ]}
                defaultValue="5"
              />
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  className="h-4 w-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                  defaultChecked
                />
                <span>Enable two-factor authentication</span>
              </label>
              <Button type="submit" variant="primary">
                Save Security Settings
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <Database className="h-6 w-6 text-emerald-600" />
              <h2 className="text-lg font-semibold">Backup Settings</h2>
            </div>
            <form className="space-y-4">
              <Select
                label="Backup Frequency"
                options={[
                  { value: 'daily', label: 'Daily' },
                  { value: 'weekly', label: 'Weekly' },
                  { value: 'monthly', label: 'Monthly' },
                ]}
                defaultValue="daily"
              />
              <Input
                label="Backup Retention (days)"
                type="number"
                defaultValue="30"
              />
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  className="h-4 w-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                  defaultChecked
                />
                <span>Enable automatic backups</span>
              </label>
              <Button type="submit" variant="primary">
                Save Backup Settings
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <CreditCard className="h-6 w-6 text-emerald-600" />
              <h2 className="text-lg font-semibold">Payment Settings</h2>
            </div>
            <form className="space-y-4">
              <Select
                label="Default Currency"
                options={[
                  { value: 'USD', label: 'US Dollar ($)' },
                  { value: 'EUR', label: 'Euro (€)' },
                  { value: 'GBP', label: 'British Pound (£)' },
                ]}
                defaultValue="USD"
              />
              <Input
                label="Platform Fee (%)"
                type="number"
                step="0.01"
                defaultValue="2.5"
              />
              <div className="space-y-2">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                    defaultChecked
                  />
                  <span>Enable PayPal</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                    defaultChecked
                  />
                  <span>Enable Stripe</span>
                </label>
              </div>
              <Button type="submit" variant="primary">
                Save Payment Settings
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}