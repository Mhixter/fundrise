import React from 'react';
import Layout from '../components/layout/Layout';
import { Card, CardContent } from '../components/ui/Card';
import { Briefcase, MapPin, Clock } from 'lucide-react';
import Button from '../components/ui/Button';

const jobs = [
  {
    title: 'Senior Full Stack Developer',
    location: 'Remote',
    type: 'Full-time',
    description: 'We\'re looking for an experienced Full Stack Developer to help build and scale our crowdfunding platform.',
    requirements: [
      'At least 5 years of experience with modern web technologies',
      'Strong proficiency in React, Node.js, and TypeScript',
      'Experience with cloud platforms (AWS/GCP/Azure)',
      'Understanding of microservices architecture'
    ]
  },
  {
    title: 'Product Manager',
    location: 'New York, NY',
    type: 'Full-time',
    description: 'Join our product team to help shape the future of online fundraising and charitable giving.',
    requirements: [
      'At least 3 years of product management experience',
      'Strong analytical and problem-solving skills',
      'Experience with agile methodologies',
      'Excellent communication skills'
    ]
  },
  {
    title: 'UX/UI Designer',
    location: 'Remote',
    type: 'Full-time',
    description: 'Help create beautiful and intuitive user experiences for our platform.',
    requirements: [
      'Portfolio demonstrating strong UI/UX work',
      'Experience with Figma and modern design tools',
      'Understanding of accessibility standards',
      'Knowledge of design systems'
    ]
  }
];

export default function CareersPage() {
  return (
    <Layout>
      <div className="bg-emerald-600">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl">
              Join Our Mission
            </h1>
            <p className="mx-auto mt-4 max-w-2xl text-lg text-emerald-100">
              Help us build the future of charitable giving and make a positive impact on the world.
            </p>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-8 md:grid-cols-3 mb-12">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="mx-auto w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
                <Briefcase className="w-6 h-6 text-emerald-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Meaningful Work</h3>
              <p className="text-gray-600">
                Make a real difference in people's lives through technology and innovation.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <div className="mx-auto w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
                <MapPin className="w-6 h-6 text-emerald-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Remote-First</h3>
              <p className="text-gray-600">
                Work from anywhere in the world with our distributed team.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <div className="mx-auto w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
                <Clock className="w-6 h-6 text-emerald-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Flexible Hours</h3>
              <p className="text-gray-600">
                Balance your work and life with flexible scheduling options.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Open Positions</h2>
          <div className="space-y-6">
            {jobs.map((job, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900">{job.title}</h3>
                      <div className="flex items-center mt-2 text-gray-500">
                        <MapPin className="w-4 h-4 mr-1" />
                        <span className="mr-4">{job.location}</span>
                        <Clock className="w-4 h-4 mr-1" />
                        <span>{job.type}</span>
                      </div>
                    </div>
                    <Button variant="primary" className="mt-4 md:mt-0">
                      Apply Now
                    </Button>
                  </div>
                  <p className="text-gray-600 mb-4">{job.description}</p>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Requirements:</h4>
                    <ul className="list-disc list-inside text-gray-600">
                      {job.requirements.map((req, i) => (
                        <li key={i}>{req}</li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Don't see the right position?</h2>
          <p className="text-gray-600 mb-6">
            We're always looking for talented individuals to join our team. Send us your resume and we'll keep you in mind for future opportunities.
          </p>
          <Button variant="outline">
            Send Your Resume
          </Button>
        </div>
      </div>
    </Layout>
  );
}