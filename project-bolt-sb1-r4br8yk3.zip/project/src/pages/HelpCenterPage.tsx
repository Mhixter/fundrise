import React, { useState } from 'react';
import Layout from '../components/layout/Layout';
import { Card, CardContent } from '../components/ui/Card';
import { Search, ChevronDown, ChevronUp } from 'lucide-react';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';

const faqs = {
  'Getting Started': [
    {
      question: 'How do I create a campaign?',
      answer: 'To create a campaign, click the "Start a Campaign" button in the navigation bar. You\'ll need to sign in or create an account, then follow the step-by-step process to set up your fundraising campaign.'
    },
    {
      question: 'What types of campaigns can I create?',
      answer: 'You can create campaigns for various causes including charity, business, creative projects, education, medical expenses, personal needs, technology, nonprofit organizations, community projects, and emergency relief.'
    },
    {
      question: 'Is there a fee to start a campaign?',
      answer: 'Creating a campaign is free. We only charge a small platform fee (2%) when you receive donations to help cover operating costs and payment processing.'
    }
  ],
  'Donations': [
    {
      question: 'How do I make a donation?',
      answer: 'To make a donation, visit the campaign page you want to support and click the "Donate" button. You can choose your donation amount and payment method, then follow the secure checkout process.'
    },
    {
      question: 'Can I donate anonymously?',
      answer: 'Yes, you can choose to make your donation anonymous during the checkout process. Your name will not be displayed publicly, but the campaign organizer will still receive your donation.'
    },
    {
      question: 'Are donations tax-deductible?',
      answer: 'Tax deductibility depends on the campaign type and the organization receiving the funds. Donations to registered nonprofit organizations are typically tax-deductible. Check with the campaign organizer or consult a tax professional for specific advice.'
    }
  ],
  'Account Management': [
    {
      question: 'How do I reset my password?',
      answer: 'To reset your password, click the "Forgot Password" link on the login page. Enter your email address, and we\'ll send you instructions to create a new password.'
    },
    {
      question: 'Can I change my email address?',
      answer: 'Yes, you can change your email address in your account settings. Go to your profile, click on "Settings," and update your email address. You\'ll need to verify the new email address before the change takes effect.'
    },
    {
      question: 'How do I close my account?',
      answer: 'To close your account, go to your account settings and select "Delete Account." Please note that this action is permanent and cannot be undone. Any active campaigns will need to be closed first.'
    }
  ],
  'Payments & Withdrawals': [
    {
      question: 'When can I withdraw my funds?',
      answer: 'You can withdraw funds as soon as they clear in your account, typically 2-5 business days after receiving a donation. Withdrawals are processed within 1-3 business days.'
    },
    {
      question: 'What payment methods are accepted?',
      answer: 'We accept major credit cards (Visa, Mastercard, American Express), PayPal, and bank transfers. Available payment methods may vary by country.'
    },
    {
      question: 'How do I set up my payment information?',
      answer: 'Go to your account settings and select "Payment Information." You can add your bank account or payment method details there. We use secure encryption to protect your financial information.'
    }
  ]
};

export default function HelpCenterPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({});
  const [expandedQuestions, setExpandedQuestions] = useState<Record<string, boolean>>({});

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const toggleQuestion = (question: string) => {
    setExpandedQuestions(prev => ({
      ...prev,
      [question]: !prev[question]
    }));
  };

  const filteredFaqs = searchQuery
    ? Object.entries(faqs).reduce((acc, [section, questions]) => {
        const filteredQuestions = questions.filter(
          q => 
            q.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
            q.answer.toLowerCase().includes(searchQuery.toLowerCase())
        );
        if (filteredQuestions.length > 0) {
          acc[section] = filteredQuestions;
        }
        return acc;
      }, {} as typeof faqs)
    : faqs;

  return (
    <Layout>
      <div className="bg-emerald-600">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl">
              Help Center
            </h1>
            <p className="mx-auto mt-4 max-w-2xl text-lg text-emerald-100">
              Find answers to common questions and learn how to make the most of FundRise.
            </p>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
            <Input
              type="text"
              placeholder="Search help articles..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div className="space-y-6">
          {Object.entries(filteredFaqs).map(([section, questions]) => (
            <Card key={section}>
              <CardContent className="p-6">
                <button
                  className="flex w-full items-center justify-between text-left"
                  onClick={() => toggleSection(section)}
                >
                  <h2 className="text-xl font-semibold text-gray-900">{section}</h2>
                  {expandedSections[section] ? (
                    <ChevronUp className="h-5 w-5 text-gray-500" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-gray-500" />
                  )}
                </button>

                {expandedSections[section] && (
                  <div className="mt-4 space-y-4">
                    {questions.map((faq, index) => (
                      <div key={index} className="border-t border-gray-200 pt-4">
                        <button
                          className="flex w-full items-center justify-between text-left"
                          onClick={() => toggleQuestion(faq.question)}
                        >
                          <h3 className="text-lg font-medium text-gray-900">
                            {faq.question}
                          </h3>
                          {expandedQuestions[faq.question] ? (
                            <ChevronUp className="h-5 w-5 text-gray-500" />
                          ) : (
                            <ChevronDown className="h-5 w-5 text-gray-500" />
                          )}
                        </button>

                        {expandedQuestions[faq.question] && (
                          <p className="mt-2 text-gray-600">{faq.answer}</p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 rounded-lg bg-gray-50 p-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Still need help?
          </h2>
          <p className="text-gray-600 mb-6">
            Our support team is available 24/7 to assist you with any questions or concerns.
          </p>
          <div className="flex justify-center space-x-4">
            <Button variant="primary">Contact Support</Button>
            <Button variant="outline">Submit a Ticket</Button>
          </div>
        </div>
      </div>
    </Layout>
  );
}