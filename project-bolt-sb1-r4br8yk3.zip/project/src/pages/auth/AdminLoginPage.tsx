import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { ArrowLeft, ArrowRight, Shield } from 'lucide-react';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import { useAuth } from '../../context/AuthContext';
import { toast } from 'sonner';

type FormData = {
  email: string;
  password: string;
};

const ADMIN_EMAIL = 'admin@fundrise.com';

export default function AdminLoginPage() {
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from || '/admin';
  const [loading, setLoading] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm<FormData>();

  const onSubmit = async (data: FormData) => {
    setLoading(true);

    try {
      // Validate admin email before attempting login
      if (data.email !== ADMIN_EMAIL) {
        throw new Error('This login page is for administrators only.');
      }

      await signIn(data.email, data.password);
      navigate(from);
    } catch (error: any) {
      console.error('Login error:', error);
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <Link 
          to="/" 
          className="absolute top-8 left-8 flex items-center text-gray-400 hover:text-white"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Home
        </Link>

        <div className="flex justify-center">
          <Shield className="h-12 w-12 text-emerald-500" />
        </div>
        
        <h2 className="mt-6 text-center text-3xl font-extrabold text-white">
          Admin Login
        </h2>
        <p className="mt-2 text-center text-sm text-gray-400">
          Secure access for platform administrators
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-gray-800 py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <form className="space-y-6" onSubmit={handleSubmit(onSubmit)}>
            <Input
              label="Email address"
              id="email"
              type="email"
              autoComplete="email"
              className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
              labelClassName="text-gray-200"
              {...register('email', {
                required: 'Email is required',
                pattern: {
                  value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                  message: 'Invalid email address'
                },
                validate: (value) => 
                  value === ADMIN_EMAIL || 'This login page is for administrators only'
              })}
              error={errors.email?.message}
            />

            <Input
              label="Password"
              id="password"
              type="password"
              autoComplete="current-password"
              className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
              labelClassName="text-gray-200"
              {...register('password', {
                required: 'Password is required',
                minLength: {
                  value: 6,
                  message: 'Password must be at least 6 characters'
                }
              })}
              error={errors.password?.message}
            />

            <div>
              <Button
                type="submit"
                variant="primary"
                fullWidth
                isLoading={loading}
                className="group bg-emerald-600 hover:bg-emerald-700"
              >
                Sign in to Admin Panel
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </div>
          </form>

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-600" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="bg-gray-800 px-2 text-gray-400">
                  Admin access only
                </span>
              </div>
            </div>
          </div>

          <div className="mt-6">
            <p className="text-center text-sm text-gray-400">
              Need help accessing your admin account?{' '}
              <a href="/contact" className="font-medium text-emerald-500 hover:text-emerald-400">
                Contact support
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}