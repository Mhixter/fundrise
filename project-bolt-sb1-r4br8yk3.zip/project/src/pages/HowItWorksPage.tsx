import React from 'react';
import Layout from '../components/layout/Layout';
import HowItWorks from '../components/home/HowItWorks';
import CallToAction from '../components/home/CallToAction';
import { FileText, Target, Users, Clock, CheckCircle, AlertCircle } from 'lucide-react';

export default function HowItWorksPage() {
  const processSteps = [
    {
      title: "Planning Your Campaign",
      description: "Before you start, it's important to have a clear plan and strategy.",
      steps: [
        "Define your fundraising goals and timeline",
        "Gather compelling photos and videos",
        "Write a clear and engaging campaign story",
        "Identify your target audience",
        "Plan your promotion strategy"
      ]
    },
    {
      title: "Creating Your Campaign",
      description: "Set up your campaign with all the essential elements.",
      steps: [
        "Choose your campaign category",
        "Set your fundraising goal",
        "Upload high-quality images",
        "Write detailed campaign description",
        "Add campaign updates and milestones"
      ]
    },
    {
      title: "Promoting Your Campaign",
      description: "Share your campaign effectively to reach potential donors.",
      steps: [
        "Share on social media platforms",
        "Email your network",
        "Create engaging updates",
        "Leverage local media",
        "Engage with your community"
      ]
    },
    {
      title: "Managing Donations",
      description: "Handle incoming donations and maintain transparency.",
      steps: [
        "Track donation progress",
        "Thank donors promptly",
        "Provide regular updates",
        "Maintain clear records",
        "Share impact stories"
      ]
    }
  ];

  return (
    <Layout>
      <div className="bg-white">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl">
              How FundRise Works
            </h1>
            <p className="mx-auto mt-4 max-w-2xl text-lg text-gray-500">
              Learn how to create successful fundraising campaigns and make a difference with FundRise.
            </p>
          </div>
        </div>
      </div>
      
      <HowItWorks />

      <div className="bg-gray-50 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Detailed Process Guide</h2>
          
          <div className="grid gap-8 md:grid-cols-2">
            {processSteps.map((section, index) => (
              <div key={index} className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-xl font-semibold mb-4">{section.title}</h3>
                <p className="text-gray-600 mb-4">{section.description}</p>
                <ul className="space-y-3">
                  {section.steps.map((step, stepIndex) => (
                    <li key={stepIndex} className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-emerald-500 mr-2 flex-shrink-0 mt-0.5" />
                      <span>{step}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-16">
            <h2 className="text-3xl font-bold text-center mb-8">Best Practices</h2>
            <div className="grid gap-8 md:grid-cols-2">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-xl font-semibold mb-4 text-emerald-600">Recommended</h3>
                <ul className="space-y-3">
                  {[
                    "Set a realistic fundraising goal",
                    "Use high-quality images and videos",
                    "Share personal stories and updates",
                    "Engage with donors regularly",
                    "Be transparent about fund usage",
                    "Thank donors promptly",
                    "Share progress updates frequently"
                  ].map((item, index) => (
                    <li key={index} className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-emerald-500 mr-2 flex-shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-xl font-semibold mb-4 text-red-600">Avoid These</h3>
                <ul className="space-y-3">
                  {[
                    "Setting unrealistic goals",
                    "Using low-quality images",
                    "Neglecting to update supporters",
                    "Ignoring donor messages",
                    "Being vague about fund usage",
                    "Forgetting to thank donors",
                    "Leaving long gaps between updates"
                  ].map((item, index) => (
                    <li key={index} className="flex items-start">
                      <AlertCircle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <div className="mt-16">
            <h2 className="text-3xl font-bold text-center mb-8">Timeline & Expectations</h2>
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <Clock className="h-6 w-6 text-emerald-500" />
                  </div>
                  <div className="ml-4">
                    <h4 className="text-lg font-medium">Campaign Duration</h4>
                    <p className="text-gray-600">Most successful campaigns run for 30-60 days. This gives enough time to reach your goal while maintaining urgency.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <Target className="h-6 w-6 text-emerald-500" />
                  </div>
                  <div className="ml-4">
                    <h4 className="text-lg font-medium">Goal Setting</h4>
                    <p className="text-gray-600">Set achievable goals based on your network size and campaign type. Consider starting with a smaller initial goal that can be increased later.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <Users className="h-6 w-6 text-emerald-500" />
                  </div>
                  <div className="ml-4">
                    <h4 className="text-lg font-medium">Community Engagement</h4>
                    <p className="text-gray-600">Plan to spend 2-3 hours per week engaging with donors and updating your campaign to maintain momentum.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <FileText className="h-6 w-6 text-emerald-500" />
                  </div>
                  <div className="ml-4">
                    <h4 className="text-lg font-medium">Documentation</h4>
                    <p className="text-gray-600">Keep detailed records of your campaign progress, donor communications, and fund usage for transparency.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <CallToAction />
    </Layout>
  );
}