import React from 'react';
import Layout from '../components/layout/Layout';
import { FileText, AlertCircle, CheckCircle } from 'lucide-react';

export default function TaxDeductionsPage() {
  return (
    <Layout>
      <div className="bg-white">
        <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
          <div className="mx-auto max-w-2xl">
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">Tax Deductions</h1>
            <p className="mt-6 text-lg leading-8 text-gray-600">
              Understanding tax deductions for your charitable donations on FundRise.
            </p>

            <div className="mt-12 space-y-8">
              <div className="rounded-lg border border-gray-200 p-6">
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    <FileText className="h-6 w-6 text-emerald-600" />
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold text-gray-900">Tax-Deductible Donations</h2>
                    <p className="mt-2 text-gray-600">
                      Donations to verified charitable organizations on FundRise may be tax-deductible. Look for the "Tax Deductible" badge on campaign pages to identify eligible donations.
                    </p>
                  </div>
                </div>
              </div>

              <div className="rounded-lg bg-emerald-50 p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Eligible Organizations</h2>
                <ul className="space-y-3">
                  {[
                    "Registered 501(c)(3) nonprofits",
                    "Educational institutions",
                    "Religious organizations",
                    "Charitable hospitals",
                    "Public charities"
                  ].map((org, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <CheckCircle className="h-5 w-5 text-emerald-600" />
                      <span>{org}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="rounded-lg border border-gray-200 p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Documentation</h2>
                <p className="text-gray-600 mb-4">
                  For tax purposes, you'll receive:
                </p>
                <ul className="space-y-3">
                  {[
                    "Donation receipt via email",
                    "Annual donation summary",
                    "Tax ID information for eligible organizations",
                    "Documentation of in-kind donations"
                  ].map((doc, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <CheckCircle className="h-5 w-5 text-emerald-600" />
                      <span>{doc}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="rounded-lg bg-yellow-50 p-6">
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    <AlertCircle className="h-6 w-6 text-yellow-600" />
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold text-gray-900">Important Notes</h2>
                    <ul className="mt-2 space-y-2 text-gray-600">
                      <li>• Personal fundraisers are typically not tax-deductible</li>
                      <li>• Consult a tax professional for specific advice</li>
                      <li>• Keep records of all charitable donations</li>
                      <li>• Verify organization's tax status before donating</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="rounded-lg border border-gray-200 p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">FAQ</h2>
                <div className="space-y-4">
                  {[
                    {
                      q: "When will I receive my tax receipt?",
                      a: "Tax receipts are sent immediately after donation via email."
                    },
                    {
                      q: "How do I know if a campaign is tax-deductible?",
                      a: "Look for the 'Tax Deductible' badge on the campaign page."
                    },
                    {
                      q: "Can I deduct donations to personal fundraisers?",
                      a: "Generally, donations to personal fundraisers are not tax-deductible."
                    }
                  ].map((faq, index) => (
                    <div key={index}>
                      <h3 className="font-medium text-gray-900">{faq.q}</h3>
                      <p className="mt-1 text-gray-600">{faq.a}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-12 text-center">
              <p className="text-gray-600">
                Need help with tax-related questions?
              </p>
              <div className="mt-4">
                <a
                  href="/contact"
                  className="inline-block rounded-md bg-emerald-600 px-6 py-3 text-base font-semibold text-white shadow-sm hover:bg-emerald-500"
                >
                  Contact Support
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}