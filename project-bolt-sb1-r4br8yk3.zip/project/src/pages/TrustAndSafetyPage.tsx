import React from 'react';
import Layout from '../components/layout/Layout';
import { Shield, Lock, UserCheck, AlertCircle } from 'lucide-react';

export default function TrustAndSafetyPage() {
  return (
    <Layout>
      <div className="bg-white">
        <div className="relative isolate overflow-hidden bg-gradient-to-b from-emerald-100/20">
          <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
            <div className="mx-auto max-w-2xl lg:mx-0">
              <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">Trust & Safety</h1>
              <p className="mt-6 text-lg leading-8 text-gray-600">
                Your security and trust are our top priorities. Learn about the measures we take to keep our platform safe and reliable.
              </p>
            </div>
          </div>
        </div>

        <div className="mx-auto max-w-7xl px-6 py-12 sm:py-16 lg:px-8">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-2">
            <div>
              <h2 className="text-3xl font-bold tracking-tight text-gray-900">Platform Security</h2>
              <div className="mt-6 space-y-8">
                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <Lock className="h-8 w-8 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Secure Payments</h3>
                    <p className="mt-2 text-gray-600">
                      All transactions are encrypted and processed through trusted payment partners. We use industry-standard SSL encryption to protect your sensitive data.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <Shield className="h-8 w-8 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Fraud Prevention</h3>
                    <p className="mt-2 text-gray-600">
                      Our advanced fraud detection system monitors all transactions and campaigns for suspicious activity. We have a dedicated team reviewing high-risk cases.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <img
                src="https://images.pexels.com/photos/5473298/pexels-photo-5473298.jpeg"
                alt="Security illustration"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>

          <div className="mt-24">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 text-center mb-12">Our Safety Measures</h2>
            <div className="grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-3">
              <div className="relative rounded-lg border border-gray-200 p-8">
                <div className="absolute -top-4 left-4 inline-block rounded-lg bg-emerald-600 p-2 text-white">
                  <UserCheck className="h-6 w-6" />
                </div>
                <h3 className="mt-4 text-lg font-semibold text-gray-900">Identity Verification</h3>
                <p className="mt-2 text-gray-600">
                  We verify the identity of campaign creators to ensure transparency and prevent fraud.
                </p>
              </div>
              <div className="relative rounded-lg border border-gray-200 p-8">
                <div className="absolute -top-4 left-4 inline-block rounded-lg bg-emerald-600 p-2 text-white">
                  <AlertCircle className="h-6 w-6" />
                </div>
                <h3 className="mt-4 text-lg font-semibold text-gray-900">Campaign Monitoring</h3>
                <p className="mt-2 text-gray-600">
                  Our team actively monitors campaigns and investigates any reported concerns.
                </p>
              </div>
              <div className="relative rounded-lg border border-gray-200 p-8">
                <div className="absolute -top-4 left-4 inline-block rounded-lg bg-emerald-600 p-2 text-white">
                  <Shield className="h-6 w-6" />
                </div>
                <h3 className="mt-4 text-lg font-semibold text-gray-900">Secure Platform</h3>
                <p className="mt-2 text-gray-600">
                  We use enterprise-grade security measures to protect your data and transactions.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-24">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 mb-12">Frequently Asked Questions</h2>
            <div className="grid grid-cols-1 gap-8 sm:grid-cols-2">
              {[
                {
                  question: "How do you verify campaign creators?",
                  answer: "We use a combination of ID verification, document validation, and manual review processes to verify campaign creators."
                },
                {
                  question: "What happens if I suspect fraud?",
                  answer: "You can report suspicious campaigns through our reporting system. Our team investigates all reports within 24 hours."
                },
                {
                  question: "Are my donations protected?",
                  answer: "Yes, all donations are protected by our Donor Protection Guarantee. If fraud is detected, you'll receive a full refund."
                },
                {
                  question: "How do you handle personal data?",
                  answer: "We follow strict data protection guidelines and never share your personal information with third parties without consent."
                }
              ].map((faq) => (
                <div key={faq.question} className="rounded-lg bg-gray-50 p-8">
                  <h3 className="text-lg font-semibold text-gray-900">{faq.question}</h3>
                  <p className="mt-2 text-gray-600">{faq.answer}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-24 text-center">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900">Need Help?</h2>
            <p className="mt-4 text-lg text-gray-600">
              Our Trust & Safety team is available 24/7 to assist you with any concerns.
            </p>
            <div className="mt-8">
              <a
                href="/contact"
                className="rounded-md bg-emerald-600 px-6 py-3 text-base font-semibold text-white shadow-sm hover:bg-emerald-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-600"
              >
                Contact Support
              </a>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}