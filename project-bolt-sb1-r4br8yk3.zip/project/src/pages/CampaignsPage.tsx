import React, { useState, useEffect } from 'react';
import { useSearchParams, useParams } from 'react-router-dom';
import Layout from '../components/layout/Layout';
import CampaignList from '../components/campaign/CampaignList';
import Input from '../components/ui/Input';
import Select from '../components/ui/Select';
import { Search } from 'lucide-react';
import { Campaign } from '../types';
import { supabase } from '../lib/supabase';
import { toast } from 'sonner';

export default function CampaignsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { category } = useParams();
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');
  const [selectedCategory, setSelectedCategory] = useState(category || searchParams.get('category') || '');
  const [sortBy, setSortBy] = useState(searchParams.get('sort') || 'newest');

  const categories = [
    { value: '', label: 'All Categories' },
    { value: 'charity', label: 'Charity & Causes' },
    { value: 'business', label: 'Business & Entrepreneurship' },
    { value: 'creative', label: 'Creative & Arts' },
    { value: 'education', label: 'Education' },
    { value: 'medical', label: 'Medical & Health' },
    { value: 'personal', label: 'Personal Needs' },
    { value: 'technology', label: 'Technology & Innovation' },
    { value: 'nonprofit', label: 'Nonprofit Organizations' },
    { value: 'community', label: 'Community Projects' },
    { value: 'emergency', label: 'Emergency Relief' },
    { value: 'other', label: 'Other' }
  ];

  useEffect(() => {
    if (category) {
      setSelectedCategory(category);
    }
  }, [category]);

  useEffect(() => {
    fetchCampaigns();
  }, [selectedCategory, sortBy, category]);

  const fetchCampaigns = async () => {
    setLoading(true);

    try {
      let query = supabase
        .from('campaigns')
        .select('*')
        .eq('status', 'active');
      
      // Apply category filter
      if (selectedCategory) {
        query = query.eq('category', selectedCategory);
      }
      
      // Apply sorting
      switch (sortBy) {
        case 'newest':
          query = query.order('created_at', { ascending: false });
          break;
        case 'oldest':
          query = query.order('created_at', { ascending: true });
          break;
        case 'most_funded':
          query = query.order('current_amount', { ascending: false });
          break;
        case 'ending_soon':
          query = query.not('deadline', 'is', null).order('deadline', { ascending: true });
          break;
      }
      
      // Apply search filter if exists
      if (searchQuery) {
        query = query.ilike('title', `%${searchQuery}%`);
      }

      const { data, error } = await query;

      if (error) {
        throw error;
      }

      setCampaigns(data || []);
    } catch (error) {
      console.error('Error fetching campaigns:', error);
      toast.error('Failed to load campaigns');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchCampaigns();
  };

  return (
    <Layout>
      <div className="bg-gray-50 py-8 sm:py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-gray-900">
            {selectedCategory ? `${categories.find(c => c.value === selectedCategory)?.label} Campaigns` : 'All Campaigns'}
          </h1>
          
          <div className="mt-6">
            <form onSubmit={handleSearch} className="flex flex-col space-y-4 md:flex-row md:space-y-0 md:space-x-4">
              <div className="relative flex-1">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                  <Search size={20} className="text-gray-400" />
                </div>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search campaigns..."
                  className="w-full rounded-md border border-gray-300 pl-10 pr-3 py-2 focus:border-emerald-500 focus:ring-emerald-500"
                />
              </div>
              
              <div className="flex flex-row space-x-4">
                <Select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  options={categories}
                  className="w-full md:w-48"
                />
                
                <Select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  options={[
                    { value: 'newest', label: 'Newest First' },
                    { value: 'oldest', label: 'Oldest First' },
                    { value: 'most_funded', label: 'Most Funded' },
                    { value: 'ending_soon', label: 'Ending Soon' }
                  ]}
                  className="w-full md:w-48"
                />
              </div>
            </form>
          </div>
          
          <div className="mt-8">
            <CampaignList 
              campaigns={campaigns} 
              loading={loading}
              emptyMessage={
                selectedCategory
                  ? `No ${categories.find(c => c.value === selectedCategory)?.label.toLowerCase()} campaigns found`
                  : "No campaigns match your criteria"
              }
            />
          </div>
        </div>
      </div>
    </Layout>
  );
}