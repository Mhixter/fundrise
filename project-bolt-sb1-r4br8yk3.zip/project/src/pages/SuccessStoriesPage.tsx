import React from 'react';
import Layout from '../components/layout/Layout';
import { Star } from 'lucide-react';

export default function SuccessStoriesPage() {
  const stories = [
    {
      title: "Medical Treatment Success",
      author: "Sarah Johnson",
      amount: "$50,000",
      image: "https://images.pexels.com/photos/3279197/pexels-photo-3279197.jpeg",
      description: "Raised funds for life-saving surgery within two weeks with community support.",
      quote: "The support we received was overwhelming. It gave us hope when we needed it most."
    },
    {
      title: "Local Business Revival",
      author: "Michael Chen",
      amount: "$75,000",
      image: "https://images.pexels.com/photos/1367269/pexels-photo-1367269.jpeg",
      description: "Small business owner saved his restaurant and employees' jobs through community funding.",
      quote: "Thanks to FundRise, we didn't just save our business - we strengthened our community bonds."
    },
    {
      title: "Art Exhibition Dream",
      author: "Priya Patel",
      amount: "$25,000",
      image: "https://images.pexels.com/photos/1647976/pexels-photo-1647976.jpeg",
      description: "Artist funded her first gallery exhibition through supporter contributions.",
      quote: "This platform turned my artistic dreams into reality. I'm forever grateful."
    }
  ];

  return (
    <Layout>
      <div className="bg-white">
        <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">Success Stories</h1>
            <p className="mt-6 text-lg leading-8 text-gray-600">
              Real stories from real people who achieved their goals through community support.
            </p>
          </div>

          <div className="mt-16 space-y-20 lg:space-y-20">
            {stories.map((story, index) => (
              <div key={index} className={`relative ${index % 2 === 0 ? '' : 'lg:flex-row-reverse'} lg:flex lg:items-center lg:gap-12`}>
                <div className="relative lg:w-1/2">
                  <img
                    src={story.image}
                    alt={story.title}
                    className="aspect-[3/2] w-full rounded-2xl object-cover"
                  />
                </div>
                <div className="mt-10 lg:mt-0 lg:w-1/2">
                  <div className="flex items-center gap-x-2 text-emerald-600">
                    <Star className="h-5 w-5" />
                    <span className="text-sm font-semibold">Featured Story</span>
                  </div>
                  <h2 className="mt-2 text-3xl font-bold tracking-tight text-gray-900">{story.title}</h2>
                  <div className="mt-4 text-lg text-gray-600">{story.description}</div>
                  <blockquote className="mt-6 border-l-4 border-emerald-500 pl-4 italic text-gray-700">
                    "{story.quote}"
                  </blockquote>
                  <div className="mt-6">
                    <p className="font-semibold text-gray-900">{story.author}</p>
                    <p className="text-emerald-600">Raised {story.amount}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}