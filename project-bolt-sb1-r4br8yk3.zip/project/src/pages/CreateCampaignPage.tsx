import React from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '../components/layout/Layout';
import CampaignForm from '../components/campaign/CampaignForm';
import { useAuth } from '../context/AuthContext';

export default function CreateCampaignPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  // Redirect to login if not authenticated
  React.useEffect(() => {
    if (!loading && !user) {
      navigate('/login', { state: { from: '/create-campaign', message: 'Please log in to create a campaign' } });
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <Layout>
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="h-8 w-1/3 rounded bg-gray-300 mb-6" />
            <div className="space-y-4">
              <div className="h-4 w-1/4 rounded bg-gray-300" />
              <div className="h-10 rounded bg-gray-300" />
              <div className="h-4 w-1/4 rounded bg-gray-300" />
              <div className="h-24 rounded bg-gray-300" />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="h-4 w-1/4 rounded bg-gray-300 mb-2" />
                  <div className="h-10 rounded bg-gray-300" />
                </div>
                <div>
                  <div className="h-4 w-1/4 rounded bg-gray-300 mb-2" />
                  <div className="h-10 rounded bg-gray-300" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Create a New Campaign</h1>
          <p className="mt-2 text-gray-600">
            Share your story, set your fundraising goal, and start receiving support from people around the world.
          </p>
        </div>
        
        <CampaignForm />
      </div>
    </Layout>
  );
}