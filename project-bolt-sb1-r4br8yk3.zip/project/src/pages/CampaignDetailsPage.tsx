import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Calendar, Clock, User, Heart, Share2, Flag } from 'lucide-react';
import Layout from '../components/layout/Layout';
import Button from '../components/ui/Button';
import ProgressBar from '../components/ui/ProgressBar';
import DonationForm from '../components/campaign/DonationForm';
import CommentSection from '../components/campaign/CommentSection';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { Campaign, Donation } from '../types';
import { supabase } from '../lib/supabase';
import { formatCurrency, formatDate, getDaysLeft } from '../utils/helpers';
import { toast } from 'sonner';

export default function CampaignDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const [campaign, setCampaign] = useState<Campaign | null>(null);
  const [recentDonations, setRecentDonations] = useState<Donation[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDonateForm, setShowDonateForm] = useState(false);

  useEffect(() => {
    if (id) {
      fetchCampaign();
      fetchRecentDonations();
    }
  }, [id]);

  const fetchCampaign = async () => {
    try {
      const { data, error } = await supabase
        .from('campaigns')
        .select(`
          *,
          creator:created_by(id, full_name, avatar_url)
        `)
        .eq('id', id)
        .single();

      if (error) {
        throw error;
      }

      setCampaign(data as Campaign);
    } catch (error) {
      console.error('Error fetching campaign:', error);
      toast.error('Failed to load campaign details');
    } finally {
      setLoading(false);
    }
  };

  const fetchRecentDonations = async () => {
    try {
      const { data, error } = await supabase
        .from('donations')
        .select(`
          *,
          donor:user_id(id, full_name, avatar_url)
        `)
        .eq('campaign_id', id)
        .order('created_at', { ascending: false })
        .limit(5);

      if (error) {
        throw error;
      }

      setRecentDonations(data || []);
    } catch (error) {
      console.error('Error fetching donations:', error);
      toast.error('Failed to load recent donations');
    }
  };

  const handleDonationSuccess = () => {
    fetchCampaign();
    fetchRecentDonations();
    setShowDonateForm(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (loading) {
    return (
      <Layout>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 animate-pulse">
          <div className="h-8 w-2/3 rounded bg-gray-300 mb-4" />
          <div className="h-96 w-full rounded bg-gray-300 mb-6" />
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
            <div className="lg:col-span-2 space-y-6">
              <div className="h-4 w-full rounded bg-gray-300" />
              <div className="h-4 w-full rounded bg-gray-300" />
              <div className="h-4 w-3/4 rounded bg-gray-300" />
              <div className="h-4 w-5/6 rounded bg-gray-300" />
            </div>
            <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
              <div className="h-4 w-full rounded bg-gray-300 mb-4" />
              <div className="h-10 w-full rounded bg-gray-300 mb-6" />
              <div className="h-10 w-full rounded bg-gray-300" />
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (!campaign) {
    return (
      <Layout>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <h2 className="text-2xl font-semibold text-gray-900">Campaign Not Found</h2>
            <p className="mt-2 text-gray-600">The campaign you're looking for does not exist or has been removed.</p>
            <Link to="/campaigns">
              <Button variant="primary" className="mt-6">
                Browse Campaigns
              </Button>
            </Link>
          </div>
        </div>
      </Layout>
    );
  }

  const daysLeft = campaign.deadline ? getDaysLeft(campaign.deadline) : null;
  const isActive = !campaign.deadline || new Date(campaign.deadline) > new Date();

  return (
    <Layout>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{campaign.title}</h1>
          <div className="flex flex-wrap items-center text-sm text-gray-500 gap-x-4 gap-y-2">
            <div className="flex items-center">
              <User size={16} className="mr-1" />
              <span>by {campaign.creator?.full_name || 'Anonymous'}</span>
            </div>
            <div className="flex items-center">
              <Calendar size={16} className="mr-1" />
              <span>Created on {formatDate(campaign.created_at)}</span>
            </div>
            {campaign.deadline && (
              <div className="flex items-center">
                <Clock size={16} className="mr-1" />
                <span>{daysLeft !== null ? `${daysLeft} days left` : 'Ended'}</span>
              </div>
            )}
            <span className="inline-flex items-center rounded-full bg-emerald-100 px-2.5 py-0.5 text-xs font-medium text-emerald-800">
              {campaign.category}
            </span>
          </div>
        </div>
        
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <div className="aspect-w-16 aspect-h-9 mb-6 overflow-hidden rounded-lg">
              <img
                src={campaign.cover_image || "https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750"}
                alt={campaign.title}
                className="h-full w-full object-cover"
              />
            </div>
            
            <div className="prose prose-emerald max-w-none">
              <div className="whitespace-pre-wrap text-gray-700">{campaign.description}</div>
            </div>
            
            <div className="mt-12">
              <CommentSection campaignId={campaign.id} />
            </div>
          </div>
          
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <div className="mb-4 text-center">
                  <p className="text-3xl font-bold text-emerald-600">
                    {formatCurrency(campaign.current_amount, campaign.currency)}
                  </p>
                  <p className="text-sm text-gray-500">
                    raised of {formatCurrency(campaign.goal_amount, campaign.currency)} goal
                  </p>
                </div>
                
                <ProgressBar 
                  currentAmount={campaign.current_amount} 
                  goalAmount={campaign.goal_amount}
                  className="mb-6" 
                />
                
                {isActive ? (
                  <div className="space-y-3">
                    <Button 
                      variant="primary" 
                      fullWidth
                      onClick={() => setShowDonateForm(!showDonateForm)}
                    >
                      {showDonateForm ? 'Hide Donation Form' : 'Donate Now'}
                    </Button>
                    <div className="flex space-x-2">
                      <Button variant="outline" fullWidth>
                        <Share2 size={16} className="mr-2" /> Share
                      </Button>
                      <Button variant="outline" fullWidth>
                        <Heart size={16} className="mr-2" /> Save
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="rounded-md bg-yellow-50 p-4">
                    <div className="flex">
                      <div className="ml-3">
                        <p className="text-sm font-medium text-yellow-800">
                          This campaign has ended and is no longer accepting donations.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
                
                {showDonateForm && (
                  <div className="mt-6 pt-6 border-t border-gray-200">
                    <DonationForm 
                      campaign={campaign} 
                      onSuccess={handleDonationSuccess}
                    />
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Recent Supporters</CardTitle>
              </CardHeader>
              <CardContent>
                {recentDonations.length > 0 ? (
                  <ul className="divide-y divide-gray-200">
                    {recentDonations.map((donation) => (
                      <li key={donation.id} className="py-3">
                        <div className="flex space-x-3">
                          <div className="flex-shrink-0">
                            {donation.is_anonymous || !donation.donor?.avatar_url ? (
                              <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                                <User size={20} className="text-gray-500" />
                              </div>
                            ) : (
                              <img
                                className="h-10 w-10 rounded-full"
                                src={donation.donor.avatar_url}
                                alt=""
                              />
                            )}
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className="text-sm font-medium text-gray-900">
                              {donation.is_anonymous ? 'Anonymous' : (donation.donor?.full_name || 'Anonymous')}
                            </p>
                            <p className="text-sm text-gray-500">
                              Donated {formatCurrency(donation.amount, donation.currency)} · {formatDate(donation.created_at)}
                            </p>
                            {donation.message && (
                              <p className="mt-1 text-sm text-gray-600 italic">
                                "{donation.message}"
                              </p>
                            )}
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-center text-sm text-gray-500 py-4">
                    No donations yet. Be the first to support this campaign!
                  </p>
                )}
              </CardContent>
            </Card>
            
            <div className="text-center">
              <button 
                className="inline-flex items-center text-sm text-gray-500 hover:text-gray-700"
              >
                <Flag size={16} className="mr-1" /> Report this campaign
              </button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}