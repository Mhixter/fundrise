import React from 'react';
import Layout from '../components/layout/Layout';
import { HelpCircle } from 'lucide-react';

export default function DonationFAQsPage() {
  const faqs = [
    {
      category: "General Questions",
      questions: [
        {
          q: "How does FundRise work?",
          a: "FundRise is a crowdfunding platform that allows individuals and organizations to raise funds for various causes. Donors can contribute to campaigns using secure payment methods, and funds are transferred to campaign organizers once goals are met."
        },
        {
          q: "Is my donation secure?",
          a: "Yes, all donations are processed through secure payment gateways with encryption. We use industry-standard security measures to protect your financial information."
        },
        {
          q: "Can I donate anonymously?",
          a: "Yes, you have the option to make your donation anonymous during the checkout process."
        }
      ]
    },
    {
      category: "Payment & Fees",
      questions: [
        {
          q: "What payment methods do you accept?",
          a: "We accept major credit cards, PayPal, and bank transfers. Some regions may have additional local payment options."
        },
        {
          q: "Are there any fees for donors?",
          a: "There are no additional fees for donors. You pay exactly the amount you choose to donate."
        },
        {
          q: "Is my donation tax-deductible?",
          a: "Tax deductibility depends on the campaign type and your location. Charitable campaigns will indicate if donations are tax-deductible."
        }
      ]
    },
    {
      category: "Campaign Support",
      questions: [
        {
          q: "What happens if a campaign doesn't reach its goal?",
          a: "Most campaigns will receive funds regardless of reaching their goal. Some campaigns may be all-or-nothing, which will be clearly indicated on the campaign page."
        },
        {
          q: "Can I get a refund on my donation?",
          a: "Refund policies vary by campaign. Please contact support for specific refund requests."
        },
        {
          q: "How do I know my donation is being used as intended?",
          a: "Campaign organizers are required to provide regular updates. We also have verification processes and fraud prevention measures in place."
        }
      ]
    }
  ];

  return (
    <Layout>
      <div className="bg-white">
        <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">Donation FAQs</h1>
            <p className="mt-6 text-lg leading-8 text-gray-600">
              Find answers to commonly asked questions about donating on FundRise.
            </p>
          </div>

          <div className="mt-16">
            {faqs.map((category, index) => (
              <div key={index} className="mb-16">
                <h2 className="text-2xl font-bold text-gray-900 mb-8">{category.category}</h2>
                <div className="grid gap-6">
                  {category.questions.map((faq, faqIndex) => (
                    <div key={faqIndex} className="rounded-lg border border-gray-200 p-6">
                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0">
                          <HelpCircle className="h-6 w-6 text-emerald-600" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">{faq.q}</h3>
                          <p className="mt-2 text-gray-600">{faq.a}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-16 rounded-2xl bg-emerald-50 p-8 text-center">
            <h2 className="text-2xl font-bold text-gray-900">Still have questions?</h2>
            <p className="mt-4 text-lg text-gray-600">
              Can't find the answer you're looking for? Our support team is here to help.
            </p>
            <div className="mt-8">
              <a
                href="/contact"
                className="inline-block rounded-md bg-emerald-600 px-6 py-3 text-base font-semibold text-white shadow-sm hover:bg-emerald-500"
              >
                Contact Support
              </a>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}