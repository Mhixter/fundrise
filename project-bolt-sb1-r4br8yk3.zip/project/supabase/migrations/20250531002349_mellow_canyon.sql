-- Create the campaigns bucket if it doesn't exist
insert into storage.buckets (id, name, public)
values ('campaigns', 'campaigns', true)
on conflict (id) do nothing;

-- Policy to allow authenticated users to upload files
create policy "Authenticated users can upload campaign images"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'campaigns' AND
  (storage.foldername(name))[1] = 'campaign-covers'
);

-- Policy to allow authenticated users to update their own files
create policy "Users can update their own campaign images"
on storage.objects
for update
to authenticated
using (
  bucket_id = 'campaigns' AND
  (storage.foldername(name))[1] = 'campaign-covers'
) 
with check (
  bucket_id = 'campaigns' AND
  (storage.foldername(name))[1] = 'campaign-covers'
);

-- Policy to allow public access to read campaign images
create policy "Public can view campaign images"
on storage.objects
for select
to public
using (bucket_id = 'campaigns');