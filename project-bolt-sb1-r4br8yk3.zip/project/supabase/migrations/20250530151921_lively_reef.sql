/*
  # Add foreign key constraints for user relationships

  1. Changes
    - Add foreign key constraint from donations.user_id to auth.users(id)
    - Add foreign key constraint from campaigns.created_by to auth.users(id)
    - Update queries to use proper join syntax

  2. Security
    - No changes to RLS policies
*/

-- Add foreign key constraint for donations.user_id if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'donations_user_id_fkey'
  ) THEN
    ALTER TABLE donations
    ADD CONSTRAINT donations_user_id_fkey
    FOREIGN KEY (user_id) REFERENCES auth.users(id);
  END IF;
END $$;

-- Add foreign key constraint for campaigns.created_by if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'campaigns_created_by_fkey'
  ) THEN
    ALTER TABLE campaigns
    ADD CONSTRAINT campaigns_created_by_fkey
    FOREIGN KEY (created_by) REFERENCES auth.users(id);
  END IF;
END $$;

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_donations_user_id ON donations(user_id);
CREATE INDEX IF NOT EXISTS idx_campaigns_created_by ON campaigns(created_by);