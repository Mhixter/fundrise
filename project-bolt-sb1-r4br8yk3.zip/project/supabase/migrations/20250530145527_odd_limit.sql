/*
  # Add foreign key constraints for user relationships

  1. Changes
    - Add foreign key constraint from donations.user_id to profiles.id
    - Update queries to use proper join syntax

  2. Security
    - No changes to RLS policies
*/

-- Add foreign key constraint if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'donations_user_id_fkey'
  ) THEN
    ALTER TABLE donations
    ADD CONSTRAINT donations_user_id_fkey
    FOREIGN KEY (user_id) REFERENCES auth.users(id);
  END IF;
END $$;