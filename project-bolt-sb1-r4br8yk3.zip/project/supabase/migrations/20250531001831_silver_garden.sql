/*
  # Create campaigns storage bucket

  1. Storage
    - Creates a new storage bucket named 'campaigns' for storing campaign cover images
    - Sets up public access for viewing images
    - Restricts uploads to authenticated users only

  2. Security
    - Enables RLS policies for the storage bucket
    - Allows public read access to all files
    - Allows authenticated users to upload files
    - Restricts file types to images only
*/

-- Create the storage bucket
insert into storage.buckets (id, name, public)
values ('campaigns', 'campaigns', true);

-- Allow public access to view campaign images
create policy "Campaign images are publicly accessible"
on storage.objects for select
to public
using ( bucket_id = 'campaigns' );

-- Allow authenticated users to upload campaign images
create policy "Users can upload campaign images"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'campaigns'
  and (storage.extension(name) = 'jpg'
    or storage.extension(name) = 'jpeg'
    or storage.extension(name) = 'png'
    or storage.extension(name) = 'gif'
  )
);

-- Allow users to delete their own uploaded images
create policy "Users can delete their own campaign images"
on storage.objects for delete
to authenticated
using ( auth.uid() = owner );