-- Create the profiles table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'profiles' AND schemaname = 'public') THEN
    CREATE TABLE public.profiles (
      id uuid REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
      full_name text,
      avatar_url text,
      email text UNIQUE,
      role text DEFAULT 'user' NOT NULL,
      created_at timestamp with time zone DEFAULT now() NOT NULL,
      bio text
    );

    -- Set up Row Level Security (RLS) for profiles
    ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

    -- Create profile policies if they don't exist
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'profiles' AND policyname = 'Public profiles are viewable by everyone') THEN
      CREATE POLICY "Public profiles are viewable by everyone" ON public.profiles FOR SELECT USING (true);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'profiles' AND policyname = 'Users can insert their own profile') THEN
      CREATE POLICY "Users can insert their own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'profiles' AND policyname = 'Users can update their own profile') THEN
      CREATE POLICY "Users can update their own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
    END IF;
  END IF;
END $$;

-- Create the handle_new_user function if it doesn't exist
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create the trigger if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'on_auth_user_created') THEN
    CREATE TRIGGER on_auth_user_created
      AFTER INSERT ON auth.users
      FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
  END IF;
END $$;

-- Create the campaigns table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'campaigns' AND schemaname = 'public') THEN
    CREATE TABLE public.campaigns (
      id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
      title text NOT NULL,
      description text NOT NULL,
      goal_amount numeric NOT NULL,
      current_amount numeric DEFAULT 0 NOT NULL,
      currency text NOT NULL,
      deadline timestamp with time zone,
      category text NOT NULL,
      status text DEFAULT 'draft' NOT NULL,
      cover_image text,
      created_by uuid REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
      created_at timestamp with time zone DEFAULT now() NOT NULL,
      updated_at timestamp with time zone DEFAULT now() NOT NULL
    );

    -- Set up RLS for campaigns
    ALTER TABLE public.campaigns ENABLE ROW LEVEL SECURITY;

    -- Create campaign policies
    CREATE POLICY "Campaigns are viewable by everyone" ON public.campaigns FOR SELECT USING (true);
    CREATE POLICY "Users can create their own campaigns" ON public.campaigns FOR INSERT WITH CHECK (auth.uid() = created_by);
    CREATE POLICY "Users can update their own campaigns" ON public.campaigns FOR UPDATE USING (auth.uid() = created_by);
    CREATE POLICY "Users can delete their own campaigns" ON public.campaigns FOR DELETE USING (auth.uid() = created_by);
  END IF;
END $$;

-- Create the donations table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'donations' AND schemaname = 'public') THEN
    CREATE TABLE public.donations (
      id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
      campaign_id uuid REFERENCES public.campaigns(id) ON DELETE CASCADE NOT NULL,
      user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
      amount numeric NOT NULL,
      currency text NOT NULL,
      message text,
      is_anonymous boolean DEFAULT FALSE NOT NULL,
      platform_fee numeric NOT NULL,
      net_amount numeric NOT NULL,
      donor_info jsonb,
      created_at timestamp with time zone DEFAULT now() NOT NULL
    );

    -- Set up RLS for donations
    ALTER TABLE public.donations ENABLE ROW LEVEL SECURITY;

    -- Create donation policies
    CREATE POLICY "Donations are viewable by campaign creator and donor" ON public.donations 
      FOR SELECT USING (
        auth.uid() = user_id OR
        EXISTS (SELECT 1 FROM public.campaigns WHERE id = campaign_id AND created_by = auth.uid())
      );
    CREATE POLICY "Anyone can insert donations" ON public.donations FOR INSERT WITH CHECK (true);
  END IF;
END $$;

-- Create the withdrawals table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'withdrawals' AND schemaname = 'public') THEN
    CREATE TABLE public.withdrawals (
      id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
      campaign_id uuid REFERENCES public.campaigns(id) ON DELETE CASCADE NOT NULL,
      amount numeric NOT NULL,
      status text DEFAULT 'pending' NOT NULL,
      created_at timestamp with time zone DEFAULT now() NOT NULL,
      updated_at timestamp with time zone DEFAULT now() NOT NULL
    );

    -- Set up RLS for withdrawals
    ALTER TABLE public.withdrawals ENABLE ROW LEVEL SECURITY;

    -- Create withdrawal policies
    CREATE POLICY "Campaign creators can view their withdrawals" ON public.withdrawals 
      FOR SELECT USING (EXISTS (
        SELECT 1 FROM public.campaigns WHERE id = campaign_id AND created_by = auth.uid()
      ));
    CREATE POLICY "Campaign creators can request withdrawals" ON public.withdrawals 
      FOR INSERT WITH CHECK (EXISTS (
        SELECT 1 FROM public.campaigns WHERE id = campaign_id AND created_by = auth.uid()
      ));
    CREATE POLICY "Admins can update withdrawal status" ON public.withdrawals 
      FOR UPDATE USING (EXISTS (
        SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'
      ));
  END IF;
END $$;