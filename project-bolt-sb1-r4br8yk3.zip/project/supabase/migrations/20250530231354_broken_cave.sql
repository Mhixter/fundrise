-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create campaigns table
CREATE TABLE IF NOT EXISTS public.campaigns (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title text NOT NULL,
    description text NOT NULL,
    goal_amount numeric(12,2) NOT NULL CHECK (goal_amount > 0),
    current_amount numeric(12,2) NOT NULL DEFAULT 0 CHECK (current_amount >= 0),
    currency text NOT NULL DEFAULT 'USD',
    deadline timestamptz,
    category text NOT NULL,
    status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'completed', 'cancelled')),
    cover_image text,
    created_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    created_at timestamptz DEFAULT now() NOT NULL,
    updated_at timestamptz DEFAULT now() NOT NULL,
    CONSTRAINT category_check CHECK (
        category IN (
            'charity', 'business', 'creative', 'education', 'medical',
            'personal', 'technology', 'nonprofit', 'community', 'emergency', 'other'
        )
    )
);

-- Create donations table
CREATE TABLE IF NOT EXISTS public.donations (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id uuid NOT NULL REFERENCES public.campaigns(id) ON DELETE CASCADE,
    user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
    amount numeric(12,2) NOT NULL CHECK (amount > 0),
    currency text NOT NULL DEFAULT 'USD',
    message text,
    is_anonymous boolean DEFAULT false,
    created_at timestamptz DEFAULT now() NOT NULL,
    updated_at timestamptz DEFAULT now() NOT NULL
);

-- Create support_agents table
CREATE TABLE IF NOT EXISTS public.support_agents (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES auth.users(id),
    name text NOT NULL,
    email text NOT NULL,
    status text NOT NULL DEFAULT 'offline',
    specialization text[] NOT NULL,
    created_at timestamptz DEFAULT now(),
    last_active timestamptz DEFAULT now(),
    CONSTRAINT support_agents_user_id_key UNIQUE (user_id)
);

-- Create chat_sessions table
CREATE TABLE IF NOT EXISTS public.chat_sessions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES auth.users(id),
    agent_id uuid REFERENCES public.support_agents(id),
    status text NOT NULL DEFAULT 'pending',
    created_at timestamptz DEFAULT now(),
    ended_at timestamptz
);

-- Create chat_messages table
CREATE TABLE IF NOT EXISTS public.chat_messages (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id uuid REFERENCES public.chat_sessions(id),
    sender_id uuid REFERENCES auth.users(id),
    content text NOT NULL,
    created_at timestamptz DEFAULT now(),
    read_at timestamptz
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_campaigns_created_by ON public.campaigns(created_by);
CREATE INDEX IF NOT EXISTS idx_campaigns_status ON public.campaigns(status);
CREATE INDEX IF NOT EXISTS idx_campaigns_category ON public.campaigns(category);
CREATE INDEX IF NOT EXISTS idx_campaigns_created_at ON public.campaigns(created_at);
CREATE INDEX IF NOT EXISTS idx_donations_campaign_id ON public.donations(campaign_id);
CREATE INDEX IF NOT EXISTS idx_donations_user_id ON public.donations(user_id);
CREATE INDEX IF NOT EXISTS idx_donations_created_at ON public.donations(created_at);
CREATE INDEX IF NOT EXISTS idx_chat_sessions_user_id ON public.chat_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_sessions_agent_id ON public.chat_sessions(agent_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_session_id ON public.chat_messages(session_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_created_at ON public.chat_messages(created_at);

-- Enable RLS
ALTER TABLE public.campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.donations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.support_agents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
DO $$ 
BEGIN
  -- Campaigns policies
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'campaigns' AND policyname = 'Enable read access for all users') THEN
    CREATE POLICY "Enable read access for all users" ON public.campaigns FOR SELECT USING (true);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'campaigns' AND policyname = 'Enable insert for authenticated users') THEN
    CREATE POLICY "Enable insert for authenticated users" ON public.campaigns FOR INSERT WITH CHECK (auth.uid() = created_by);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'campaigns' AND policyname = 'Enable update for campaign owners') THEN
    CREATE POLICY "Enable update for campaign owners" ON public.campaigns FOR UPDATE USING (auth.uid() = created_by);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'campaigns' AND policyname = 'Enable delete for campaign owners') THEN
    CREATE POLICY "Enable delete for campaign owners" ON public.campaigns FOR DELETE USING (auth.uid() = created_by);
  END IF;

  -- Donations policies
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'donations' AND policyname = 'Enable read access for all users') THEN
    CREATE POLICY "Enable read access for all users" ON public.donations FOR SELECT USING (true);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'donations' AND policyname = 'Enable insert for authenticated users') THEN
    CREATE POLICY "Enable insert for authenticated users" ON public.donations FOR INSERT WITH CHECK (auth.uid() = user_id OR user_id IS NULL);
  END IF;

  -- Support agents policies
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'support_agents' AND policyname = 'Allow public read access to online agents') THEN
    CREATE POLICY "Allow public read access to online agents" ON public.support_agents FOR SELECT TO public USING (status = 'online');
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'support_agents' AND policyname = 'Allow agents to update their own status') THEN
    CREATE POLICY "Allow agents to update their own status" ON public.support_agents FOR UPDATE TO authenticated USING (user_id = auth.uid());
  END IF;

  -- Chat sessions policies
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'chat_sessions' AND policyname = 'Allow users to view their own chat sessions') THEN
    CREATE POLICY "Allow users to view their own chat sessions" ON public.chat_sessions FOR SELECT TO authenticated 
      USING (user_id = auth.uid() OR agent_id IN (SELECT id FROM public.support_agents WHERE user_id = auth.uid()));
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'chat_sessions' AND policyname = 'Allow users to create chat sessions') THEN
    CREATE POLICY "Allow users to create chat sessions" ON public.chat_sessions FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
  END IF;

  -- Chat messages policies
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'chat_messages' AND policyname = 'Allow users to view messages in their sessions') THEN
    CREATE POLICY "Allow users to view messages in their sessions" ON public.chat_messages FOR SELECT TO authenticated 
      USING (session_id IN (SELECT id FROM public.chat_sessions WHERE user_id = auth.uid() OR agent_id IN (SELECT id FROM public.support_agents WHERE user_id = auth.uid())));
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'chat_messages' AND policyname = 'Allow users to send messages in their sessions') THEN
    CREATE POLICY "Allow users to send messages in their sessions" ON public.chat_messages FOR INSERT TO authenticated 
      WITH CHECK (session_id IN (SELECT id FROM public.chat_sessions WHERE user_id = auth.uid() OR agent_id IN (SELECT id FROM public.support_agents WHERE user_id = auth.uid())));
  END IF;
END $$;

-- Create triggers
DROP TRIGGER IF EXISTS update_campaigns_updated_at ON public.campaigns;
CREATE TRIGGER update_campaigns_updated_at
    BEFORE UPDATE ON public.campaigns
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_donations_updated_at ON public.donations;
CREATE TRIGGER update_donations_updated_at
    BEFORE UPDATE ON public.donations
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Create admin user
DO $$ 
DECLARE
  new_user_id uuid := gen_random_uuid();
BEGIN
  IF NOT EXISTS (SELECT 1 FROM auth.users WHERE email = 'admin@fundrise.com') THEN
    -- Insert admin user
    INSERT INTO auth.users (
      id, instance_id, email, encrypted_password, email_confirmed_at, role,
      raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
      confirmation_token, recovery_token, aud, is_super_admin
    ) VALUES (
      new_user_id, '00000000-0000-0000-0000-000000000000',
      'admin@fundrise.com', crypt('admin123', gen_salt('bf')), NOW(),
      'authenticated',
      jsonb_build_object('provider', 'email', 'providers', ARRAY['email']),
      jsonb_build_object('full_name', 'Admin User', 'role', 'admin'),
      NOW(), NOW(), '', '', 'authenticated', true
    );

    -- Create support agent record for admin
    INSERT INTO public.support_agents (
      user_id, name, email, status, specialization
    ) VALUES (
      new_user_id, 'Admin User', 'admin@fundrise.com', 'online',
      ARRAY['general', 'technical', 'billing']::text[]
    );
  END IF;
END $$;