-- Create support_agents table if it doesn't exist
CREATE TABLE IF NOT EXISTS public.support_agents (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES auth.users(id),
    name text NOT NULL,
    email text NOT NULL,
    status text NOT NULL DEFAULT 'offline',
    specialization text[] NOT NULL,
    created_at timestamptz DEFAULT now(),
    last_active timestamptz DEFAULT now()
);

-- Add unique constraint to user_id
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'support_agents_user_id_key'
  ) THEN
    ALTER TABLE public.support_agents 
    ADD CONSTRAINT support_agents_user_id_key UNIQUE (user_id);
  END IF;
END $$;

-- Create admin user with secure credentials
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM auth.users WHERE email = 'admin@fundrise.com'
  ) THEN
    -- Insert admin user into auth.users
    INSERT INTO auth.users (
      id,
      instance_id,
      email,
      encrypted_password,
      email_confirmed_at,
      role,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at,
      confirmation_token,
      recovery_token,
      aud,
      is_super_admin
    ) VALUES (
      gen_random_uuid(),
      '00000000-0000-0000-0000-000000000000',
      'admin@fundrise.com',
      crypt('admin123', gen_salt('bf')), -- Default password: admin123
      NOW(),
      'authenticated',
      jsonb_build_object(
        'provider', 'email',
        'providers', ARRAY['email']
      ),
      jsonb_build_object(
        'full_name', 'Admin User',
        'role', 'admin'
      ),
      NOW(),
      NOW(),
      '',
      '',
      'authenticated',
      true
    );
  END IF;
END $$;

-- Grant necessary permissions to admin user
DO $$
DECLARE
  admin_user_id uuid;
BEGIN
  SELECT id INTO admin_user_id FROM auth.users WHERE email = 'admin@fundrise.com';
  
  IF admin_user_id IS NOT NULL THEN
    -- Create support agent record for admin
    INSERT INTO public.support_agents (
      user_id,
      name,
      email,
      status,
      specialization
    ) VALUES (
      admin_user_id,
      'Admin User',
      'admin@fundrise.com',
      'online',
      ARRAY['general', 'technical', 'billing']::text[]
    )
    ON CONFLICT (user_id) DO NOTHING;
  END IF;
END $$;

-- Enable RLS on support_agents table
ALTER TABLE public.support_agents ENABLE ROW LEVEL SECURITY;

-- Create policies for support_agents table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE policyname = 'Allow agents to update their own status'
    AND tablename = 'support_agents'
  ) THEN
    CREATE POLICY "Allow agents to update their own status"
      ON public.support_agents
      FOR UPDATE
      TO authenticated
      USING (user_id = auth.uid());
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE policyname = 'Allow public read access to online agents'
    AND tablename = 'support_agents'
  ) THEN
    CREATE POLICY "Allow public read access to online agents"
      ON public.support_agents
      FOR SELECT
      TO public
      USING (status = 'online');
  END IF;
END $$;