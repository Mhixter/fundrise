-- Drop existing foreign key if it exists (to avoid conflicts)
ALTER TABLE IF EXISTS campaigns
DROP CONSTRAINT IF EXISTS campaigns_created_by_fkey;

-- Add the correct foreign key constraint to auth.users
ALTER TABLE campaigns
ADD CONSTRAINT campaigns_created_by_fkey
FOREIGN KEY (created_by) REFERENCES auth.users(id)
ON DELETE CASCADE;

-- Update RLS policies to use created_by
DROP POLICY IF EXISTS "Users can update their own campaigns" ON campaigns;
CREATE POLICY "Users can update their own campaigns"
ON campaigns
FOR UPDATE
TO authenticated
USING (auth.uid() = created_by)
WITH CHECK (auth.uid() = created_by);

DROP POLICY IF EXISTS "Users can delete their own campaigns" ON campaigns;
CREATE POLICY "Users can delete their own campaigns"
ON campaigns
FOR DELETE
TO authenticated
USING (auth.uid() = created_by);

-- Create index for better query performance
CREATE INDEX IF NOT EXISTS idx_campaigns_created_by ON campaigns(created_by);