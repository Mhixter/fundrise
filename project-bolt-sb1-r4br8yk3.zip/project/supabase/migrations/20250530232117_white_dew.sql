-- Create AI assistant related tables

-- Create AI assistants table
CREATE TABLE IF NOT EXISTS public.ai_assistants (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name text NOT NULL,
    description text,
    capabilities text[] NOT NULL,
    model_config jsonb NOT NULL DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamptz DEFAULT now() NOT NULL,
    updated_at timestamptz DEFAULT now() NOT NULL
);

-- Create conversations table
CREATE TABLE IF NOT EXISTS public.conversations (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
    assistant_id uuid REFERENCES public.ai_assistants(id),
    title text,
    status text NOT NULL DEFAULT 'active',
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamptz DEFAULT now() NOT NULL,
    updated_at timestamptz DEFAULT now() NOT NULL
);

-- Create messages table
CREATE TABLE IF NOT EXISTS public.messages (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id uuid REFERENCES public.conversations(id) ON DELETE CASCADE,
    role text NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
    content text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamptz DEFAULT now() NOT NULL
);

-- Create message feedback table
CREATE TABLE IF NOT EXISTS public.message_feedback (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id uuid REFERENCES public.messages(id) ON DELETE CASCADE,
    user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
    rating smallint CHECK (rating >= 1 AND rating <= 5),
    feedback text,
    created_at timestamptz DEFAULT now() NOT NULL
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_conversations_user_id ON public.conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_conversations_assistant_id ON public.conversations(assistant_id);
CREATE INDEX IF NOT EXISTS idx_messages_conversation_id ON public.messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON public.messages(created_at);
CREATE INDEX IF NOT EXISTS idx_message_feedback_message_id ON public.message_feedback(message_id);

-- Enable RLS
ALTER TABLE public.ai_assistants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.message_feedback ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Allow public read access to active assistants" 
    ON public.ai_assistants FOR SELECT 
    USING (is_active = true);

CREATE POLICY "Allow users to view their own conversations" 
    ON public.conversations FOR SELECT 
    USING (user_id = auth.uid());

CREATE POLICY "Allow users to create conversations" 
    ON public.conversations FOR INSERT 
    WITH CHECK (user_id = auth.uid());

CREATE POLICY "Allow users to view messages in their conversations" 
    ON public.messages FOR SELECT 
    USING (conversation_id IN (
        SELECT id FROM public.conversations WHERE user_id = auth.uid()
    ));

CREATE POLICY "Allow users to create messages in their conversations" 
    ON public.messages FOR INSERT 
    WITH CHECK (conversation_id IN (
        SELECT id FROM public.conversations WHERE user_id = auth.uid()
    ));

CREATE POLICY "Allow users to create feedback" 
    ON public.message_feedback FOR INSERT 
    WITH CHECK (user_id = auth.uid());

-- Create default AI assistant
INSERT INTO public.ai_assistants (
    name,
    description,
    capabilities,
    model_config
) VALUES (
    'Support Assistant',
    'General purpose support assistant for helping users with platform-related questions',
    ARRAY['general_support', 'platform_help', 'technical_assistance'],
    '{
        "model": "gpt-4",
        "temperature": 0.7,
        "max_tokens": 500,
        "top_p": 1
    }'::jsonb
);