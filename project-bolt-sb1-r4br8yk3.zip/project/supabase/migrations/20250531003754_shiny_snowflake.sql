/*
  # Add Profile Relationships

  1. Changes
    - Add foreign key constraint between support_tickets.user_id and profiles.id
    - Add foreign key constraint between campaigns.created_by and profiles.id
    
  2. Security
    - No changes to RLS policies
    - Existing table permissions remain unchanged
    
  Note: Using IF NOT EXISTS to prevent errors if constraints already exist
*/

DO $$ 
BEGIN
  -- Add foreign key for support_tickets.user_id if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'support_tickets_user_id_fkey'
  ) THEN
    ALTER TABLE support_tickets
    ADD CONSTRAINT support_tickets_user_id_fkey
    FOREIGN KEY (user_id) REFERENCES profiles(id);
  END IF;

  -- Add foreign key for campaigns.created_by if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'campaigns_created_by_fkey'
  ) THEN
    ALTER TABLE campaigns
    ADD CONSTRAINT campaigns_created_by_fkey
    FOREIGN KEY (created_by) REFERENCES profiles(id);
  END IF;
END $$;