/*
  # Fix campaign schema and add missing columns

  1. Changes
    - Add missing columns to campaigns table:
      - title (text)
      - description (text)
      - goal_amount (numeric)
      - current_amount (numeric)
      - currency (text)
      - category (text)
      - cover_image (text)

  2. Security
    - Maintain existing RLS policies
*/

-- Add missing columns to campaigns table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'campaigns' AND column_name = 'title'
  ) THEN
    ALTER TABLE campaigns 
      ADD COLUMN title text NOT NULL,
      ADD COLUMN description text,
      ADD COLUMN goal_amount numeric(12,2) NOT NULL DEFAULT 0,
      ADD COLUMN current_amount numeric(12,2) NOT NULL DEFAULT 0,
      ADD COLUMN currency text NOT NULL DEFAULT 'USD',
      ADD COLUMN category text,
      ADD COLUMN cover_image text;
  END IF;
END $$;