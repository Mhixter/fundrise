-- Add category validation to campaigns table
ALTER TABLE campaigns
DROP CONSTRAINT IF EXISTS campaigns_category_check;

ALTER TABLE campaigns
ADD CONSTRAINT campaigns_category_check
CHECK (category = ANY (ARRAY[
  'charity',
  'business',
  'creative',
  'education',
  'medical',
  'personal',
  'technology',
  'nonprofit',
  'community',
  'emergency',
  'other'
]::text[]));

-- Update any invalid categories to 'other'
UPDATE campaigns
SET category = 'other'
WHERE category IS NULL OR category NOT IN (
  'charity',
  'business',
  'creative',
  'education',
  'medical',
  'personal',
  'technology',
  'nonprofit',
  'community',
  'emergency',
  'other'
);

-- Make category column required
ALTER TABLE campaigns
ALTER COLUMN category SET NOT NULL;