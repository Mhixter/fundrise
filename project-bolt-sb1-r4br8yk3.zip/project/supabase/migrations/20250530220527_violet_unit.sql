-- Create support_agents table
CREATE TABLE IF NOT EXISTS public.support_agents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'offline',
  specialization TEXT[] NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  last_active TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create chat_sessions table
CREATE TABLE IF NOT EXISTS public.chat_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  agent_id UUID REFERENCES support_agents(id),
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  ended_at TIMESTAMP WITH TIME ZONE
);

-- Create chat_messages table
CREATE TABLE IF NOT EXISTS public.chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID REFERENCES chat_sessions(id),
  sender_id UUID REFERENCES auth.users(id),
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  read_at TIMESTAMP WITH TIME ZONE
);

-- Enable RLS
ALTER TABLE public.support_agents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;

-- RLS Policies with existence checks
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'support_agents' 
    AND policyname = 'Allow public read access to online agents'
  ) THEN
    CREATE POLICY "Allow public read access to online agents" ON public.support_agents
      FOR SELECT TO public USING (status = 'online');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'support_agents' 
    AND policyname = 'Allow agents to update their own status'
  ) THEN
    CREATE POLICY "Allow agents to update their own status" ON public.support_agents
      FOR UPDATE TO authenticated USING (user_id = auth.uid());
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'chat_sessions' 
    AND policyname = 'Allow users to view their own chat sessions'
  ) THEN
    CREATE POLICY "Allow users to view their own chat sessions" ON public.chat_sessions
      FOR SELECT TO authenticated USING (user_id = auth.uid() OR agent_id IN (
        SELECT id FROM support_agents WHERE user_id = auth.uid()
      ));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'chat_sessions' 
    AND policyname = 'Allow users to create chat sessions'
  ) THEN
    CREATE POLICY "Allow users to create chat sessions" ON public.chat_sessions
      FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'chat_messages' 
    AND policyname = 'Allow users to view messages in their sessions'
  ) THEN
    CREATE POLICY "Allow users to view messages in their sessions" ON public.chat_messages
      FOR SELECT TO authenticated USING (
        session_id IN (
          SELECT id FROM chat_sessions WHERE user_id = auth.uid() OR agent_id IN (
            SELECT id FROM support_agents WHERE user_id = auth.uid()
          )
        )
      );
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'chat_messages' 
    AND policyname = 'Allow users to send messages in their sessions'
  ) THEN
    CREATE POLICY "Allow users to send messages in their sessions" ON public.chat_messages
      FOR INSERT TO authenticated WITH CHECK (
        session_id IN (
          SELECT id FROM chat_sessions WHERE user_id = auth.uid() OR agent_id IN (
            SELECT id FROM support_agents WHERE user_id = auth.uid()
          )
        )
      );
  END IF;
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_chat_sessions_user_id ON public.chat_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_sessions_agent_id ON public.chat_sessions(agent_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_session_id ON public.chat_messages(session_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_created_at ON public.chat_messages(created_at);