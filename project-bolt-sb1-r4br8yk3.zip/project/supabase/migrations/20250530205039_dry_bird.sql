-- Create admin user if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM auth.users WHERE email = 'admin@fundrise.com'
  ) THEN
    -- Insert admin user into auth.users with UUID
    INSERT INTO auth.users (
      id,
      instance_id,
      email,
      encrypted_password,
      email_confirmed_at,
      role,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at,
      confirmation_token,
      recovery_token,
      aud,
      is_super_admin
    ) VALUES (
      gen_random_uuid(),
      '00000000-0000-0000-0000-000000000000',
      'admin@fundrise.com',
      crypt('admin123', gen_salt('bf')),
      NOW(),
      'authenticated',
      '{"provider": "email", "providers": ["email"]}',
      '{"full_name": "Admin User", "role": "admin"}',
      NOW(),
      NOW(),
      '',
      '',
      'authenticated',
      false
    );
  END IF;
END $$;