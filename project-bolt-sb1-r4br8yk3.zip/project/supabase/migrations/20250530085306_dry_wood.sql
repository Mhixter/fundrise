/*
  # Add deadline column to campaigns table

  1. Changes
    - Add `deadline` column to `campaigns` table
      - Type: DATE (allows storing campaign end dates)
      - Nullable (allows campaigns without deadlines)
      - No default value (optional field)

  2. Impact
    - Enables setting and tracking campaign deadlines
    - Maintains backward compatibility with existing campaigns
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'campaigns' 
    AND column_name = 'deadline'
  ) THEN
    ALTER TABLE campaigns 
    ADD COLUMN deadline DATE;
  END IF;
END $$;