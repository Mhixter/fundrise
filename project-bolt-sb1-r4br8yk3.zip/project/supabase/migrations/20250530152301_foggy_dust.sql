-- Add category validation to campaigns table
ALTER TABLE campaigns
DROP CONSTRAINT IF EXISTS campaigns_category_check;

ALTER TABLE campaigns
ADD CONSTRAINT campaigns_category_check
CHECK (category IN (
  'charity',
  'business',
  'creative',
  'education',
  'medical',
  'personal',
  'technology',
  'nonprofit',
  'community',
  'emergency',
  'other'
));

-- Update existing campaigns with invalid categories
UPDATE campaigns
SET category = 'other'
WHERE category NOT IN (
  'charity',
  'business',
  'creative',
  'education',
  'medical',
  'personal',
  'technology',
  'nonprofit',
  'community',
  'emergency',
  'other'
);