-- Function to create admin user and support agent
CREATE OR REPLACE FUNCTION create_admin_user()
RETURNS void AS $$
DECLARE
  new_user_id uuid;
  existing_user_id uuid;
BEGIN
  -- Check if admin user already exists
  SELECT id INTO existing_user_id 
  FROM auth.users 
  WHERE email = 'admin@fundrise.com';

  IF existing_user_id IS NULL THEN
    -- Generate new UUID for user
    new_user_id := gen_random_uuid();
    
    -- Create admin user
    INSERT INTO auth.users (
      id,
      instance_id,
      email,
      encrypted_password,
      email_confirmed_at,
      role,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at,
      confirmation_token,
      recovery_token,
      aud,
      is_super_admin
    ) VALUES (
      new_user_id,
      '00000000-0000-0000-0000-000000000000',
      'admin@fundrise.com',
      crypt('admin123', gen_salt('bf')),
      NOW(),
      'authenticated',
      jsonb_build_object(
        'provider', 'email',
        'providers', ARRAY['email']
      ),
      jsonb_build_object(
        'full_name', 'Admin User',
        'role', 'admin'
      ),
      NOW(),
      NOW(),
      '',
      '',
      'authenticated',
      false
    );

    -- Create support agent record for admin
    INSERT INTO public.support_agents (
      user_id,
      name,
      email,
      status,
      specialization
    ) VALUES (
      new_user_id,
      'Admin User',
      'admin@fundrise.com',
      'online',
      ARRAY['general', 'technical', 'billing']::text[]
    );
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Execute the function
SELECT create_admin_user();

-- Drop the function after use
DROP FUNCTION IF EXISTS create_admin_user();