-- Create the storage bucket if it doesn't exist
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public)
  VALUES ('campaigns', 'campaigns', true)
  ON CONFLICT (id) DO NOTHING;
END $$;

-- Enable public access to read campaign images
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'Campaign images are publicly accessible'
  ) THEN
    CREATE POLICY "Campaign images are publicly accessible"
    ON storage.objects FOR SELECT
    TO public
    USING (bucket_id = 'campaigns');
  END IF;
END $$;

-- Allow authenticated users to upload campaign images
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'Users can upload campaign images'
  ) THEN
    CREATE POLICY "Users can upload campaign images"
    ON storage.objects FOR INSERT
    TO authenticated
    WITH CHECK (
      bucket_id = 'campaigns' AND
      (LOWER(path) LIKE '%.jpg' OR 
       LOWER(path) LIKE '%.jpeg' OR 
       LOWER(path) LIKE '%.png' OR 
       LOWER(path) LIKE '%.gif' OR 
       LOWER(path) LIKE '%.webp') AND
      octet_length(content) < 10485760 -- Limit file size to 10MB
    );
  END IF;
END $$;