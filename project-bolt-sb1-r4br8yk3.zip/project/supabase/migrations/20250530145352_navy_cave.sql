/*
  # Add foreign key from donations to profiles

  1. Changes
    - Add foreign key constraint from donations.user_id to profiles.id
    - This enables proper joins between donations and profiles tables
    - Required for displaying donor information in campaign details and admin dashboard

  2. Security
    - No changes to RLS policies
    - Existing table permissions remain unchanged
*/

-- Add foreign key constraint from donations.user_id to profiles.id
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'donations_user_id_fkey'
  ) THEN
    ALTER TABLE donations
    ADD CONSTRAINT donations_user_id_fkey
    FOREIGN KEY (user_id) REFERENCES auth.users(id);
  END IF;
END $$;